import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

type TeamId = 'alpha' | 'bravo';
type TeamSizeMode = '2v2' | '5v5';
type MpMode = 'tdm' | 'domination';

interface CapturePointState {
  id: 'A' | 'B' | 'C';
  x: number;
  z: number;
  owner: TeamId | 'neutral';
  progress: number;
  capturingTeam: TeamId | null;
}

interface ServerPlayer {
  id: string;
  callsign: string;
  team: TeamId;
  ready: boolean;
  isHost: boolean;
  characterId: string;
  skinId: string;
  weaponId: string;
  kills: number;
  deaths: number;
  assists: number;
  score: number;
  hp: number;
  alive: boolean;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  crouching: boolean;
  moving: boolean;
  lastFireMs: number;
  medkits: number;
  respawnAtMs: number;
  ws: WebSocket;
}

interface ServerRoom {
  roomId: string;
  code: string;
  name: string;
  isPrivate: boolean;
  mode: MpMode;
  teamSize: TeamSizeMode;
  maxPlayers: number;
  mapId: 'urban_arena' | 'harbor_arena';
  status: 'lobby' | 'playing' | 'ended';
  hostId: string;
  alphaScore: number;
  bravoScore: number;
  scoreLimit: number;
  timeRemainingSec: number;
  winner: TeamId | 'draw' | null;
  players: Map<string, ServerPlayer>;
  capturePoints: CapturePointState[];
  lastDomTickMs: number;
  createdAtMs: number;
}

const WEAPON_DAMAGE_TABLE: Record<string, { dmg: number; minIntervalMs: number }> = {
  m4a1: { dmg: 28, minIntervalMs: 75 },
  ak74m: { dmg: 36, minIntervalMs: 90 },
  mp5sd: { dmg: 22, minIntervalMs: 60 },
  spas12: { dmg: 76, minIntervalMs: 420 },
  scarh: { dmg: 44, minIntervalMs: 110 },
  m249: { dmg: 30, minIntervalMs: 70 },
  awm: { dmg: 115, minIntervalMs: 900 },
  p226: { dmg: 26, minIntervalMs: 130 },
};

const ALPHA_SPAWNS = [
  { x: -38, z: -38 },
  { x: -42, z: -30 },
  { x: -30, z: -42 },
  { x: -44, z: -38 },
  { x: -34, z: -34 },
];

const BRAVO_SPAWNS = [
  { x: 38, z: 38 },
  { x: 42, z: 30 },
  { x: 30, z: 42 },
  { x: 44, z: 38 },
  { x: 34, z: 34 },
];

function makeRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < 6; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

function makeId(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

function createInitialCapturePoints(): CapturePointState[] {
  return [
    { id: 'A', x: -22, z: -18, owner: 'neutral', progress: 0, capturingTeam: null },
    { id: 'B', x: 0, z: 0, owner: 'neutral', progress: 0, capturingTeam: null },
    { id: 'C', x: 22, z: 18, owner: 'neutral', progress: 0, capturingTeam: null },
  ];
}

function serializeRoom(room: ServerRoom) {
  return {
    roomId: room.roomId,
    code: room.code,
    name: room.name,
    isPrivate: room.isPrivate,
    mode: room.mode,
    teamSize: room.teamSize,
    maxPlayers: room.maxPlayers,
    mapId: room.mapId,
    status: room.status,
    hostId: room.hostId,
    alphaScore: room.alphaScore,
    bravoScore: room.bravoScore,
    scoreLimit: room.scoreLimit,
    timeRemainingSec: Math.max(0, Math.ceil(room.timeRemainingSec)),
    winner: room.winner,
    capturePoints: room.capturePoints,
    players: Array.from(room.players.values()).map((p) => ({
      id: p.id,
      callsign: p.callsign,
      team: p.team,
      ready: p.ready,
      isHost: p.isHost,
      characterId: p.characterId,
      skinId: p.skinId,
      weaponId: p.weaponId,
      kills: p.kills,
      deaths: p.deaths,
      assists: p.assists,
      score: p.score,
      hp: p.hp,
      alive: p.alive,
      x: p.x,
      y: p.y,
      z: p.z,
      yaw: p.yaw,
      pitch: p.pitch,
      crouching: p.crouching,
      moving: p.moving,
    })),
  };
}

function sendJson(ws: WebSocket, payload: unknown) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function broadcastRoom(room: ServerRoom, payload: unknown, exceptPlayerId?: string) {
  const msg = JSON.stringify(payload);
  for (const player of room.players.values()) {
    if (exceptPlayerId && player.id === exceptPlayerId) continue;
    if (player.ws.readyState === WebSocket.OPEN) {
      player.ws.send(msg);
    }
  }
}

function getSpawnForPlayer(team: TeamId, index: number) {
  const list = team === 'alpha' ? ALPHA_SPAWNS : BRAVO_SPAWNS;
  const pt = list[index % list.length];
  return { x: pt.x, y: 0, z: pt.z, yaw: team === 'alpha' ? -Math.PI * 0.75 : Math.PI * 0.25 };
}

async function startServer() {
  const app = express();
  app.use(express.json());

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  const rooms = new Map<string, ServerRoom>();
  const socketToMeta = new Map<WebSocket, { playerId: string; roomId: string | null }>();

  function assignBalancedTeam(room: ServerRoom): TeamId {
    let alpha = 0;
    let bravo = 0;
    for (const p of room.players.values()) {
      if (p.team === 'alpha') alpha++;
      else bravo++;
    }
    return alpha <= bravo ? 'alpha' : 'bravo';
  }

  function removePlayerFromRoom(ws: WebSocket) {
    const meta = socketToMeta.get(ws);
    if (!meta || !meta.roomId) return;
    const room = rooms.get(meta.roomId);
    meta.roomId = null;
    if (!room) return;

    const leaving = room.players.get(meta.playerId);
    room.players.delete(meta.playerId);

    if (room.players.size === 0) {
      rooms.delete(room.roomId);
      return;
    }

    if (room.hostId === meta.playerId) {
      const nextHost = room.players.values().next().value;
      if (nextHost) {
        nextHost.isHost = true;
        room.hostId = nextHost.id;
      }
    }

    if (leaving) {
      broadcastRoom(room, {
        type: 'chat_message',
        message: {
          id: makeId('sys'),
          senderId: 'system',
          senderName: 'النظام',
          team: 'system',
          text: `غادر ${leaving.callsign} الغرفة.`,
          timestamp: Date.now(),
        },
      });
    }

    broadcastRoom(room, { type: 'room_state', room: serializeRoom(room) });
  }

  function createRoomInternal(opts: {
    name: string;
    isPrivate: boolean;
    mode: MpMode;
    teamSize: TeamSizeMode;
    mapId: 'urban_arena' | 'harbor_arena';
    hostId: string;
  }): ServerRoom {
    const maxPerTeam = opts.teamSize === '2v2' ? 2 : 5;
    let code = makeRoomCode();
    while (Array.from(rooms.values()).some((r) => r.code === code)) {
      code = makeRoomCode();
    }
    const room: ServerRoom = {
      roomId: makeId('room'),
      code,
      name: opts.name.slice(0, 28) || `غرفة ${code}`,
      isPrivate: opts.isPrivate,
      mode: opts.mode,
      teamSize: opts.teamSize,
      maxPlayers: maxPerTeam * 2,
      mapId: opts.mapId,
      status: 'lobby',
      hostId: opts.hostId,
      alphaScore: 0,
      bravoScore: 0,
      scoreLimit: opts.mode === 'tdm' ? (opts.teamSize === '2v2' ? 15 : 30) : 100,
      timeRemainingSec: opts.mode === 'tdm' ? 300 : 360,
      winner: null,
      players: new Map(),
      capturePoints: createInitialCapturePoints(),
      lastDomTickMs: Date.now(),
      createdAtMs: Date.now(),
    };
    rooms.set(room.roomId, room);
    return room;
  }

  function joinRoomInternal(
    ws: WebSocket,
    playerId: string,
    room: ServerRoom,
    profile: { callsign: string; characterId: string; skinId: string; weaponId: string }
  ) {
    if (room.players.size >= room.maxPlayers) {
      sendJson(ws, { type: 'error', message: 'الغرفة ممتلئة حالياً.' });
      return;
    }

    const team = assignBalancedTeam(room);
    const spawn = getSpawnForPlayer(team, room.players.size);
    const isHost = room.players.size === 0 || room.hostId === playerId;

    const player: ServerPlayer = {
      id: playerId,
      callsign: (profile.callsign || 'جندي').slice(0, 20),
      team,
      ready: isHost,
      isHost,
      characterId: profile.characterId || 'striker',
      skinId: profile.skinId || 'olive',
      weaponId: profile.weaponId || 'm4a1',
      kills: 0,
      deaths: 0,
      assists: 0,
      score: 0,
      hp: 100,
      alive: true,
      x: spawn.x,
      y: spawn.y,
      z: spawn.z,
      yaw: spawn.yaw,
      pitch: 0,
      crouching: false,
      moving: false,
      lastFireMs: 0,
      medkits: 2,
      respawnAtMs: 0,
      ws,
    };

    room.players.set(playerId, player);
    socketToMeta.set(ws, { playerId, roomId: room.roomId });

    sendJson(ws, { type: 'joined_room', playerId, room: serializeRoom(room) });
    broadcastRoom(room, { type: 'room_state', room: serializeRoom(room) }, playerId);
    broadcastRoom(room, {
      type: 'chat_message',
      message: {
        id: makeId('sys'),
        senderId: 'system',
        senderName: 'النظام',
        team: 'system',
        text: `انضم ${player.callsign} إلى فريق ${team === 'alpha' ? 'ألفا' : 'برافو'}.`,
        timestamp: Date.now(),
      },
    });
  }

  wss.on('connection', (ws) => {
    const playerId = makeId('plr');
    socketToMeta.set(ws, { playerId, roomId: null });
    sendJson(ws, { type: 'welcome', playerId });

    ws.on('message', (raw) => {
      let data: Record<string, unknown>;
      try {
        data = JSON.parse(raw.toString()) as Record<string, unknown>;
      } catch {
        return;
      }

      const meta = socketToMeta.get(ws);
      if (!meta) return;
      const type = String(data.type || '');

      if (type === 'create_room') {
        removePlayerFromRoom(ws);
        const mode: MpMode = data.mode === 'domination' ? 'domination' : 'tdm';
        const teamSize: TeamSizeMode = data.teamSize === '5v5' ? '5v5' : '2v2';
        const mapId = data.mapId === 'harbor_arena' ? 'harbor_arena' : 'urban_arena';
        const isPrivate = Boolean(data.isPrivate);
        const room = createRoomInternal({
          name: String(data.roomName || ''),
          isPrivate,
          mode,
          teamSize,
          mapId,
          hostId: meta.playerId,
        });
        joinRoomInternal(ws, meta.playerId, room, {
          callsign: String(data.callsign || 'قائد'),
          characterId: String(data.characterId || 'striker'),
          skinId: String(data.skinId || 'olive'),
          weaponId: String(data.weaponId || 'm4a1'),
        });
        return;
      }

      if (type === 'quick_match') {
        removePlayerFromRoom(ws);
        const mode: MpMode = data.mode === 'domination' ? 'domination' : 'tdm';
        const teamSize: TeamSizeMode = data.teamSize === '5v5' ? '5v5' : '2v2';
        let targetRoom: ServerRoom | null = null;
        for (const r of rooms.values()) {
          if (
            !r.isPrivate &&
            r.mode === mode &&
            r.teamSize === teamSize &&
            r.status !== 'ended' &&
            r.players.size < r.maxPlayers
          ) {
            targetRoom = r;
            break;
          }
        }
        if (!targetRoom) {
          targetRoom = createRoomInternal({
            name: mode === 'tdm' ? `مباراة ${teamSize}` : `سيطرة ${teamSize}`,
            isPrivate: false,
            mode,
            teamSize,
            mapId: mode === 'domination' ? 'harbor_arena' : 'urban_arena',
            hostId: meta.playerId,
          });
        }
        joinRoomInternal(ws, meta.playerId, targetRoom, {
          callsign: String(data.callsign || 'مقاتل'),
          characterId: String(data.characterId || 'striker'),
          skinId: String(data.skinId || 'olive'),
          weaponId: String(data.weaponId || 'm4a1'),
        });
        return;
      }

      if (type === 'join_room') {
        removePlayerFromRoom(ws);
        const codeOrId = String(data.code || data.roomId || '').trim().toUpperCase();
        let found: ServerRoom | undefined;
        for (const r of rooms.values()) {
          if (r.code === codeOrId || r.roomId.toUpperCase() === codeOrId) {
            found = r;
            break;
          }
        }
        if (!found) {
          sendJson(ws, { type: 'error', message: 'لم يتم العثور على الغرفة المطلوبة.' });
          return;
        }
        if (found.status === 'ended') {
          sendJson(ws, { type: 'error', message: 'انتهت المباراة في هذه الغرفة.' });
          return;
        }
        joinRoomInternal(ws, meta.playerId, found, {
          callsign: String(data.callsign || 'مقاتل'),
          characterId: String(data.characterId || 'striker'),
          skinId: String(data.skinId || 'olive'),
          weaponId: String(data.weaponId || 'm4a1'),
        });
        return;
      }

      if (type === 'leave_room') {
        removePlayerFromRoom(ws);
        sendJson(ws, { type: 'left_room' });
        return;
      }

      const room = meta.roomId ? rooms.get(meta.roomId) : undefined;
      if (!room) return;
      const player = room.players.get(meta.playerId);
      if (!player) return;

      if (type === 'switch_team' && room.status === 'lobby') {
        const nextTeam: TeamId = player.team === 'alpha' ? 'bravo' : 'alpha';
        const maxPerTeam = room.maxPlayers / 2;
        let count = 0;
        for (const p of room.players.values()) {
          if (p.team === nextTeam) count++;
        }
        if (count < maxPerTeam) {
          player.team = nextTeam;
          broadcastRoom(room, { type: 'room_state', room: serializeRoom(room) });
        }
        return;
      }

      if (type === 'set_ready' && room.status === 'lobby') {
        player.ready = Boolean(data.ready);
        broadcastRoom(room, { type: 'room_state', room: serializeRoom(room) });
        return;
      }

      if (type === 'update_loadout') {
        player.characterId = String(data.characterId || player.characterId);
        player.skinId = String(data.skinId || player.skinId);
        player.weaponId = String(data.weaponId || player.weaponId);
        broadcastRoom(room, { type: 'room_state', room: serializeRoom(room) });
        return;
      }

      if (type === 'start_match' && room.hostId === player.id && room.status === 'lobby') {
        if (room.players.size < 2) {
          sendJson(ws, {
            type: 'error',
            message: 'يتطلب بدء المباراة لاعبين حقيقيين على الأقل (شارك رمز الغرفة مع صديق أو انتظر لاعباً آخر).',
          });
          return;
        }

        // Ensure both teams have at least 1 player if imbalanced
        let alphaCount = 0;
        let bravoCount = 0;
        for (const p of room.players.values()) {
          if (p.team === 'alpha') alphaCount++;
          else bravoCount++;
        }
        if (alphaCount === 0 || bravoCount === 0) {
          let i = 0;
          for (const p of room.players.values()) {
            p.team = i % 2 === 0 ? 'alpha' : 'bravo';
            i++;
          }
        }

        room.status = 'playing';
        room.alphaScore = 0;
        room.bravoScore = 0;
        room.winner = null;
        room.timeRemainingSec = room.mode === 'tdm' ? 300 : 360;
        room.capturePoints = createInitialCapturePoints();
        room.lastDomTickMs = Date.now();

        let idx = 0;
        for (const p of room.players.values()) {
          const sp = getSpawnForPlayer(p.team, idx++);
          p.hp = 100;
          p.alive = true;
          p.kills = 0;
          p.deaths = 0;
          p.assists = 0;
          p.score = 0;
          p.x = sp.x;
          p.y = sp.y;
          p.z = sp.z;
          p.yaw = sp.yaw;
          p.pitch = 0;
          p.medkits = 2;
        }

        broadcastRoom(room, { type: 'match_started', room: serializeRoom(room) });
        return;
      }

      if (type === 'return_lobby' && room.hostId === player.id) {
        room.status = 'lobby';
        room.winner = null;
        for (const p of room.players.values()) {
          p.ready = p.isHost;
          p.hp = 100;
          p.alive = true;
        }
        broadcastRoom(room, { type: 'room_state', room: serializeRoom(room) });
        return;
      }

      if (type === 'chat_message') {
        const text = String(data.text || '').trim().slice(0, 180);
        if (!text) return;
        broadcastRoom(room, {
          type: 'chat_message',
          message: {
            id: makeId('msg'),
            senderId: player.id,
            senderName: player.callsign,
            team: player.team,
            text,
            timestamp: Date.now(),
          },
        });
        return;
      }

      if (room.status !== 'playing') return;

      if (type === 'player_state' && player.alive) {
        player.x = Number(data.x) || 0;
        player.y = Number(data.y) || 0;
        player.z = Number(data.z) || 0;
        player.yaw = Number(data.yaw) || 0;
        player.pitch = Number(data.pitch) || 0;
        player.crouching = Boolean(data.crouching);
        player.moving = Boolean(data.moving);
        if (typeof data.weaponId === 'string') {
          player.weaponId = data.weaponId;
        }
        broadcastRoom(
          room,
          {
            type: 'player_delta',
            id: player.id,
            x: player.x,
            y: player.y,
            z: player.z,
            yaw: player.yaw,
            pitch: player.pitch,
            crouching: player.crouching,
            moving: player.moving,
            weaponId: player.weaponId,
          },
          player.id
        );
        return;
      }

      if (type === 'player_fire' && player.alive) {
        broadcastRoom(
          room,
          {
            type: 'remote_fire',
            playerId: player.id,
            weaponId: String(data.weaponId || player.weaponId),
            ox: Number(data.ox) || player.x,
            oy: Number(data.oy) || player.y + 1.5,
            oz: Number(data.oz) || player.z,
            dx: Number(data.dx) || 0,
            dy: Number(data.dy) || 0,
            dz: Number(data.dz) || -1,
          },
          player.id
        );
        return;
      }

      if (type === 'player_heal' && player.alive) {
        if (player.medkits > 0 && player.hp > 0 && player.hp < 100) {
          player.medkits -= 1;
          player.hp = Math.min(100, player.hp + 50);
          broadcastRoom(room, { type: 'room_state', room: serializeRoom(room) });
        }
        return;
      }

      if (type === 'hit_claim' && player.alive) {
        const targetId = String(data.targetId || '');
        const victim = room.players.get(targetId);
        if (!victim || !victim.alive || victim.team === player.team) return;

        const now = Date.now();
        const weaponSpec = WEAPON_DAMAGE_TABLE[player.weaponId] || WEAPON_DAMAGE_TABLE.m4a1;
        if (now - player.lastFireMs < weaponSpec.minIntervalMs * 0.75) return;
        player.lastFireMs = now;

        const headshot = Boolean(data.headshot);
        const dmg = Math.round(weaponSpec.dmg * (headshot ? 1.8 : 1.0));
        victim.hp = Math.max(0, victim.hp - dmg);

        sendJson(victim.ws, {
          type: 'took_damage',
          hp: victim.hp,
          fromId: player.id,
          fromX: player.x,
          fromZ: player.z,
        });

        if (victim.hp <= 0) {
          victim.alive = false;
          victim.deaths += 1;
          victim.respawnAtMs = now + 3500;
          player.kills += 1;
          player.score += headshot ? 150 : 100;

          if (room.mode === 'tdm') {
            if (player.team === 'alpha') room.alphaScore += 1;
            else room.bravoScore += 1;
          }

          broadcastRoom(room, {
            type: 'kill_event',
            killerId: player.id,
            killerName: player.callsign,
            killerTeam: player.team,
            victimId: victim.id,
            victimName: victim.callsign,
            victimTeam: victim.team,
            weaponId: player.weaponId,
            headshot,
          });

          if (room.mode === 'tdm' && (room.alphaScore >= room.scoreLimit || room.bravoScore >= room.scoreLimit)) {
            room.status = 'ended';
            room.winner = room.alphaScore >= room.scoreLimit ? 'alpha' : 'bravo';
            broadcastRoom(room, { type: 'match_ended', room: serializeRoom(room) });
            return;
          }
        }

        broadcastRoom(room, { type: 'room_state', room: serializeRoom(room) });
      }
    });

    ws.on('close', () => {
      removePlayerFromRoom(ws);
      socketToMeta.delete(ws);
    });
  });

  // Server simulation tick (200ms) for timers, respawns, and Domination capture points
  setInterval(() => {
    const now = Date.now();
    for (const room of rooms.values()) {
      if (room.status !== 'playing') continue;

      let stateChanged = false;
      room.timeRemainingSec -= 0.2;

      // Respawns
      let spawnIdx = 0;
      for (const p of room.players.values()) {
        if (!p.alive && p.respawnAtMs > 0 && now >= p.respawnAtMs) {
          const sp = getSpawnForPlayer(p.team, spawnIdx++);
          p.alive = true;
          p.hp = 100;
          p.x = sp.x;
          p.y = sp.y;
          p.z = sp.z;
          p.yaw = sp.yaw;
          p.medkits = 2;
          p.respawnAtMs = 0;
          sendJson(p.ws, { type: 'respawned', x: p.x, y: p.y, z: p.z, yaw: p.yaw });
          stateChanged = true;
        }
      }

      // Domination capture points
      if (room.mode === 'domination') {
        for (const cp of room.capturePoints) {
          let alphaNear = 0;
          let bravoNear = 0;
          for (const p of room.players.values()) {
            if (!p.alive) continue;
            const dx = p.x - cp.x;
            const dz = p.z - cp.z;
            if (dx * dx + dz * dz <= 42) {
              if (p.team === 'alpha') alphaNear++;
              else bravoNear++;
            }
          }
          const diff = alphaNear - bravoNear;
          if (diff !== 0) {
            cp.capturingTeam = diff > 0 ? 'alpha' : 'bravo';
            cp.progress = Math.max(-100, Math.min(100, cp.progress + diff * 8));
            if (cp.progress >= 100) cp.owner = 'alpha';
            else if (cp.progress <= -100) cp.owner = 'bravo';
            else if (Math.abs(cp.progress) < 15) cp.owner = 'neutral';
            stateChanged = true;
          } else if (cp.capturingTeam !== null) {
            cp.capturingTeam = null;
            stateChanged = true;
          }
        }

        if (now - room.lastDomTickMs >= 1200) {
          room.lastDomTickMs = now;
          for (const cp of room.capturePoints) {
            if (cp.owner === 'alpha') room.alphaScore += 1;
            else if (cp.owner === 'bravo') room.bravoScore += 1;
          }
          stateChanged = true;
          if (room.alphaScore >= room.scoreLimit || room.bravoScore >= room.scoreLimit) {
            room.status = 'ended';
            room.winner = room.alphaScore >= room.bravoScore ? 'alpha' : 'bravo';
            broadcastRoom(room, { type: 'match_ended', room: serializeRoom(room) });
            continue;
          }
        }
      }

      // Match timeout
      if (room.timeRemainingSec <= 0) {
        room.status = 'ended';
        room.winner =
          room.alphaScore > room.bravoScore
            ? 'alpha'
            : room.bravoScore > room.alphaScore
              ? 'bravo'
              : 'draw';
        broadcastRoom(room, { type: 'match_ended', room: serializeRoom(room) });
        continue;
      }

      if (stateChanged || Math.floor(room.timeRemainingSec * 5) % 5 === 0) {
        broadcastRoom(room, { type: 'room_state', room: serializeRoom(room) });
      }
    }
  }, 200);

  // REST Endpoints
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, rooms: rooms.size });
  });

  app.get('/api/rooms', (_req, res) => {
    const publicRooms = Array.from(rooms.values())
      .filter((r) => !r.isPrivate && r.status !== 'ended')
      .map((r) => ({
        roomId: r.roomId,
        code: r.code,
        name: r.name,
        mode: r.mode,
        teamSize: r.teamSize,
        playerCount: r.players.size,
        maxPlayers: r.maxPlayers,
        status: r.status,
      }));
    res.json({ rooms: publicRooms });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexPath = path.join(distDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  const port = Number(process.env.PORT) || 3000;
  server.listen(port, '0.0.0.0', () => {
    console.log(`Iron Vanguard server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
