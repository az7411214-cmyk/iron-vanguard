# Security Specification — Iron Vanguard Firestore Rules

## 1. Data Invariants
1. A `PlayerProfile` at `/users/{userId}` can only be read, created, or updated by the verified owner (`request.auth.uid == userId`). No user listing is allowed.
2. `userId` and `createdAt` on `/users/{userId}` are immutable after creation.
3. All numeric progression fields (`xp`, `credits`, `rank`, `unlockedMission`, `kills`, `deaths`, `wins`) must stay within strict non-negative bounds (`unlockedMission` between 1 and 10).
4. Array fields (`completedMissions`, `unlockedWeapons`, `unlockedSkins`) are strictly size-bounded (`<= 20`) and validated at index 0 when non-empty.
5. A `MissionRecord` at `/users/{userId}/missionRecords/{missionId}` enforces the Master Gate: parent `/users/{userId}` must exist and belong to `request.auth.uid`.
6. A `LeaderboardEntry` at `/leaderboard/{userId}` contains zero PII (only `callsign`, `rank`, `xp`, `kills`, `wins`, `isPublic`), can only be written by `request.auth.uid == userId`, and `allow list` strictly enforces `resource.data.isPublic == true`.

## 2. Dirty Dozen Attack Payloads (Expected: PERMISSION_DENIED)
1. **Unauthenticated Read/Write**: Read `/users/userA` with `auth == null`.
2. **Cross-Owner Profile Read**: Read `/users/userB` as `userA`.
3. **Identity Spoofing on Create**: Create `/users/userA` with `userId: "userB"`.
4. **Ghost Field Injection**: Create `/users/userA` with extra key `isAdmin: true`.
5. **Path ID Poisoning**: Create `/users/invalid$id!` or 1500-char ID.
6. **Immutable `createdAt` Tampering**: Update `/users/userA` changing `createdAt`.
7. **Timestamp Forgery**: Create `/users/userA` with client-supplied past `createdAt`.
8. **Out-of-Bounds Mission Unlock**: Update `/users/userA` with `unlockedMission: 99`.
9. **Array Flood (DoW)**: Update `/users/userA` with 500 strings in `unlockedWeapons`.
10. **Orphaned Subcollection Write**: Create `/users/userA/missionRecords/m1` when `/users/userA` does not exist.
11. **Unverified Email Bypass**: Write `/users/userA` when `email_verified == false`.
12. **Leaderboard Forgery for Another User**: Update `/leaderboard/userB` as `userA`.
