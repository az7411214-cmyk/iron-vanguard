/**
 * Dirty Dozen Security Specification Cases for Iron Vanguard Firestore Rules.
 * Intended for verification against Firebase Rules Emulator when running emulator tests.
 */
export interface DirtyDozenCase {
  id: number;
  name: string;
  path: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  auth: { uid: string; email_verified: boolean } | null;
  payload?: Record<string, unknown>;
  expected: 'PERMISSION_DENIED';
}

export const DIRTY_DOZEN_CASES: DirtyDozenCase[] = [
  {
    id: 1,
    name: 'Unauthenticated Read',
    path: 'users/userA',
    operation: 'get',
    auth: null,
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Cross-Owner Profile Read',
    path: 'users/userB',
    operation: 'get',
    auth: { uid: 'userA', email_verified: true },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Identity Spoofing on Create',
    path: 'users/userA',
    operation: 'create',
    auth: { uid: 'userA', email_verified: true },
    payload: { userId: 'userB', callsign: 'Rogue' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Ghost Field Injection',
    path: 'users/userA',
    operation: 'create',
    auth: { uid: 'userA', email_verified: true },
    payload: { userId: 'userA', isAdmin: true },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Path ID Poisoning',
    path: 'users/invalid$id!',
    operation: 'create',
    auth: { uid: 'invalid$id!', email_verified: true },
    payload: { userId: 'invalid$id!' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Immutable createdAt Tampering',
    path: 'users/userA',
    operation: 'update',
    auth: { uid: 'userA', email_verified: true },
    payload: { createdAt: '2020-01-01T00:00:00Z' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'Client Timestamp Forgery',
    path: 'users/userA',
    operation: 'create',
    auth: { uid: 'userA', email_verified: true },
    payload: { userId: 'userA', createdAt: '1999-01-01T00:00:00Z' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Out-of-Bounds Mission Unlock',
    path: 'users/userA',
    operation: 'update',
    auth: { uid: 'userA', email_verified: true },
    payload: { unlockedMission: 99 },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Array Flood Denial-of-Wallet',
    path: 'users/userA',
    operation: 'update',
    auth: { uid: 'userA', email_verified: true },
    payload: { unlockedWeapons: Array.from({ length: 50 }, (_, i) => `w${i}`) },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Orphaned Subcollection Write',
    path: 'users/noParent/missionRecords/m1',
    operation: 'create',
    auth: { uid: 'noParent', email_verified: true },
    payload: { userId: 'noParent', missionId: 1, stars: 3, bestScore: 1000, bestTimeSec: 90 },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Unverified Email Bypass',
    path: 'users/userA',
    operation: 'create',
    auth: { uid: 'userA', email_verified: false },
    payload: { userId: 'userA' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Leaderboard Forgery for Another User',
    path: 'leaderboard/userB',
    operation: 'update',
    auth: { uid: 'userA', email_verified: true },
    payload: { userId: 'userB', xp: 999999, isPublic: true },
    expected: 'PERMISSION_DENIED',
  },
];
