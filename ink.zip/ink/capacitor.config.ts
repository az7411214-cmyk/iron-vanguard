import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ironvanguard.game',
  appName: 'Iron Vanguard',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
};

export default config;
