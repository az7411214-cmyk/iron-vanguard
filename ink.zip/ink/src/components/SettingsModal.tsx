import React from 'react';
import { Maximize2, Minimize2, Move, Volume2, VolumeX, X } from 'lucide-react';
import { HUD_PRESETS, type HudPresetId } from '../game/hudLayout';
import type { FpsCap, GameSettings, GraphicsQuality } from '../game/types';

interface SettingsModalProps {
  settings: GameSettings;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onChange: (next: GameSettings) => void;
  onOpenLayoutEditor: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  isFullscreen,
  onToggleFullscreen,
  onChange,
  onOpenLayoutEditor,
  onClose,
}) => {
  const update = <K extends keyof GameSettings>(key: K, val: GameSettings[K]) => {
    onChange({ ...settings, [key]: val });
  };

  return (
    <div className="absolute inset-0 z-40 bg-black/80 flex items-center justify-center p-3">
      <div className="max-w-xl w-full max-h-[92%] bg-[#0d131c] border border-slate-700 rounded-2xl flex flex-col overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
          <h2 className="text-sm sm:text-base font-black text-white">إعدادات الرسومات والصوت والتحكم</h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-3 sm:p-4 space-y-3.5 overflow-y-auto tactical-scroll text-xs">
          {/* HUD Button Layout Customization */}
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/35 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="font-bold text-amber-300 text-xs">تخصيص أماكن وحجم الأزرار (HUD)</div>
                <div className="text-[10px] text-slate-300">
                  اسحب أزرار الحركة والإطلاق والمهام لتضعها في المكان المناسب لك
                </div>
              </div>
              <button
                type="button"
                onClick={onOpenLayoutEditor}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[11px] cursor-pointer"
              >
                <Move className="w-3.5 h-3.5" />
                <span>تغيير أماكن الأزرار</span>
              </button>
            </div>
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[10px] text-slate-400">توزيع سريع:</span>
              {(Object.keys(HUD_PRESETS) as HudPresetId[]).map((pid) => (
                <button
                  key={pid}
                  type="button"
                  onClick={() => update('hudLayout', HUD_PRESETS[pid].layout)}
                  className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] text-slate-200 cursor-pointer"
                >
                  {HUD_PRESETS[pid].labelAr}
                </button>
              ))}
            </div>
          </div>

          {/* Graphics Preset */}
          <div>
            <label className="block text-[11px] font-bold text-slate-300 mb-1.5">جودة الرسومات 3D</label>
            <div className="grid grid-cols-4 gap-2">
              {(
                [
                  { id: 'ultra', label: 'Ultra' },
                  { id: 'high', label: 'High' },
                  { id: 'medium', label: 'Medium' },
                  { id: 'low', label: 'Low' },
                ] as Array<{ id: GraphicsQuality; label: string }>
              ).map((g) => (
                <button
                  key={g.id}
                  type="button"
                  onClick={() => update('graphics', g.id)}
                  className={`py-2 rounded-xl font-tactical font-bold text-xs cursor-pointer ${
                    settings.graphics === g.id
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>
          </div>

          {/* FPS Cap & Touch Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1.5">معدل الإطارات (FPS)</label>
              <div className="grid grid-cols-3 gap-1.5">
                {(
                  [
                    { val: 60, label: '60 FPS' },
                    { val: 120, label: '120 FPS' },
                    { val: 0, label: 'غير محدود' },
                  ] as Array<{ val: FpsCap; label: string }>
                ).map((f) => (
                  <button
                    key={f.val}
                    type="button"
                    onClick={() => update('fpsCap', f.val)}
                    className={`py-1.5 rounded-lg text-[11px] font-bold font-mono-num cursor-pointer ${
                      settings.fpsCap === f.val
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-900 border border-slate-800 text-slate-300'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1.5">أزرار اللمس على الشاشة</label>
              <div className="grid grid-cols-3 gap-1.5">
                {(
                  [
                    { val: 'auto', label: 'تلقائي' },
                    { val: 'always', label: 'مفعّل دائماً' },
                    { val: 'off', label: 'إيقاف' },
                  ] as const
                ).map((t) => (
                  <button
                    key={t.val}
                    type="button"
                    onClick={() => update('touchControls', t.val)}
                    className={`py-1.5 rounded-lg text-[11px] font-bold cursor-pointer ${
                      settings.touchControls === t.val
                        ? 'bg-sky-600 text-white'
                        : 'bg-slate-900 border border-slate-800 text-slate-300'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Sliders */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800">
              <div className="flex justify-between text-[11px] mb-1.5">
                <span className="text-slate-300">حساسية التصويب</span>
                <span className="font-mono-num text-amber-400">{settings.sensitivity.toFixed(1)}</span>
              </div>
              <input
                type="range"
                min={0.3}
                max={2.5}
                step={0.1}
                value={settings.sensitivity}
                onChange={(e) => update('sensitivity', Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800">
              <div className="flex justify-between text-[11px] mb-1.5">
                <span className="text-slate-300">مجال الرؤية (FOV)</span>
                <span className="font-mono-num text-amber-400">{settings.fov}°</span>
              </div>
              <input
                type="range"
                min={65}
                max={105}
                step={1}
                value={settings.fov}
                onChange={(e) => update('fov', Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>
          </div>

          {/* Audio */}
          <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-300">إعدادات الصوت</span>
              <button
                type="button"
                onClick={() => update('muted', !settings.muted)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 text-[11px] text-slate-200 cursor-pointer"
              >
                {settings.muted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
                <span>{settings.muted ? 'مكتوم' : 'الصوت مفعّل'}</span>
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-[11px]">
              <div>
                <div className="flex justify-between mb-1 text-slate-400">
                  <span>الصوت العام</span>
                  <span className="font-mono-num">{Math.round(settings.masterVolume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.masterVolume}
                  onChange={(e) => update('masterVolume', Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
              </div>
              <div>
                <div className="flex justify-between mb-1 text-slate-400">
                  <span>الأسلحة والمؤثرات</span>
                  <span className="font-mono-num">{Math.round(settings.sfxVolume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.sfxVolume}
                  onChange={(e) => update('sfxVolume', Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
              </div>
              <div>
                <div className="flex justify-between mb-1 text-slate-400">
                  <span>الأجواء والبيئة</span>
                  <span className="font-mono-num">{Math.round(settings.ambientVolume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.ambientVolume}
                  onChange={(e) => update('ambientVolume', Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Toggles */}
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            <label className="flex items-center gap-1.5 text-[11px] text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.showFps}
                onChange={(e) => update('showFps', e.target.checked)}
                className="w-3.5 h-3.5 accent-amber-500"
              />
              <span>إظهار عداد FPS</span>
            </label>
            <label className="flex items-center gap-1.5 text-[11px] text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.invertY}
                onChange={(e) => update('invertY', e.target.checked)}
                className="w-3.5 h-3.5 accent-amber-500"
              />
              <span>عكس المحور العمودي (Invert Y)</span>
            </label>
            <button
              type="button"
              onClick={onToggleFullscreen}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-bold text-white cursor-pointer"
            >
              {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              <span>{isFullscreen ? 'إلغاء ملء الشاشة' : 'تفعيل ملء الشاشة'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
