import React from 'react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'حدث خطأ غير متوقع.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="fixed inset-0 bg-[#080b0f] text-slate-100 flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-[#10161f] border border-red-500/40 rounded-xl p-6 space-y-4">
            <h2 className="text-xl font-bold text-red-400">تعذر إكمال العملية</h2>
            <p className="text-sm text-slate-300 break-words font-mono-num">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg cursor-pointer"
            >
              إعادة تشغيل اللعبة
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
