import React, { useEffect, useState } from 'react';
import {
  ArrowLeftRight,
  ArrowRight,
  CheckCircle2,
  Copy,
  Globe,
  Lock,
  Play,
  RefreshCw,
  Search,
  Send,
  Users,
} from 'lucide-react';
import type {
  ChatMessage,
  MultiplayerRoomState,
  PlayerProfile,
  TeamSizeMode,
} from '../game/types';
import { mpClient } from '../services/multiplayerClient';

interface PublicRoomSummary {
  roomId: string;
  code: string;
  name: string;
  mode: 'tdm' | 'domination';
  teamSize: TeamSizeMode;
  playerCount: number;
  maxPlayers: number;
  status: 'lobby' | 'playing' | 'ended';
}

interface MultiplayerLobbyProps {
  profile: PlayerProfile;
  connected: boolean;
  localPlayerId: string | null;
  room: MultiplayerRoomState | null;
  chatMessages: ChatMessage[];
  errorMsg: string | null;
  onClearError: () => void;
  onBack: () => void;
}

export const MultiplayerLobby: React.FC<MultiplayerLobbyProps> = ({
  profile,
  connected,
  localPlayerId,
  room,
  chatMessages,
  errorMsg,
  onClearError,
  onBack,
}) => {
  const [mode, setMode] = useState<'tdm' | 'domination'>('tdm');
  const [teamSize, setTeamSize] = useState<TeamSizeMode>('2v2');
  const [mapId, setMapId] = useState<'urban_arena' | 'harbor_arena'>('urban_arena');
  const [roomName, setRoomName] = useState('معركة الطليعة');
  const [isPrivate, setIsPrivate] = useState(false);
  const [joinCode, setJoinCode] = useState('');
  const [publicRooms, setPublicRooms] = useState<PublicRoomSummary[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [copied, setCopied] = useState(false);

  const fetchRooms = async () => {
    try {
      const res = await fetch('/api/rooms');
      if (res.ok) {
        const data = (await res.json()) as { rooms: PublicRoomSummary[] };
        setPublicRooms(data.rooms || []);
      }
    } catch {
      // ignore network transient
    }
  };

  useEffect(() => {
    mpClient.connect();
    void fetchRooms();
    const interval = window.setInterval(() => {
      if (!room) void fetchRooms();
    }, 4000);

    // Check URL ?room=CODE invite parameter
    const params = new URLSearchParams(window.location.search);
    const inviteCode = params.get('room');
    if (inviteCode && !room) {
      setJoinCode(inviteCode.toUpperCase());
    }
    return () => window.clearInterval(interval);
  }, [room]);

  const handleCopyInvite = () => {
    if (!room) return;
    const url = `${window.location.origin}?room=${room.code}`;
    void navigator.clipboard?.writeText(url);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    mpClient.sendChat(chatInput.trim());
    setChatInput('');
  };

  const me = room?.players.find((p) => p.id === localPlayerId);
  const isHost = Boolean(room && localPlayerId && room.hostId === localPlayerId);

  return (
    <div className="absolute inset-0 z-30 bg-[#080c12]/96 flex flex-col p-3 sm:p-4 overflow-hidden">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5 shrink-0">
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => {
              if (room) mpClient.leaveRoom();
              onBack();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
          >
            <ArrowRight className="w-3.5 h-3.5" />
            <span>{room ? 'مغادرة' : 'القائمة'}</span>
          </button>
          <div>
            <h2 className="text-sm sm:text-base font-black text-white">طور اللعب الجماعي أونلاين (حقيقي)</h2>
            <p className="text-[10px] text-slate-400">
              خوادم WebSocket مباشرة — لاعبون حقيقيون فقط بدون أي بوتات وهمية
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono-num">
          <span className={connected ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
            {connected ? 'متصل بالخادم' : 'جاري الاتصال...'}
          </span>
        </div>
      </div>

      {errorMsg && (
        <div className="mt-3 p-3 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-xs sm:text-sm flex items-center justify-between">
          <span>{errorMsg}</span>
          <button type="button" onClick={onClearError} className="px-2 py-1 rounded bg-red-800/60 text-white cursor-pointer">
            إغلاق
          </button>
        </div>
      )}

      {/* Not in a Room: Matchmaking, Create Room, Join by Code, Public Browser */}
      {!room ? (
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-5 pt-4 min-h-0 overflow-y-auto tactical-scroll">
          {/* Quick Match & Create Room */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-5 rounded-2xl bg-[#0e151f] border border-slate-800 space-y-4">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <Search className="w-4 h-4" />
                <span>البحث السريع عن مباراة (Matchmaking)</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1.5">طور اللعب</label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setMode('tdm')}
                      className={`py-2 rounded-lg text-xs font-bold cursor-pointer ${
                        mode === 'tdm' ? 'bg-amber-500 text-slate-950' : 'bg-slate-900 text-slate-300 border border-slate-800'
                      }`}
                    >
                      مباراة الموت
                    </button>
                    <button
                      type="button"
                      onClick={() => setMode('domination')}
                      className={`py-2 rounded-lg text-xs font-bold cursor-pointer ${
                        mode === 'domination' ? 'bg-amber-500 text-slate-950' : 'bg-slate-900 text-slate-300 border border-slate-800'
                      }`}
                    >
                      السيطرة
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1.5">حجم الفرق</label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setTeamSize('2v2')}
                      className={`py-2 rounded-lg text-xs font-bold font-mono-num cursor-pointer ${
                        teamSize === '2v2' ? 'bg-emerald-500 text-slate-950' : 'bg-slate-900 text-slate-300 border border-slate-800'
                      }`}
                    >
                      2 ضد 2
                    </button>
                    <button
                      type="button"
                      onClick={() => setTeamSize('5v5')}
                      className={`py-2 rounded-lg text-xs font-bold font-mono-num cursor-pointer ${
                        teamSize === '5v5' ? 'bg-emerald-500 text-slate-950' : 'bg-slate-900 text-slate-300 border border-slate-800'
                      }`}
                    >
                      5 ضد 5
                    </button>
                  </div>
                </div>
              </div>

              <button
                type="button"
                disabled={!connected}
                onClick={() =>
                  mpClient.quickMatch({
                    mode,
                    teamSize,
                    callsign: profile.callsign,
                    characterId: profile.selectedCharacter,
                    skinId: profile.selectedSkin,
                    weaponId: profile.primaryWeapon,
                  })
                }
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-black text-sm cursor-pointer"
              >
                ابحث عن مباراة أونلاين ({mode === 'tdm' ? 'TDM' : 'Domination'} · {teamSize})
              </button>
            </div>

            {/* Create Custom / Private Room */}
            <div className="p-5 rounded-2xl bg-[#0e151f] border border-slate-800 space-y-4">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <Users className="w-4 h-4" />
                <span>إنشاء غرفة جديدة (عامة أو خاصة للأصدقاء)</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">اسم الغرفة</label>
                  <input
                    type="text"
                    value={roomName}
                    maxLength={28}
                    onChange={(e) => setRoomName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">الخريطة</label>
                  <select
                    value={mapId}
                    onChange={(e) => setMapId(e.target.value as 'urban_arena' | 'harbor_arena')}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white outline-none"
                  >
                    <option value="urban_arena">ساحة المدينة المدمرة</option>
                    <option value="harbor_arena">ساحة الميناء الشرقي</option>
                  </select>
                </div>
              </div>

              <label className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isPrivate}
                  onChange={(e) => setIsPrivate(e.target.checked)}
                  className="w-4 h-4 accent-amber-500"
                />
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>غرفة خاصة (دعوة الأصدقاء برمز الغرفة فقط)</span>
              </label>

              <button
                type="button"
                disabled={!connected}
                onClick={() =>
                  mpClient.createRoom({
                    roomName,
                    isPrivate,
                    mode,
                    teamSize,
                    mapId,
                    callsign: profile.callsign,
                    characterId: profile.selectedCharacter,
                    skinId: profile.selectedSkin,
                    weaponId: profile.primaryWeapon,
                  })
                }
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800 text-slate-950 font-black text-sm cursor-pointer"
              >
                إنشاء الغرفة واستلام رمز الدعوة
              </button>
            </div>
          </div>

          {/* Join by Code & Public Rooms List */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-5 rounded-2xl bg-[#0e151f] border border-slate-800 space-y-3">
              <div className="text-sm font-bold text-white">الانضمام برمز غرفة خاصة</div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={joinCode}
                  maxLength={10}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  placeholder="أدخل رمز الغرفة (مثال: A7K2P9)"
                  className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white font-mono-num uppercase outline-none"
                />
                <button
                  type="button"
                  disabled={!connected || !joinCode.trim()}
                  onClick={() =>
                    mpClient.joinRoom({
                      code: joinCode.trim(),
                      callsign: profile.callsign,
                      characterId: profile.selectedCharacter,
                      skinId: profile.selectedSkin,
                      weaponId: profile.primaryWeapon,
                    })
                  }
                  className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:bg-slate-800 text-white font-bold text-sm cursor-pointer"
                >
                  انضمام
                </button>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-[#0e151f] border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-bold text-white">
                  <Globe className="w-4 h-4 text-sky-400" />
                  <span>الغرف العامة المفتوحة الآن</span>
                </div>
                <button
                  type="button"
                  onClick={() => void fetchRooms()}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>

              {publicRooms.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400 border border-dashed border-slate-800 rounded-xl">
                  لا توجد غرف عامة نشطة حالياً. أنشئ غرفة جديدة أو استخدم البحث السريع لبدء غرفة واستقبال اللاعبين.
                </div>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto tactical-scroll">
                  {publicRooms.map((r) => (
                    <div
                      key={r.roomId}
                      className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3"
                    >
                      <div>
                        <div className="font-bold text-sm text-white">{r.name}</div>
                        <div className="text-xs text-slate-400 font-mono-num">
                          {r.mode === 'tdm' ? 'TDM' : 'Domination'} · {r.teamSize} · رمز {r.code}
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-mono-num text-emerald-400 font-bold">
                          {r.playerCount}/{r.maxPlayers}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            mpClient.joinRoom({
                              code: r.code,
                              callsign: profile.callsign,
                              characterId: profile.selectedCharacter,
                              skinId: profile.selectedSkin,
                              weaponId: profile.primaryWeapon,
                            })
                          }
                          className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer"
                        >
                          دخول
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Active Room Lobby */
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-5 pt-4 min-h-0">
          {/* Teams & Controls */}
          <div className="lg:col-span-8 flex flex-col gap-4 min-h-0 overflow-y-auto tactical-scroll">
            <div className="p-4 rounded-2xl bg-[#0e151f] border border-slate-700/70 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-black text-white">{room.name}</span>
                  <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-xs font-mono-num">
                    {room.mode === 'tdm' ? 'مباراة الموت' : 'السيطرة على النقاط'} · {room.teamSize}
                  </span>
                </div>
                <div className="text-xs text-slate-400 font-mono-num mt-1">
                  رمز الدعوة: <strong className="text-white">{room.code}</strong> · اللاعبون المتصلون: {room.players.length}/{room.maxPlayers}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyInvite}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-sky-300 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? 'تم نسخ الرابط!' : 'نسخ رابط الدعوة'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => mpClient.switchTeam()}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 cursor-pointer"
                >
                  <ArrowLeftRight className="w-3.5 h-3.5" />
                  <span>تبديل الفريق</span>
                </button>
              </div>
            </div>

            {/* Alpha vs Bravo Rosters */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(['alpha', 'bravo'] as const).map((teamKey) => {
                const members = room.players.filter((p) => p.team === teamKey);
                const isAlpha = teamKey === 'alpha';
                return (
                  <div
                    key={teamKey}
                    className={`p-4 rounded-2xl border ${
                      isAlpha
                        ? 'bg-sky-950/25 border-sky-500/40'
                        : 'bg-red-950/25 border-red-500/40'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className={`font-black text-sm ${isAlpha ? 'text-sky-400' : 'text-red-400'}`}>
                        {isAlpha ? 'فريق ألفا (ALPHA)' : 'فريق برافو (BRAVO)'}
                      </span>
                      <span className="text-xs font-mono-num text-slate-400">
                        {members.length} / {room.maxPlayers / 2}
                      </span>
                    </div>
                    <div className="space-y-2">
                      {members.length === 0 ? (
                        <div className="p-3 rounded-lg bg-slate-900/60 text-xs text-slate-500 text-center">
                          بانتظار انضمام لاعب حقيقي...
                        </div>
                      ) : (
                        members.map((m) => (
                          <div
                            key={m.id}
                            className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs"
                          >
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white">{m.callsign}</span>
                              {m.isHost && (
                                <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px]">
                                  مضيف
                                </span>
                              )}
                            </div>
                            <span className={m.ready ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
                              {m.ready ? 'جاهز' : 'غير جاهز'}
                            </span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-[#0e151f] border border-slate-800">
              <button
                type="button"
                onClick={() => mpClient.setReady(!(me?.ready ?? false))}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-sm cursor-pointer ${
                  me?.ready
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{me?.ready ? 'أنا جاهز للقتال' : 'تأكيد الجاهزية'}</span>
              </button>

              {isHost ? (
                <button
                  type="button"
                  onClick={() => mpClient.startMatch()}
                  className="flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-slate-950" />
                  <span>بدء المباراة ({room.players.length}/2 حد أدنى)</span>
                </button>
              ) : (
                <div className="text-xs text-slate-400">بانتظار المضيف لبدء المباراة...</div>
              )}
            </div>
          </div>

          {/* Live Room Chat */}
          <div className="lg:col-span-4 rounded-2xl bg-[#0e151f] border border-slate-800 flex flex-col min-h-[260px]">
            <div className="p-3.5 border-b border-slate-800 font-bold text-sm text-white">
              محادثة الغرفة المباشرة
            </div>
            <div className="flex-1 p-3 space-y-2 overflow-y-auto tactical-scroll text-xs">
              {chatMessages.map((msg) => (
                <div key={msg.id} className="leading-relaxed">
                  <span
                    className={
                      msg.team === 'system'
                        ? 'text-amber-400 font-bold'
                        : msg.team === 'alpha'
                          ? 'text-sky-400 font-bold'
                          : 'text-red-400 font-bold'
                    }
                  >
                    {msg.senderName}:{' '}
                  </span>
                  <span className="text-slate-200">{msg.text}</span>
                </div>
              ))}
            </div>
            <form onSubmit={handleSendChat} className="p-3 border-t border-slate-800 flex gap-2">
              <input
                type="text"
                value={chatInput}
                maxLength={160}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="اكتب رسالة للاعبين..."
                className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white outline-none"
              />
              <button
                type="submit"
                className="p-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
