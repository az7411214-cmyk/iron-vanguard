import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Lock, Play, ShieldAlert, Star } from 'lucide-react';
import { CAMPAIGN_MISSIONS } from '../game/missions';
import type { MissionDef, PlayerProfile } from '../game/types';
import { WEAPONS } from '../game/weapons';

interface CampaignSelectProps {
  profile: PlayerProfile;
  onStartMission: (mission: MissionDef) => void;
  onBack: () => void;
}

export const CampaignSelect: React.FC<CampaignSelectProps> = ({
  profile,
  onStartMission,
  onBack,
}) => {
  const [selectedId, setSelectedId] = useState<number>(
    Math.min(10, Math.max(1, profile.unlockedMission))
  );

  const selected = CAMPAIGN_MISSIONS.find((m) => m.id === selectedId) || CAMPAIGN_MISSIONS[0];
  const isUnlocked = selected.id <= profile.unlockedMission;
  const isCompleted = profile.completedMissions.includes(selected.id);
  const record = profile.missionRecords?.[selected.id];

  return (
    <div className="absolute inset-0 z-30 bg-[#080c12]/94 flex flex-col p-3 sm:p-4 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 shrink-0">
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
          >
            <ArrowRight className="w-3.5 h-3.5" />
            <span>القائمة</span>
          </button>
          <div>
            <h2 className="text-sm sm:text-base font-black text-white">حملة العمليات العسكرية (10 مراحل)</h2>
            <p className="text-[10px] text-slate-400">اختر المهمة، راجع الأهداف، وانطلق إلى ساحة المعركة</p>
          </div>
        </div>
        <div className="flex items-center gap-2 font-mono-num text-[11px] bg-slate-900 border border-slate-700/70 px-2.5 py-1 rounded-lg">
          <span className="text-slate-400">التقدم:</span>
          <span className="text-amber-400 font-bold">{profile.completedMissions.length}/10</span>
        </div>
      </div>

      {/* Main Split */}
      <div className="flex-1 grid grid-cols-12 gap-3 pt-3 min-h-0">
        {/* 10 Missions Compact List */}
        <div className="col-span-7 overflow-y-auto tactical-scroll pl-1 space-y-1.5">
          {CAMPAIGN_MISSIONS.map((m) => {
            const unlocked = m.id <= profile.unlockedMission;
            const completed = profile.completedMissions.includes(m.id);
            const rec = profile.missionRecords?.[m.id];
            const active = m.id === selected.id;

            return (
              <button
                key={m.id}
                type="button"
                onClick={() => setSelectedId(m.id)}
                className={`w-full text-right px-2.5 py-2 rounded-lg border transition-colors flex items-center justify-between gap-2 cursor-pointer ${
                  active
                    ? 'bg-amber-500/15 border-amber-500 text-white'
                    : unlocked
                      ? 'bg-[#0e151f] hover:bg-[#141d2b] border-slate-800 text-slate-200'
                      : 'bg-[#0a0e15] border-slate-800/50 text-slate-500'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-8 h-8 rounded-md flex items-center justify-center font-tactical font-bold text-xs border shrink-0 ${
                      completed
                        ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                        : unlocked
                          ? 'bg-amber-500/15 border-amber-500/40 text-amber-400'
                          : 'bg-slate-900 border-slate-800 text-slate-600'
                    }`}
                  >
                    {unlocked ? (completed ? <CheckCircle2 className="w-4 h-4" /> : m.id) : <Lock className="w-3.5 h-3.5" />}
                  </div>
                  <div className="min-w-0">
                    <div className="text-[9px] font-tactical text-amber-400/90 leading-none">{m.code}</div>
                    <div className="font-bold text-xs truncate mt-0.5">{m.titleAr} — {m.subtitleAr}</div>
                    <div className="text-[10px] text-slate-400 truncate">{m.locationAr}</div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-0.5 shrink-0">
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3].map((s) => (
                      <Star
                        key={s}
                        className={`w-3 h-3 ${
                          (rec?.stars || 0) >= s ? 'text-amber-400 fill-amber-400' : 'text-slate-700'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-[9px] font-mono-num text-slate-400">
                    صعوبة {m.difficulty}/5
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Mission Tactical Briefing */}
        <div className="col-span-5 bg-[#0d141d] border border-slate-700/70 rounded-xl p-3 flex flex-col justify-between overflow-y-auto tactical-scroll">
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-tactical px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/30">
                {selected.code}
              </span>
              <span className="text-[10px] font-mono-num text-slate-400">
                {isCompleted ? 'مكتملة (قابلة للإعادة)' : isUnlocked ? 'متاحة للقتال' : 'مغلقة'}
              </span>
            </div>

            <div>
              <h3 className="text-base font-black text-white leading-tight">{selected.titleAr}</h3>
              <p className="text-xs text-amber-300 font-bold">{selected.subtitleAr}</p>
              <p className="text-[10px] text-slate-400 mt-0.5">{selected.locationAr}</p>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 text-[11px] text-slate-200 leading-relaxed">
              {selected.briefingAr}
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div className="p-2 rounded-lg bg-slate-900/70 border border-slate-800">
                <div className="text-slate-400">الهدف الرئيسي</div>
                <div className="font-bold text-white mt-0.5">{selected.objectiveLabelAr}</div>
              </div>
              <div className="p-2 rounded-lg bg-slate-900/70 border border-slate-800">
                <div className="text-slate-400">قوة العدو</div>
                <div className="font-bold text-red-400 font-mono-num mt-0.5">
                  {selected.enemyCount} مقاتل {selected.hasBoss ? '+ زعيم' : ''}
                </div>
              </div>
              <div className="p-2 rounded-lg bg-slate-900/70 border border-slate-800">
                <div className="text-slate-400">المكافآت</div>
                <div className="font-bold text-emerald-400 font-mono-num mt-0.5">
                  +{selected.rewardXp} XP · +{selected.rewardCredits}
                </div>
              </div>
              <div className="p-2 rounded-lg bg-slate-900/70 border border-slate-800">
                <div className="text-slate-400">فتح إضافي</div>
                <div className="font-bold text-amber-300 mt-0.5">
                  {selected.unlockWeapon
                    ? WEAPONS[selected.unlockWeapon].name
                    : selected.unlockSkin
                      ? 'تمويه تكتيكي'
                      : 'نقاط خبرة'}
                </div>
              </div>
            </div>

            {record && (
              <div className="flex items-center justify-between p-2 rounded-lg bg-emerald-950/30 border border-emerald-700/40 text-[10px]">
                <span className="text-emerald-300 font-bold">أفضل نتيجة</span>
                <span className="font-mono-num text-white">
                  {record.bestScore.toLocaleString()} · {record.bestTimeSec} ث
                </span>
              </div>
            )}
          </div>

          <div className="pt-3 mt-2 border-t border-slate-800">
            {isUnlocked ? (
              <button
                type="button"
                onClick={() => onStartMission(selected)}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs sm:text-sm cursor-pointer"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>{isCompleted ? 'إعادة لعب المرحلة' : 'بدء المهمة الآن'}</span>
              </button>
            ) : (
              <div className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-slate-800 text-slate-400 font-bold text-[11px]">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
                <span>أكمل المرحلة {selected.id - 1} أولاً</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
