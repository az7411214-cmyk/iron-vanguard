import React from 'react';
import {
  Crosshair,
  Globe,
  LogIn,
  LogOut,
  Maximize2,
  Minimize2,
  Settings,
  Shield,
  Swords,
  Trophy,
  User,
} from 'lucide-react';
import { CHARACTERS, SKINS } from '../game/characters';
import type { PlayerProfile } from '../game/types';
import { WEAPONS } from '../game/weapons';

interface TitleMenuProps {
  profile: PlayerProfile;
  authUser: { uid: string; email: string | null; displayName: string | null } | null;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onSignIn: () => void;
  onSignOut: () => void;
  onOpenCampaign: () => void;
  onOpenMultiplayer: () => void;
  onOpenArmory: () => void;
  onOpenLeaderboard: () => void;
  onOpenSettings: () => void;
}

export const TitleMenu: React.FC<TitleMenuProps> = ({
  profile,
  authUser,
  isFullscreen,
  onToggleFullscreen,
  onSignIn,
  onSignOut,
  onOpenCampaign,
  onOpenMultiplayer,
  onOpenArmory,
  onOpenLeaderboard,
  onOpenSettings,
}) => {
  const charDef = CHARACTERS[profile.selectedCharacter];
  const skinDef = SKINS[profile.selectedSkin];
  const weaponDef = WEAPONS[profile.primaryWeapon];

  return (
    <div className="absolute inset-0 z-20 flex flex-col justify-between p-3 sm:p-5 pointer-events-none">
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pointer-events-auto">
        <div className="flex items-center gap-2.5 bg-[#0c121a]/90 border border-slate-700/70 rounded-xl px-3 py-1.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <User className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-slate-100 text-xs">{profile.callsign}</span>
              <span className="text-[10px] font-mono-num px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                LVL {profile.rank}
              </span>
            </div>
            <div className="flex items-center gap-2.5 text-[10px] text-slate-400 font-mono-num">
              <span>XP: {profile.xp.toLocaleString()}</span>
              <span className="text-emerald-400 font-bold">رصيد: {profile.credits.toLocaleString()}</span>
              <span>مراحل: {profile.completedMissions.length}/10</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {authUser ? (
            <button
              type="button"
              onClick={onSignOut}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#0c121a]/90 hover:bg-slate-800 border border-slate-700/70 text-[11px] text-slate-200 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5 text-slate-400" />
              <span>حساب متزامن</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onSignIn}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/50 text-[11px] text-amber-300 font-bold cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>حفظ سحابي</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenLeaderboard}
            title="لوحة المتصدرين"
            className="p-2 rounded-lg bg-[#0c121a]/90 hover:bg-slate-800 border border-slate-700/70 text-amber-400 cursor-pointer"
          >
            <Trophy className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onOpenSettings}
            title="الإعدادات"
            className="p-2 rounded-lg bg-[#0c121a]/90 hover:bg-slate-800 border border-slate-700/70 text-slate-200 cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onToggleFullscreen}
            title="ملء الشاشة"
            className="p-2 rounded-lg bg-[#0c121a]/90 hover:bg-slate-800 border border-slate-700/70 text-slate-200 cursor-pointer"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Title & Action Column */}
      <div className="flex items-end justify-between my-auto">
        <div className="w-full max-w-[340px] space-y-3 pointer-events-auto bg-[#0a0f16]/88 border border-slate-700/70 rounded-2xl p-4">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
            <svg viewBox="0 0 64 64" className="w-10 h-10 shrink-0" aria-hidden="true">
              <polygon
                points="32,4 58,18 58,46 32,60 6,46 6,18"
                fill="#111822"
                stroke="#f59e0b"
                strokeWidth="2.5"
              />
              <polygon points="32,12 48,22 48,42 32,52 16,42 16,22" fill="#1e293b" />
              <path d="M32 16 L38 30 L32 48 L26 30 Z" fill="#f59e0b" />
              <path d="M18 32 L46 32" stroke="#f8fafc" strokeWidth="2.2" />
            </svg>
            <div>
              <div className="text-[9px] font-tactical tracking-[0.2em] text-amber-400 uppercase">
                TACTICAL COMBAT OPERATIONS
              </div>
              <h1 className="text-xl font-black text-white tracking-tight leading-tight">
                الطليعة الحديدية
              </h1>
              <p className="text-[10px] text-slate-400 font-tactical tracking-wider">IRON VANGUARD 3D</p>
            </div>
          </div>

          <div className="space-y-2">
            <button
              type="button"
              onClick={onOpenCampaign}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <Swords className="w-4 h-4" />
                <div className="text-right">
                  <div className="text-xs sm:text-sm leading-tight">طور القصة — 10 مهمات</div>
                  <div className="text-[10px] font-semibold text-slate-900/80">
                    المرحلة المتاحة: {profile.unlockedMission} / 10
                  </div>
                </div>
              </div>
              <span className="font-tactical text-[11px] px-2 py-0.5 rounded bg-slate-950/15">CAMPAIGN</span>
            </button>

            <button
              type="button"
              onClick={onOpenMultiplayer}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <Globe className="w-4 h-4" />
                <div className="text-right">
                  <div className="text-xs sm:text-sm leading-tight">اللعب الجماعي أونلاين</div>
                  <div className="text-[10px] font-normal text-emerald-100">
                    2 ضد 2 · 5 ضد 5 · غرف خاصة
                  </div>
                </div>
              </div>
              <span className="font-tactical text-[11px] px-2 py-0.5 rounded bg-black/20">ONLINE</span>
            </button>

            <button
              type="button"
              onClick={onOpenArmory}
              className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-600/60 text-slate-100 font-bold transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <Shield className="w-4 h-4 text-amber-400" />
                <div className="text-right">
                  <div className="text-xs leading-tight">الترسانة والشخصيات والمظاهر</div>
                  <div className="text-[10px] text-slate-400">
                    {weaponDef.name} · {charDef.nameAr} · {skinDef.nameAr}
                  </div>
                </div>
              </div>
              <Crosshair className="w-3.5 h-3.5 text-slate-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Control Hint */}
      <div className="flex items-center justify-center pointer-events-none">
        <div className="bg-[#0a0f16]/85 border border-slate-800 rounded-lg px-3 py-1 text-[10px] text-slate-300 font-mono-num">
          WASD حركة · الماوس تصويب · زر أيسر إطلاق · زر أيمن منظار · R تلقيم · G قنبلة · E تفاعل · Esc إيقاف
        </div>
      </div>
    </div>
  );
};
