import React, { useRef, useState } from 'react';
import { Check, Crosshair, HeartPulse, Move, Pause, RotateCcw, Shield, X, Zap } from 'lucide-react';
import {
  DEFAULT_HUD_LAYOUT,
  HUD_CONTROL_IDS,
  HUD_CONTROL_META,
  HUD_PRESETS,
  resolveHudLayout,
  type HudPresetId,
} from '../game/hudLayout';
import type { HudControlId, HudLayoutConfig } from '../game/types';

interface HudLayoutEditorProps {
  initialLayout?: Partial<HudLayoutConfig>;
  onSave: (layout: HudLayoutConfig) => void;
  onCancel: () => void;
}

export const HudLayoutEditor: React.FC<HudLayoutEditorProps> = ({
  initialLayout,
  onSave,
  onCancel,
}) => {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const [layout, setLayout] = useState<HudLayoutConfig>(() => resolveHudLayout(initialLayout));
  const [selectedId, setSelectedId] = useState<HudControlId>('fire');
  const dragRef = useRef<{
    id: HudControlId;
    pointerId: number;
    offsetX: number;
    offsetY: number;
  } | null>(null);

  const selectedPlacement = layout[selectedId];
  const selectedMeta = HUD_CONTROL_META[selectedId];

  const handlePointerDown = (id: HudControlId, e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    e.preventDefault();
    setSelectedId(id);
    const stage = stageRef.current;
    if (!stage) return;
    const rect = stage.getBoundingClientRect();
    const curX = (layout[id].x / 100) * rect.width;
    const curY = (layout[id].y / 100) * rect.height;
    const ptrX = e.clientX - rect.left;
    const ptrY = e.clientY - rect.top;
    dragRef.current = {
      id,
      pointerId: e.pointerId,
      offsetX: curX - ptrX,
      offsetY: curY - ptrY,
    };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (id: HudControlId, e: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.id !== id || drag.pointerId !== e.pointerId) return;
    const stage = stageRef.current;
    if (!stage) return;
    const rect = stage.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    const nextPxX = e.clientX - rect.left + drag.offsetX;
    const nextPxY = e.clientY - rect.top + drag.offsetY;
    const pctX = Math.max(3, Math.min(97, Math.round((nextPxX / rect.width) * 1000) / 10));
    const pctY = Math.max(4, Math.min(96, Math.round((nextPxY / rect.height) * 1000) / 10));

    setLayout((prev) => ({
      ...prev,
      [id]: { ...prev[id], x: pctX, y: pctY },
    }));
  };

  const handlePointerUp = (id: HudControlId, e: React.PointerEvent<HTMLDivElement>) => {
    if (dragRef.current?.id === id && dragRef.current.pointerId === e.pointerId) {
      dragRef.current = null;
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
        // ignore
      }
    }
  };

  const updateSelectedProp = (key: 'scale' | 'opacity', val: number) => {
    setLayout((prev) => ({
      ...prev,
      [selectedId]: { ...prev[selectedId], [key]: val },
    }));
  };

  const applyPreset = (presetId: HudPresetId) => {
    setLayout(resolveHudLayout(HUD_PRESETS[presetId].layout));
  };

  const renderPreviewWidget = (id: HudControlId) => {
    switch (id) {
      case 'joystick':
        return (
          <div className="w-20 h-20 rounded-full bg-slate-900/80 border-2 border-slate-400/70 flex items-center justify-center relative">
            <div className="w-8 h-8 rounded-full bg-amber-500/85 border border-white/60" />
            <span className="absolute -bottom-4 text-[9px] font-bold text-amber-300 whitespace-nowrap">
              الحركة
            </span>
          </div>
        );
      case 'fire':
        return (
          <div className="w-14 h-14 rounded-full bg-red-600/85 border-2 border-red-300 flex flex-col items-center justify-center text-white">
            <Crosshair className="w-5 h-5" />
            <span className="text-[8px] font-bold">إطلاق</span>
          </div>
        );
      case 'ability':
        return (
          <div className="w-11 h-11 rounded-full bg-slate-900/90 border-2 border-amber-400 text-amber-300 text-[9px] font-black flex flex-col items-center justify-center">
            <Zap className="w-3.5 h-3.5" />
            <span>قدرة</span>
          </div>
        );
      case 'heal':
        return (
          <div className="w-11 h-11 rounded-full bg-emerald-950/90 border-2 border-emerald-400 text-emerald-300 text-[9px] font-black flex flex-col items-center justify-center">
            <HeartPulse className="w-3.5 h-3.5" />
            <span>هيل</span>
          </div>
        );
      case 'ads':
      case 'reload':
      case 'jump':
      case 'crouch':
      case 'grenade':
      case 'swap':
      case 'interact':
        return (
          <div className="w-10 h-10 rounded-lg bg-slate-900/85 border border-slate-500 text-white text-[9px] font-bold flex items-center justify-center text-center leading-tight px-1">
            {HUD_CONTROL_META[id].labelAr}
          </div>
        );
      case 'pause':
        return (
          <div className="px-2 py-1 rounded-lg bg-slate-900/90 border border-slate-600 text-white flex items-center gap-1 text-[9px] font-bold">
            <Pause className="w-3 h-3" />
            <span>إيقاف</span>
          </div>
        );
      case 'radar':
        return (
          <div className="w-16 h-16 rounded-full bg-slate-900/90 border-2 border-slate-500 flex items-center justify-center text-[9px] text-emerald-300 font-bold">
            رادار
          </div>
        );
      case 'objective':
        return (
          <div className="px-2.5 py-1 rounded-lg bg-slate-900/90 border border-amber-500/50 text-[9px] text-amber-300 font-bold whitespace-nowrap">
            مربع المهام (0/10)
          </div>
        );
      case 'vitals':
        return (
          <div className="px-2.5 py-1.5 rounded-lg bg-slate-900/90 border border-emerald-500/50 text-[9px] text-emerald-300 font-bold flex items-center gap-1 whitespace-nowrap">
            <Shield className="w-3 h-3" />
            <span>HP 100</span>
          </div>
        );
      case 'ammo':
        return (
          <div className="px-2.5 py-1.5 rounded-lg bg-slate-900/90 border border-slate-600 text-[9px] text-white font-mono-num font-bold whitespace-nowrap">
            30 / 150
          </div>
        );
    }
  };

  return (
    <div
      ref={stageRef}
      className="absolute inset-0 z-50 bg-[#070b11]/88 select-none overflow-hidden"
      style={{
        backgroundImage:
          'linear-gradient(to right, rgba(148,163,184,0.08) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,163,184,0.08) 1px, transparent 1px)',
        backgroundSize: '32px 32px',
      }}
    >
      {/* Compact Center-Top Control Bar */}
      <div className="absolute top-2 left-1/2 -translate-x-1/2 z-30 bg-[#0d141e]/96 border border-slate-700 rounded-xl px-3 py-2 flex flex-wrap items-center justify-center gap-2 max-w-[96%] shadow-2xl">
        <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-400">
          <Move className="w-3.5 h-3.5" />
          <span>اسحب أي زر لتغيير مكانه ({selectedMeta.labelAr})</span>
        </div>

        <div className="flex items-center gap-2 text-[10px] text-slate-300 bg-slate-900/90 border border-slate-800 rounded-lg px-2 py-1">
          <span>الحجم {Math.round(selectedPlacement.scale * 100)}%</span>
          <input
            type="range"
            min={0.65}
            max={1.45}
            step={0.05}
            value={selectedPlacement.scale}
            onChange={(e) => updateSelectedProp('scale', Number(e.target.value))}
            className="w-16 accent-amber-500 cursor-pointer"
          />
          <span>شفافية {Math.round(selectedPlacement.opacity * 100)}%</span>
          <input
            type="range"
            min={0.4}
            max={1}
            step={0.05}
            value={selectedPlacement.opacity}
            onChange={(e) => updateSelectedProp('opacity', Number(e.target.value))}
            className="w-14 accent-sky-400 cursor-pointer"
          />
        </div>

        <div className="flex items-center gap-1">
          {(Object.keys(HUD_PRESETS) as HudPresetId[]).map((pid) => (
            <button
              key={pid}
              type="button"
              onClick={() => applyPreset(pid)}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-slate-200 cursor-pointer"
            >
              {pid === 'default' ? 'افتراضي' : pid === 'left_hand' ? 'معكوس' : '4 أصابع'}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setLayout(resolveHudLayout(DEFAULT_HUD_LAYOUT))}
            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-amber-300 cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>إعادة</span>
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-slate-300 cursor-pointer"
          >
            <X className="w-3 h-3" />
            <span>إلغاء</span>
          </button>
          <button
            type="button"
            onClick={() => onSave(layout)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-[10px] font-black text-white cursor-pointer"
          >
            <Check className="w-3 h-3" />
            <span>حفظ الأماكن</span>
          </button>
        </div>
      </div>

      {/* Draggable Buttons & HUD Clusters */}
      {HUD_CONTROL_IDS.map((id) => {
        const pos = layout[id];
        const isSelected = selectedId === id;
        return (
          <div
            key={id}
            onPointerDown={(e) => handlePointerDown(id, e)}
            onPointerMove={(e) => handlePointerMove(id, e)}
            onPointerUp={(e) => handlePointerUp(id, e)}
            onPointerCancel={(e) => handlePointerUp(id, e)}
            style={{
              left: `${pos.x}%`,
              top: `${pos.y}%`,
              opacity: pos.opacity,
              transform: `translate(-50%, -50%) scale(${pos.scale})`,
              touchAction: 'none',
            }}
            className={`absolute cursor-grab active:cursor-grabbing rounded-xl p-1 ${
              isSelected
                ? 'z-20 ring-2 ring-amber-400 bg-amber-500/10'
                : 'z-10 ring-1 ring-slate-600/60 hover:ring-slate-400'
            }`}
          >
            {renderPreviewWidget(id)}
          </div>
        );
      })}
    </div>
  );
};
