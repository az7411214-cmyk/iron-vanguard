import React, { useState } from 'react';
import { ArrowRight, Check, Lock, Shield, UserCheck, Volume2, Zap } from 'lucide-react';
import { audioEngine } from '../engine/AudioEngine';
import { CHARACTER_LIST, SKIN_LIST } from '../game/characters';
import type { CharacterId, PlayerProfile, SkinId, WeaponId } from '../game/types';
import { PRIMARY_WEAPON_LIST } from '../game/weapons';

interface ArmoryScreenProps {
  profile: PlayerProfile;
  onEquipWeapon: (weaponId: WeaponId) => void;
  onUnlockWeapon: (weaponId: WeaponId, cost: number) => void;
  onEquipCharacter: (characterId: CharacterId) => void;
  onUnlockCharacter: (characterId: CharacterId, cost: number) => void;
  onEquipSkin: (skinId: SkinId) => void;
  onUnlockSkin: (skinId: SkinId, cost: number) => void;
  onUpdateCallsign: (callsign: string) => void;
  onBack: () => void;
}

export const ArmoryScreen: React.FC<ArmoryScreenProps> = ({
  profile,
  onEquipWeapon,
  onUnlockWeapon,
  onEquipCharacter,
  onUnlockCharacter,
  onEquipSkin,
  onUnlockSkin,
  onUpdateCallsign,
  onBack,
}) => {
  const [tab, setTab] = useState<'weapons' | 'operators' | 'skins'>('weapons');
  const [callsignInput, setCallsignInput] = useState(profile.callsign);

  return (
    <div className="absolute inset-0 z-30 bg-[#080c12]/95 flex flex-col p-3 sm:p-4 overflow-hidden">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5 shrink-0">
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
          >
            <ArrowRight className="w-3.5 h-3.5" />
            <span>رجوع</span>
          </button>
          <div>
            <h2 className="text-sm sm:text-base font-black text-white">الترسانة وتخصيص المقاتل</h2>
            <p className="text-[10px] text-slate-400">افتح الأسلحة والشخصيات والتمويهات باستخدام رصيد القتال</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1">
            <input
              type="text"
              value={callsignInput}
              maxLength={20}
              onChange={(e) => setCallsignInput(e.target.value)}
              placeholder="الاسم الحربي"
              className="bg-transparent text-xs text-white outline-none w-24 sm:w-28"
            />
            <button
              type="button"
              onClick={() => onUpdateCallsign(callsignInput)}
              className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 text-[10px] font-bold cursor-pointer"
            >
              حفظ
            </button>
          </div>
          <div className="px-2.5 py-1.5 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-mono-num text-xs font-bold">
            رصيدك: {profile.credits.toLocaleString()}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 py-2.5 shrink-0">
        {[
          { id: 'weapons', label: 'الأسلحة الرئيسية (7)' },
          { id: 'operators', label: 'الشخصيات والقدرات (8)' },
          { id: 'skins', label: 'المظاهر والتمويه (5)' },
        ].map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id as typeof tab)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
              tab === t.id
                ? 'bg-amber-500 text-slate-950'
                : 'bg-slate-900 text-slate-300 border border-slate-800 hover:bg-slate-800'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto tactical-scroll">
        {tab === 'weapons' && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 pb-6">
            {PRIMARY_WEAPON_LIST.map((w) => {
              const unlocked = profile.unlockedWeapons.includes(w.id);
              const equipped = profile.primaryWeapon === w.id;
              const canAfford = profile.credits >= w.unlockCost;
              return (
                <div
                  key={w.id}
                  className={`p-4 rounded-xl border flex flex-col justify-between gap-4 ${
                    equipped
                      ? 'bg-amber-500/10 border-amber-500'
                      : 'bg-[#0d141d] border-slate-800'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[11px] font-tactical text-amber-400 uppercase">{w.categoryAr}</span>
                        <h3 className="text-lg font-black text-white">{w.name}</h3>
                        <p className="text-xs text-slate-400">{w.nameAr}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          audioEngine.unlock();
                          audioEngine.playWeaponFire(w.id, 1);
                        }}
                        title="اختبار صوت السلاح"
                        className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 cursor-pointer"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{w.descriptionAr}</p>

                    <div className="space-y-1.5 text-xs font-mono-num">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">الضرر</span>
                        <span className="text-white">{w.damage * (w.pellets || 1)}</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-800 rounded overflow-hidden">
                        <div className="h-full bg-amber-400" style={{ width: `${Math.min(100, (w.damage * (w.pellets || 1)) / 1.4)}%` }} />
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-slate-400">معدل الإطلاق / المخزن</span>
                        <span className="text-slate-200">{w.fireRateRpm} RPM · {w.magSize} طلقة</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    {equipped ? (
                      <div className="w-full py-2.5 rounded-lg bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 font-bold text-sm flex items-center justify-center gap-2">
                        <Check className="w-4 h-4" />
                        <span>مجهّز حالياً</span>
                      </div>
                    ) : unlocked ? (
                      <button
                        type="button"
                        onClick={() => onEquipWeapon(w.id)}
                        className="w-full py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm cursor-pointer"
                      >
                        تجهيز السلاح
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled={!canAfford}
                        onClick={() => onUnlockWeapon(w.id, w.unlockCost)}
                        className={`w-full py-2.5 rounded-lg font-bold text-sm flex items-center justify-center gap-2 ${
                          canAfford
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        <Lock className="w-4 h-4" />
                        <span>فتح مقابل {w.unlockCost} رصيد</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === 'operators' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-6">
            {CHARACTER_LIST.map((ch) => {
              const isOwned =
                ch.unlockCost === 0 ||
                profile.unlockedSkins.includes(`char_${ch.id}` as SkinId) ||
                profile.selectedCharacter === ch.id;
              const equipped = profile.selectedCharacter === ch.id;
              return (
                <div
                  key={ch.id}
                  className={`p-5 rounded-xl border flex flex-col justify-between gap-4 ${
                    equipped ? 'bg-amber-500/10 border-amber-500' : 'bg-[#0d141d] border-slate-800'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs text-amber-400 font-bold">{ch.roleAr}</span>
                        <h3 className="text-xl font-black text-white">{ch.nameAr}</h3>
                      </div>
                      <Shield className="w-7 h-7 text-amber-400" />
                    </div>
                    <p className="text-sm text-slate-300">{ch.descriptionAr}</p>
                    <div
                      className="p-2.5 rounded-lg bg-slate-900/90 border text-xs space-y-1"
                      style={{ borderColor: `${ch.abilityAccent}66` }}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-black flex items-center gap-1" style={{ color: ch.abilityAccent }}>
                          <Zap className="w-3.5 h-3.5" />
                          <span>قدرة خاصة: {ch.abilityNameAr}</span>
                        </span>
                        <span className="text-[10px] font-mono-num text-slate-400">
                          تهدئة {ch.abilityCooldownSec}ث
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">{ch.abilityDescAr}</p>
                    </div>
                    <div className="flex items-center gap-4 pt-1 text-xs font-mono-num">
                      <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-sky-300">
                        درع إضافي: +{ch.armorBonus}
                      </span>
                      <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-emerald-300">
                        السرعة: {Math.round(ch.speedMult * 100)}%
                      </span>
                    </div>
                  </div>

                  {equipped ? (
                    <div className="w-full py-2.5 rounded-lg bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 font-bold text-sm flex items-center justify-center gap-2">
                      <UserCheck className="w-4 h-4" />
                      <span>الشخصية النشطة</span>
                    </div>
                  ) : isOwned ? (
                    <button
                      type="button"
                      onClick={() => onEquipCharacter(ch.id)}
                      className="w-full py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm cursor-pointer"
                    >
                      اختيار الشخصية
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={profile.credits < ch.unlockCost}
                      onClick={() => onUnlockCharacter(ch.id, ch.unlockCost)}
                      className={`w-full py-2.5 rounded-lg font-bold text-sm ${
                        profile.credits >= ch.unlockCost
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      فتح مقابل {ch.unlockCost} رصيد
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {tab === 'skins' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pb-6">
            {SKIN_LIST.map((sk) => {
              const unlocked = profile.unlockedSkins.includes(sk.id);
              const equipped = profile.selectedSkin === sk.id;
              const canAfford = profile.credits >= sk.unlockCost;
              return (
                <div
                  key={sk.id}
                  className={`p-4 rounded-xl border flex flex-col justify-between gap-4 ${
                    equipped ? 'bg-amber-500/10 border-amber-500' : 'bg-[#0d141d] border-slate-800'
                  }`}
                >
                  <div className="space-y-3">
                    <div
                      className="w-full h-24 rounded-lg border border-slate-700"
                      style={{ background: sk.swatchCss }}
                    />
                    <h3 className="text-base font-extrabold text-white">{sk.nameAr}</h3>
                  </div>

                  {equipped ? (
                    <div className="w-full py-2.5 rounded-lg bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 font-bold text-sm flex items-center justify-center gap-2">
                      <Check className="w-4 h-4" />
                      <span>مظهر مفعّل</span>
                    </div>
                  ) : unlocked ? (
                    <button
                      type="button"
                      onClick={() => onEquipSkin(sk.id)}
                      className="w-full py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm cursor-pointer"
                    >
                      تفعيل التمويه
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={!canAfford}
                      onClick={() => onUnlockSkin(sk.id, sk.unlockCost)}
                      className={`w-full py-2.5 rounded-lg font-bold text-sm ${
                        canAfford
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      شراء مقابل {sk.unlockCost} رصيد
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
