import React, { useEffect, useRef, useState } from 'react';
import {
  Crosshair,
  HeartPulse,
  MessageSquare,
  Move,
  Pause,
  Play,
  RotateCcw,
  Send,
  Shield,
  Star,
  Trophy,
  Zap,
} from 'lucide-react';
import type { GameEngine, MissionResultPayload } from '../engine/GameEngine';
import { resolveHudLayout } from '../game/hudLayout';
import type {
  ChatMessage,
  GameMode,
  GameSettings,
  HudControlId,
  HudSnapshot,
  KillFeedItem,
  MissionDef,
  MultiplayerRoomState,
} from '../game/types';
import { WEAPONS } from '../game/weapons';
import { mpClient } from '../services/multiplayerClient';

interface GameHUDProps {
  engineRef: React.RefObject<GameEngine | null>;
  mode: GameMode;
  mission: MissionDef | null;
  room: MultiplayerRoomState | null;
  localPlayerId: string | null;
  hud: HudSnapshot;
  settings: GameSettings;
  paused: boolean;
  missionResult: MissionResultPayload | null;
  killFeed: KillFeedItem[];
  chatMessages: ChatMessage[];
  onResume: () => void;
  onPause: () => void;
  onOpenSettings: () => void;
  onOpenLayoutEditor: () => void;
  onRestartMission: () => void;
  onNextMission: () => void;
  onExitToMenu: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  engineRef,
  mode,
  mission,
  room,
  localPlayerId,
  hud,
  settings,
  paused,
  missionResult,
  killFeed,
  chatMessages,
  onResume,
  onPause,
  onOpenSettings,
  onOpenLayoutEditor,
  onRestartMission,
  onNextMission,
  onExitToMenu,
}) => {
  const [showScoreboard, setShowScoreboard] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatText, setChatText] = useState('');
  const touchStageRef = useRef<HTMLDivElement | null>(null);
  const joyKnobRef = useRef<HTMLDivElement | null>(null);
  const joyTouchIdRef = useRef<number | null>(null);
  const joyMouseDown = useRef(false);
  const joyCenterRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const activeTouchesRef = useRef<
    Map<
      number,
      {
        role: HudControlId | 'look';
        x: number;
        y: number;
      }
    >
  >(new Map());
  const mouseDragActive = useRef<{ x: number; y: number; isFire?: boolean } | null>(null);
  const lastTouchTimeRef = useRef(0);
  const weaponIdRef = useRef(hud.weaponId);
  weaponIdRef.current = hud.weaponId;

  const layout = resolveHudLayout(settings.hudLayout);

  const isTouchDevice =
    settings.touchControls === 'always' ||
    (settings.touchControls === 'auto' &&
      typeof window !== 'undefined' &&
      ('ontouchstart' in window || navigator.maxTouchPoints > 0));

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Tab' && mode !== 'campaign') {
        e.preventDefault();
        setShowScoreboard(true);
      }
      if (e.code === 'KeyT' && mode !== 'campaign' && !chatOpen) {
        e.preventDefault();
        engineRef.current?.exitPointerLock();
        setChatOpen(true);
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Tab') {
        setShowScoreboard(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [mode, chatOpen, engineRef]);

  const weapon = WEAPONS[hud.weaponId];
  const isSniperAds = hud.ads && hud.weaponId === 'awm';

  const formatClock = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const posStyle = (id: HudControlId): React.CSSProperties => {
    const p = layout[id];
    return {
      left: `${p.x}%`,
      top: `${p.y}%`,
      opacity: p.opacity,
      transform: `translate(-50%, -50%) scale(${p.scale})`,
    };
  };

  const setJoyKnobVisual = (x: number, y: number) => {
    if (joyKnobRef.current) {
      joyKnobRef.current.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    }
  };

  const updateJoystickFromCoords = (clientX: number, clientY: number) => {
    const dx = clientX - joyCenterRef.current.x;
    const dy = clientY - joyCenterRef.current.y;
    const maxR = 30;
    const dist = Math.hypot(dx, dy);
    const clamped = dist > maxR ? maxR / dist : 1;
    const kx = dx * clamped;
    const ky = dy * clamped;
    setJoyKnobVisual(kx, ky);
    engineRef.current?.setTouchMove(kx / maxR, -ky / maxR);
  };

  const syncPressedButtonsVisual = () => {
    const stage = touchStageRef.current;
    if (!stage) return;
    const pressedRoles = new Set<string>();
    for (const v of activeTouchesRef.current.values()) {
      if (v.role !== 'look') pressedRoles.add(v.role);
    }
    const buttons = stage.querySelectorAll<HTMLElement>('[data-hud-btn]');
    buttons.forEach((el) => {
      const id = el.dataset.hudBtn;
      el.dataset.pressed = id && pressedRoles.has(id) ? 'true' : 'false';
    });
  };

  const syncTouchFireState = () => {
    const anyFire = Array.from(activeTouchesRef.current.values()).some((v) => v.role === 'fire');
    engineRef.current?.setTouchFire(anyFire);
  };

  const clearAllActiveTouches = () => {
    joyTouchIdRef.current = null;
    joyMouseDown.current = false;
    activeTouchesRef.current.clear();
    mouseDragActive.current = null;
    setJoyKnobVisual(0, 0);
    engineRef.current?.setTouchMove(0, 0);
    engineRef.current?.setTouchFire(false);
    syncPressedButtonsVisual();
  };

  const mpMatchEnded = mode !== 'campaign' && room?.status === 'ended';
  const touchGameplayActive =
    isTouchDevice && !hud.cinematicActive && !paused && !missionResult && !mpMatchEnded;

  // Reset active touch states if paused or match ends
  useEffect(() => {
    if (!touchGameplayActive) {
      clearAllActiveTouches();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [touchGameplayActive]);

  // Unified non-passive multi-touch manager: handles arbitrary simultaneous fingers (joystick + fire + jump + ads + ability + look)
  useEffect(() => {
    if (!touchGameplayActive) return;
    const stage = touchStageRef.current;
    if (!stage) return;

    const findTouchInList = (list: TouchList, id: number): Touch | null => {
      for (let i = 0; i < list.length; i++) {
        if (list[i].identifier === id) return list[i];
      }
      return null;
    };

    const resolveTouchRole = (t: Touch): { role: HudControlId | 'look'; el: HTMLElement | null } => {
      const buttons = stage.querySelectorAll<HTMLElement>('[data-hud-btn]');
      let joyEl: HTMLElement | null = null;
      // Check action buttons first (small +6px padding) so adjacent buttons aren't swallowed by joystick padding
      for (const el of buttons) {
        const id = el.dataset.hudBtn as HudControlId | undefined;
        if (!id) continue;
        if (id === 'joystick') {
          joyEl = el;
          continue;
        }
        const rect = el.getBoundingClientRect();
        if (
          t.clientX >= rect.left - 6 &&
          t.clientX <= rect.right + 6 &&
          t.clientY >= rect.top - 6 &&
          t.clientY <= rect.bottom + 6
        ) {
          return { role: id, el };
        }
      }

      if (joyEl) {
        const rect = joyEl.getBoundingClientRect();
        const pad = 16;
        if (
          t.clientX >= rect.left - pad &&
          t.clientX <= rect.right + pad &&
          t.clientY >= rect.top - pad &&
          t.clientY <= rect.bottom + pad
        ) {
          return { role: 'joystick', el: joyEl };
        }
      }

      return { role: 'look', el: null };
    };

    const onTouchStart = (e: TouchEvent) => {
      const targetEl = e.target instanceof Element ? e.target : null;
      if (targetEl?.closest('[data-ui-control="true"]')) {
        return;
      }
      e.preventDefault();
      lastTouchTimeRef.current = performance.now();

      // Reconcile stale joystick touch ID against currently live touches before assigning a new one
      if (joyTouchIdRef.current !== null && !findTouchInList(e.touches, joyTouchIdRef.current)) {
        joyTouchIdRef.current = null;
      }

      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        const { role, el } = resolveTouchRole(t);

        if (role === 'joystick') {
          if (joyTouchIdRef.current === null && el) {
            joyTouchIdRef.current = t.identifier;
            const rect = el.getBoundingClientRect();
            joyCenterRef.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
            activeTouchesRef.current.set(t.identifier, { role: 'joystick', x: t.clientX, y: t.clientY });
            updateJoystickFromCoords(t.clientX, t.clientY);
          } else {
            activeTouchesRef.current.set(t.identifier, { role: 'look', x: t.clientX, y: t.clientY });
          }
          continue;
        }

        activeTouchesRef.current.set(t.identifier, { role, x: t.clientX, y: t.clientY });

        if (role === 'fire') {
          syncTouchFireState();
        } else if (role === 'ads') {
          engineRef.current?.toggleAds();
        } else if (role === 'reload') {
          engineRef.current?.triggerReload();
        } else if (role === 'jump') {
          engineRef.current?.triggerJump();
        } else if (role === 'crouch') {
          engineRef.current?.triggerCrouch();
        } else if (role === 'grenade') {
          engineRef.current?.triggerGrenade();
        } else if (role === 'swap') {
          engineRef.current?.switchWeaponSlot(weaponIdRef.current === 'p226' ? 1 : 2);
        } else if (role === 'ability') {
          engineRef.current?.triggerAbility();
        } else if (role === 'heal') {
          engineRef.current?.triggerHeal();
        } else if (role === 'interact') {
          engineRef.current?.triggerInteract();
        }
      }

      syncPressedButtonsVisual();
    };

    const onTouchMove = (e: TouchEvent) => {
      if (activeTouchesRef.current.size === 0 && joyTouchIdRef.current === null) return;
      e.preventDefault();
      lastTouchTimeRef.current = performance.now();

      // Always sync active joystick finger directly from e.touches regardless of changedTouches batching
      if (joyTouchIdRef.current !== null) {
        const joyTouch = findTouchInList(e.touches, joyTouchIdRef.current);
        if (joyTouch) {
          updateJoystickFromCoords(joyTouch.clientX, joyTouch.clientY);
        }
      }

      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (t.identifier === joyTouchIdRef.current) continue;
        const entry = activeTouchesRef.current.get(t.identifier);
        if (!entry || entry.role === 'joystick') continue;

        const dx = t.clientX - entry.x;
        const dy = t.clientY - entry.y;
        entry.x = t.clientX;
        entry.y = t.clientY;
        if (dx !== 0 || dy !== 0) {
          engineRef.current?.addLookDelta(dx * 1.35, dy * 1.35);
        }
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (activeTouchesRef.current.size === 0 && joyTouchIdRef.current === null) return;
      e.preventDefault();
      lastTouchTimeRef.current = performance.now();

      let joyEnded = false;
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        activeTouchesRef.current.delete(t.identifier);
        if (joyTouchIdRef.current === t.identifier) {
          joyEnded = true;
        }
      }

      // Safety reconciliation against remaining live touches (e.touches already excludes ended touches)
      const liveIds = new Set<number>();
      for (let i = 0; i < e.touches.length; i++) {
        liveIds.add(e.touches[i].identifier);
      }
      for (const id of Array.from(activeTouchesRef.current.keys())) {
        if (!liveIds.has(id)) {
          activeTouchesRef.current.delete(id);
        }
      }

      if (joyTouchIdRef.current !== null && (joyEnded || !liveIds.has(joyTouchIdRef.current))) {
        joyTouchIdRef.current = null;
        setJoyKnobVisual(0, 0);
        engineRef.current?.setTouchMove(0, 0);
      } else if (joyTouchIdRef.current !== null) {
        const joyTouch = findTouchInList(e.touches, joyTouchIdRef.current);
        if (joyTouch) {
          updateJoystickFromCoords(joyTouch.clientX, joyTouch.clientY);
        }
      }

      syncTouchFireState();
      syncPressedButtonsVisual();
    };

    const onWindowBlur = () => clearAllActiveTouches();
    const onPreventGesture = (e: Event) => e.preventDefault();

    window.addEventListener('touchstart', onTouchStart, { passive: false });
    window.addEventListener('touchmove', onTouchMove, { passive: false });
    window.addEventListener('touchend', onTouchEnd, { passive: false });
    window.addEventListener('touchcancel', onTouchEnd, { passive: false });
    window.addEventListener('gesturestart', onPreventGesture, { passive: false });
    window.addEventListener('gesturechange', onPreventGesture, { passive: false });
    window.addEventListener('blur', onWindowBlur);

    return () => {
      window.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('touchcancel', onTouchEnd);
      window.removeEventListener('gesturestart', onPreventGesture);
      window.removeEventListener('gesturechange', onPreventGesture);
      window.removeEventListener('blur', onWindowBlur);
      clearAllActiveTouches();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [touchGameplayActive, engineRef]);

  // Mouse fallback for desktop preview when touchControls === 'always' (blocked while touching or within 5s of touch)
  const isMouseFallbackBlocked = () =>
    settings.touchControls !== 'always' ||
    activeTouchesRef.current.size > 0 ||
    joyTouchIdRef.current !== null ||
    performance.now() - lastTouchTimeRef.current < 5000;

  const startButtonMouseLook = (e: React.MouseEvent<HTMLElement>, isFire = false) => {
    if (isMouseFallbackBlocked()) return;
    e.stopPropagation();
    mouseDragActive.current = { x: e.clientX, y: e.clientY, isFire };
  };

  const moveButtonMouseLook = (e: React.MouseEvent<HTMLElement>) => {
    if (!mouseDragActive.current || isMouseFallbackBlocked()) return;
    e.stopPropagation();
    const dx = e.clientX - mouseDragActive.current.x;
    const dy = e.clientY - mouseDragActive.current.y;
    mouseDragActive.current.x = e.clientX;
    mouseDragActive.current.y = e.clientY;
    if (dx !== 0 || dy !== 0) {
      engineRef.current?.addLookDelta(dx * 1.35, dy * 1.35);
    }
  };

  const endButtonMouseLook = (e: React.MouseEvent<HTMLElement>, isFire = false) => {
    if (isMouseFallbackBlocked()) return;
    e.stopPropagation();
    mouseDragActive.current = null;
    if (isFire) engineRef.current?.setTouchFire(false);
  };

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (chatText.trim()) {
      mpClient.sendChat(chatText.trim());
      setChatText('');
    }
    setChatOpen(false);
  };

  return (
    <div className="absolute inset-0 z-20 pointer-events-none select-none overflow-hidden">
      {/* Special Ability Active Edge Glow */}
      {hud.abilityActiveSec > 0 && (
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            boxShadow: `inset 0 0 46px ${hud.abilityAccent}55`,
          }}
        />
      )}

      {/* Heal Success Emerald Glow */}
      {hud.healFlash > 0.05 && (
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            boxShadow: `inset 0 0 75px rgba(16, 185, 129, ${hud.healFlash * 0.55})`,
          }}
        />
      )}

      {/* Damage / Low HP Vignette */}
      {(hud.damageFlash > 0.05 || hud.lowHealth) && (
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            boxShadow: `inset 0 0 ${hud.lowHealth ? 95 : 65}px rgba(220, 38, 38, ${Math.max(
              hud.lowHealth ? 0.35 : 0,
              hud.damageFlash * 0.65
            )})`,
          }}
        />
      )}

      {/* AWM Sniper Scope Overlay */}
      {isSniperAds && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-[68%] aspect-square max-w-[360px] rounded-full border-[32px] border-black/95 relative">
            <div className="absolute inset-x-0 top-1/2 h-[1px] bg-black/80" />
            <div className="absolute inset-y-0 left-1/2 w-[1px] bg-black/80" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-red-500" />
          </div>
        </div>
      )}

      {/* Multiplayer Floating Nametags above 3D Characters */}
      {hud.nametags.map(
        (tag) =>
          tag.visible && (
            <div
              key={tag.id}
              className="absolute -translate-x-1/2 -translate-y-full flex flex-col items-center pointer-events-none z-10"
              style={{ left: `${tag.screenX}px`, top: `${tag.screenY}px` }}
            >
              <span
                className={`text-[10px] font-bold px-1 py-0.5 rounded bg-black/75 ${
                  tag.team === 'alpha' ? 'text-sky-300' : 'text-red-300'
                }`}
              >
                {tag.name}
              </span>
              <div className="w-10 h-1 bg-black/70 rounded overflow-hidden mt-0.5">
                <div
                  className={tag.team === 'alpha' ? 'h-full bg-sky-400' : 'h-full bg-red-400'}
                  style={{ width: `${Math.max(0, Math.min(100, tag.hp))}%` }}
                />
              </div>
            </div>
          )
      )}

      {/* Center Crosshair & Hitmarker */}
      {!hud.cinematicActive && !paused && !missionResult && !mpMatchEnded && hud.hp > 0 && !isSniperAds && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center z-10 pointer-events-none">
          <div className="relative w-6 h-6 flex items-center justify-center">
            <span className="w-1 h-1 rounded-full bg-white" />
            <span className="absolute top-0 w-[1.5px] h-1.5 bg-white/90" />
            <span className="absolute bottom-0 w-[1.5px] h-1.5 bg-white/90" />
            <span className="absolute left-0 h-[1.5px] w-1.5 bg-white/90" />
            <span className="absolute right-0 h-[1.5px] w-1.5 bg-white/90" />
          </div>

          {hud.hitmarkerKind !== 'none' && (
            <div
              className={`absolute w-5 h-5 ${
                hud.hitmarkerKind === 'kill'
                  ? 'text-red-500'
                  : hud.hitmarkerKind === 'headshot'
                    ? 'text-amber-400'
                    : 'text-white'
              }`}
            >
              <svg viewBox="0 0 24 24" className="w-full h-full stroke-current" strokeWidth="2.5">
                <line x1="4" y1="4" x2="9" y2="9" />
                <line x1="20" y1="4" x2="15" y2="9" />
                <line x1="4" y1="20" x2="9" y2="15" />
                <line x1="20" y1="20" x2="15" y2="15" />
              </svg>
            </div>
          )}
        </div>
      )}

      {/* Repositionable HUD Clusters */}
      {!hud.cinematicActive && (
        <>
          {/* Minimap Radar */}
          <div style={posStyle('radar')} className="absolute z-10 flex items-start gap-1.5 pointer-events-none">
            <div className="w-16 h-16 rounded-full bg-[#090e14]/90 border border-slate-600/80 relative overflow-hidden">
              <div className="absolute inset-0 border border-slate-700/40 rounded-full m-3" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-white rounded-full" />
              {hud.radarBlips.map((blip, idx) => {
                const dx = blip.x - hud.playerPos.x;
                const dz = blip.z - hud.playerPos.z;
                const c = Math.cos(-hud.playerPos.yaw);
                const s = Math.sin(-hud.playerPos.yaw);
                const rx = dx * c - dz * s;
                const rz = dx * s + dz * c;
                const scale = 0.68; // 64px diameter -> ~29px radius
                const px = Math.max(-28, Math.min(28, rx * scale));
                const py = Math.max(-28, Math.min(28, rz * scale));
                const color =
                  blip.kind === 'enemy'
                    ? 'bg-red-500'
                    : blip.kind === 'ally'
                      ? 'bg-sky-400'
                      : blip.kind === 'civilian'
                        ? 'bg-cyan-300'
                        : 'bg-amber-400';
                return (
                  <span
                    key={idx}
                    className={`absolute w-1.5 h-1.5 rounded-full ${color}`}
                    style={{
                      left: `${32 + px - 3}px`,
                      top: `${32 + py - 3}px`,
                    }}
                  />
                );
              })}
            </div>
            {settings.showFps && (
              <div className="px-1.5 py-0.5 rounded bg-[#090e14]/85 border border-slate-700 text-[9px] font-mono-num text-emerald-400 whitespace-nowrap">
                {hud.fps} FPS
              </div>
            )}
          </div>

          {/* Compact Mission Objective / Match Score */}
          <div
            style={posStyle('objective')}
            className="absolute z-10 bg-[#090e14]/85 border border-slate-700/80 rounded-lg px-2.5 py-1 text-center min-w-[140px] max-w-[235px] pointer-events-none"
          >
            {mode === 'campaign' ? (
              <>
                <div className="text-[10px] text-amber-400 font-bold leading-tight truncate">
                  {hud.objectiveTextAr}
                </div>
                <div className="flex items-center justify-center gap-2 mt-0.5 font-mono-num text-[10px]">
                  <span className="text-white font-bold">
                    {hud.objectiveProgress}/{hud.objectiveTarget}
                  </span>
                  {hud.wave !== undefined && (
                    <span className="text-sky-300">
                      موجة {hud.wave}/{hud.maxWaves}
                    </span>
                  )}
                  {hud.baseCoreHp !== undefined && (
                    <span className="text-emerald-400">قاعدة {hud.baseCoreHp}%</span>
                  )}
                  <span className="text-slate-400">{formatClock(hud.timerSec)}</span>
                </div>
              </>
            ) : (
              <div className="space-y-0.5">
                <div className="flex items-center justify-center gap-2.5 font-mono-num text-[11px] font-black">
                  <span className="text-sky-400">ألفا {hud.alphaScore ?? 0}</span>
                  <span className="text-slate-300 text-[10px]">{formatClock(hud.timerSec)}</span>
                  <span className="text-red-400">{hud.bravoScore ?? 0} برافو</span>
                </div>
                {hud.capturePoints && hud.capturePoints.length > 0 && (
                  <div className="flex items-center justify-center gap-1.5 text-[9px] font-mono-num">
                    {hud.capturePoints.map((cp) => (
                      <span
                        key={cp.id}
                        className={`px-1.5 py-0.5 rounded font-bold ${
                          cp.owner === 'alpha'
                            ? 'bg-sky-600 text-white'
                            : cp.owner === 'bravo'
                              ? 'bg-red-600 text-white'
                              : 'bg-slate-700 text-slate-200'
                        }`}
                      >
                        {cp.id}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Pause & Chat Cluster (sits above touch stage so taps work normally) */}
          <div data-ui-control="true" style={posStyle('pause')} className="absolute z-30 flex flex-col items-end gap-1.5 pointer-events-auto">
            <div className="flex items-center gap-1.5">
              {mode !== 'campaign' && (
                <button
                  type="button"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={() => {
                    engineRef.current?.exitPointerLock();
                    setChatOpen((v) => !v);
                  }}
                  className="p-1.5 rounded-lg bg-[#090e14]/90 border border-slate-700 text-slate-200 cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                type="button"
                onPointerDown={(e) => e.stopPropagation()}
                onClick={onPause}
                className="p-1.5 rounded-lg bg-[#090e14]/90 border border-slate-700 text-slate-200 cursor-pointer"
              >
                <Pause className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Kill Feed (Pinned top-right under pause) */}
          {killFeed.length > 0 && (
            <div className="absolute top-12 right-2.5 z-10 space-y-1 text-left pointer-events-none">
              {killFeed.slice(-3).map((kf) => (
                <div
                  key={kf.id}
                  className="px-2 py-0.5 rounded bg-[#090e14]/80 border border-slate-800 text-[10px] font-mono-num flex items-center gap-1"
                >
                  <span className={kf.killerTeam === 'alpha' ? 'text-sky-400' : 'text-red-400'}>
                    {kf.killerName}
                  </span>
                  <span className="text-slate-400">[{WEAPONS[kf.weaponId]?.name || kf.weaponId}]</span>
                  <span className={kf.victimTeam === 'alpha' ? 'text-sky-400' : 'text-red-400'}>
                    {kf.victimName}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* HP & Armor */}
          <div
            style={posStyle('vitals')}
            className="absolute z-10 bg-[#090e14]/88 border border-slate-700/80 rounded-lg px-2.5 py-1.5 min-w-[132px] space-y-1 pointer-events-none"
          >
            <div className="flex items-center justify-between text-[10px] font-mono-num">
              <span className="text-slate-400">HP</span>
              <span className={`font-black text-xs ${hud.lowHealth ? 'text-red-400' : 'text-white'}`}>
                {hud.hp}
              </span>
            </div>
            <div className="w-full h-1.5 bg-slate-800 rounded overflow-hidden">
              <div
                className={`h-full ${hud.lowHealth ? 'bg-red-500' : 'bg-emerald-500'}`}
                style={{ width: `${Math.max(0, Math.min(100, hud.hp))}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[9px] font-mono-num text-sky-300 gap-2">
              <span className="flex items-center gap-0.5">
                <Shield className="w-2.5 h-2.5" /> {hud.armor}
              </span>
              <span className="flex items-center gap-0.5 text-emerald-300 font-bold">
                <HeartPulse className="w-2.5 h-2.5" /> [H] {hud.medkits}
              </span>
              <span className="text-amber-300">طاقة {hud.stamina}%</span>
            </div>
          </div>

          {/* Weapon & Ammo */}
          <div
            style={posStyle('ammo')}
            className="absolute z-10 bg-[#090e14]/88 border border-slate-700/80 rounded-lg px-2.5 py-1.5 min-w-[138px] text-left space-y-0.5 pointer-events-none"
          >
            <div className="text-[9px] font-tactical text-amber-400 uppercase leading-none">
              {weapon.name}
            </div>
            {hud.reloading ? (
              <div className="text-[10px] font-bold text-amber-300 py-0.5">إعادة تلقيم...</div>
            ) : (
              <div className="font-mono-num flex items-baseline justify-end gap-1">
                <span className="text-lg font-black text-white leading-none">{hud.ammo}</span>
                <span className="text-[10px] text-slate-400">/ {hud.reserve}</span>
              </div>
            )}
            <div className="flex items-center justify-between text-[9px] font-mono-num text-slate-400 gap-2">
              <span>[1/2]</span>
              <span
                className="font-bold"
                style={{
                  color: hud.abilityActiveSec > 0 || hud.abilityCooldownSec <= 0 ? hud.abilityAccent : '#94a3b8',
                }}
              >
                [Q]{' '}
                {hud.abilityActiveSec > 0
                  ? `${hud.abilityActiveSec.toFixed(1)}s`
                  : hud.abilityCooldownSec > 0
                    ? `${Math.ceil(hud.abilityCooldownSec)}s`
                    : 'جاهزة'}
              </span>
              <span>[G] {hud.grenades}</span>
            </div>
          </div>
        </>
      )}

      {/* Active Ability Status Pill */}
      {hud.abilityActiveSec > 0 && !hud.cinematicActive && (
        <div
          className="absolute top-14 left-1/2 -translate-x-1/2 z-10 px-2.5 py-0.5 rounded-md bg-[#090e14]/90 border text-[10px] font-black flex items-center gap-1.5 pointer-events-none"
          style={{ borderColor: hud.abilityAccent, color: hud.abilityAccent }}
        >
          <Zap className="w-3 h-3" />
          <span>{hud.abilityNameAr}</span>
          <span className="font-mono-num text-white">{hud.abilityActiveSec.toFixed(1)}s</span>
        </div>
      )}

      {/* Healing Progress Bar */}
      {hud.healing && !hud.cinematicActive && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-10 w-36 bg-[#090e14]/90 border border-emerald-500/60 rounded-lg px-2.5 py-1.5 space-y-1 pointer-events-none">
          <div className="flex items-center justify-between text-[10px] font-black text-emerald-300">
            <span className="flex items-center gap-1">
              <HeartPulse className="w-3 h-3" />
              <span>جارٍ استخدام الهيل...</span>
            </span>
            <span className="font-mono-num text-white">{Math.round(hud.healProgress * 100)}%</span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded overflow-hidden">
            <div className="h-full bg-emerald-400" style={{ width: `${Math.round(hud.healProgress * 100)}%` }} />
          </div>
        </div>
      )}

      {/* Interact / Reload / Respawn Prompts */}
      {hud.interactPromptAr && !hud.cinematicActive && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-10 px-3 py-1 rounded-lg bg-amber-500 text-slate-950 font-black text-[11px]">
          {hud.interactPromptAr}
        </div>
      )}

      {hud.respawnTimerSec > 0 && mode !== 'campaign' && (
        <div className="absolute inset-0 z-20 bg-black/55 flex items-center justify-center">
          <div className="bg-[#0d131c] border border-red-500/50 rounded-xl px-5 py-3 text-center">
            <div className="text-red-400 font-black text-sm">تم إسقاطك</div>
            <div className="text-slate-300 text-xs font-mono-num mt-1">
              إعادة الانتشار خلال {Math.ceil(hud.respawnTimerSec)} ثانية...
            </div>
          </div>
        </div>
      )}

      {/* Click-to-Lock Hint on Desktop */}
      {!isTouchDevice && !hud.pointerLocked && !paused && !missionResult && !mpMatchEnded && !hud.cinematicActive && !chatOpen && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-10 px-3 py-1 rounded-lg bg-[#090e14]/90 border border-amber-500/40 text-amber-300 text-[10px]">
          انقر في وسط الشاشة لتفعيل التصويب الحر بالماوس
        </div>
      )}

      {/* Unified Multi-Touch Stage (handles simultaneous joystick + buttons + camera look) */}
      {touchGameplayActive && (
        <div
          ref={touchStageRef}
          onMouseDown={(e) => {
            if (isMouseFallbackBlocked()) return;
            mouseDragActive.current = { x: e.clientX, y: e.clientY };
          }}
          onMouseMove={(e) => {
            if (!mouseDragActive.current || isMouseFallbackBlocked()) return;
            const dx = e.clientX - mouseDragActive.current.x;
            const dy = e.clientY - mouseDragActive.current.y;
            mouseDragActive.current.x = e.clientX;
            mouseDragActive.current.y = e.clientY;
            if (dx !== 0 || dy !== 0) {
              engineRef.current?.addLookDelta(dx * 1.35, dy * 1.35);
            }
          }}
          onMouseUp={() => {
            if (mouseDragActive.current && !mouseDragActive.current.isFire) {
              mouseDragActive.current = null;
            }
          }}
          onContextMenu={(e) => e.preventDefault()}
          className="absolute inset-0 z-20 pointer-events-auto select-none"
          style={{
            touchAction: 'none',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            WebkitTapHighlightColor: 'transparent',
          }}
        >
          {/* Joystick */}
          <div
            data-hud-btn="joystick"
            onMouseDown={(e) => {
              if (isMouseFallbackBlocked()) return;
              e.stopPropagation();
              joyMouseDown.current = true;
              const rect = e.currentTarget.getBoundingClientRect();
              joyCenterRef.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
              updateJoystickFromCoords(e.clientX, e.clientY);
            }}
            onMouseMove={(e) => {
              if (!joyMouseDown.current || isMouseFallbackBlocked()) return;
              e.stopPropagation();
              updateJoystickFromCoords(e.clientX, e.clientY);
            }}
            onMouseUp={() => {
              if (!joyMouseDown.current) return;
              joyMouseDown.current = false;
              setJoyKnobVisual(0, 0);
              engineRef.current?.setTouchMove(0, 0);
            }}
            style={{ ...posStyle('joystick'), touchAction: 'none' }}
            className="absolute z-20 w-20 h-20 rounded-full bg-slate-900/60 border-2 border-slate-500/60 flex items-center justify-center pointer-events-auto select-none data-[pressed=true]:border-amber-400"
          >
            <div
              ref={joyKnobRef}
              className="w-9 h-9 rounded-full bg-amber-500/85 border border-white/50 pointer-events-none"
            />
          </div>

          {/* Fire */}
          <div
            role="button"
            tabIndex={-1}
            data-hud-btn="fire"
            onMouseDown={(e) => {
              if (isMouseFallbackBlocked()) return;
              startButtonMouseLook(e, true);
              engineRef.current?.setTouchFire(true);
            }}
            onMouseMove={moveButtonMouseLook}
            onMouseUp={(e) => endButtonMouseLook(e, true)}
            onMouseLeave={(e) => {
              if (mouseDragActive.current?.isFire) endButtonMouseLook(e, true);
            }}
            style={{ ...posStyle('fire'), touchAction: 'none' }}
            className="absolute z-20 w-14 h-14 rounded-full bg-red-600/85 border-2 border-red-300 text-white font-black flex items-center justify-center pointer-events-auto select-none cursor-pointer data-[pressed=true]:brightness-125 data-[pressed=true]:ring-2 data-[pressed=true]:ring-white/80"
          >
            <Crosshair className="w-6 h-6 pointer-events-none" />
          </div>

          {/* ADS */}
          <div
            role="button"
            tabIndex={-1}
            data-hud-btn="ads"
            onMouseDown={(e) => {
              if (isMouseFallbackBlocked()) return;
              startButtonMouseLook(e);
              engineRef.current?.toggleAds();
            }}
            onMouseMove={moveButtonMouseLook}
            onMouseUp={(e) => endButtonMouseLook(e)}
            style={{ ...posStyle('ads'), touchAction: 'none' }}
            className={`absolute z-20 w-10 h-10 rounded-lg border text-[10px] font-bold flex items-center justify-center pointer-events-auto select-none cursor-pointer data-[pressed=true]:brightness-125 data-[pressed=true]:ring-2 data-[pressed=true]:ring-white/80 ${
              hud.ads
                ? 'bg-amber-500 text-slate-950 border-amber-300'
                : 'bg-slate-900/80 text-white border-slate-600'
            }`}
          >
            <span className="pointer-events-none">منظار</span>
          </div>

          {/* Reload */}
          <div
            role="button"
            tabIndex={-1}
            data-hud-btn="reload"
            onMouseDown={(e) => {
              if (isMouseFallbackBlocked()) return;
              startButtonMouseLook(e);
              engineRef.current?.triggerReload();
            }}
            onMouseMove={moveButtonMouseLook}
            onMouseUp={(e) => endButtonMouseLook(e)}
            style={{ ...posStyle('reload'), touchAction: 'none' }}
            className="absolute z-20 w-10 h-10 rounded-lg bg-slate-900/80 border border-slate-600 text-white text-[10px] font-bold flex items-center justify-center pointer-events-auto select-none cursor-pointer data-[pressed=true]:brightness-125 data-[pressed=true]:ring-2 data-[pressed=true]:ring-white/80"
          >
            <span className="pointer-events-none">تلقيم</span>
          </div>

          {/* Jump */}
          <div
            role="button"
            tabIndex={-1}
            data-hud-btn="jump"
            onMouseDown={(e) => {
              if (isMouseFallbackBlocked()) return;
              startButtonMouseLook(e);
              engineRef.current?.triggerJump();
            }}
            onMouseMove={moveButtonMouseLook}
            onMouseUp={(e) => endButtonMouseLook(e)}
            style={{ ...posStyle('jump'), touchAction: 'none' }}
            className="absolute z-20 w-10 h-10 rounded-lg bg-slate-900/80 border border-slate-600 text-white text-[10px] font-bold flex items-center justify-center pointer-events-auto select-none cursor-pointer data-[pressed=true]:brightness-125 data-[pressed=true]:ring-2 data-[pressed=true]:ring-white/80"
          >
            <span className="pointer-events-none">قفز</span>
          </div>

          {/* Crouch */}
          <div
            role="button"
            tabIndex={-1}
            data-hud-btn="crouch"
            onMouseDown={(e) => {
              if (isMouseFallbackBlocked()) return;
              startButtonMouseLook(e);
              engineRef.current?.triggerCrouch();
            }}
            onMouseMove={moveButtonMouseLook}
            onMouseUp={(e) => endButtonMouseLook(e)}
            style={{ ...posStyle('crouch'), touchAction: 'none' }}
            className={`absolute z-20 w-10 h-10 rounded-lg border text-[10px] font-bold flex items-center justify-center pointer-events-auto select-none cursor-pointer data-[pressed=true]:brightness-125 data-[pressed=true]:ring-2 data-[pressed=true]:ring-white/80 ${
              hud.crouching
                ? 'bg-sky-600 text-white border-sky-300'
                : 'bg-slate-900/80 border-slate-600 text-white'
            }`}
          >
            <span className="pointer-events-none">انحناء</span>
          </div>

          {/* Grenade */}
          <div
            role="button"
            tabIndex={-1}
            data-hud-btn="grenade"
            onMouseDown={(e) => {
              if (isMouseFallbackBlocked()) return;
              startButtonMouseLook(e);
              engineRef.current?.triggerGrenade();
            }}
            onMouseMove={moveButtonMouseLook}
            onMouseUp={(e) => endButtonMouseLook(e)}
            style={{ ...posStyle('grenade'), touchAction: 'none' }}
            className="absolute z-20 w-10 h-10 rounded-lg bg-slate-900/80 border border-slate-600 text-amber-300 text-[10px] font-bold flex items-center justify-center pointer-events-auto select-none cursor-pointer data-[pressed=true]:brightness-125 data-[pressed=true]:ring-2 data-[pressed=true]:ring-white/80"
          >
            <span className="pointer-events-none">قنبلة</span>
          </div>

          {/* Swap Weapon */}
          <div
            role="button"
            tabIndex={-1}
            data-hud-btn="swap"
            onMouseDown={(e) => {
              if (isMouseFallbackBlocked()) return;
              startButtonMouseLook(e);
              engineRef.current?.switchWeaponSlot(hud.weaponId === 'p226' ? 1 : 2);
            }}
            onMouseMove={moveButtonMouseLook}
            onMouseUp={(e) => endButtonMouseLook(e)}
            style={{ ...posStyle('swap'), touchAction: 'none' }}
            className="absolute z-20 w-10 h-10 rounded-lg bg-slate-900/80 border border-slate-600 text-sky-300 text-[10px] font-bold flex items-center justify-center pointer-events-auto select-none cursor-pointer data-[pressed=true]:brightness-125 data-[pressed=true]:ring-2 data-[pressed=true]:ring-white/80"
          >
            <span className="pointer-events-none">سلاح</span>
          </div>

          {/* Special Ability */}
          <div
            role="button"
            tabIndex={-1}
            data-hud-btn="ability"
            onMouseDown={(e) => {
              if (isMouseFallbackBlocked()) return;
              startButtonMouseLook(e);
              engineRef.current?.triggerAbility();
            }}
            onMouseMove={moveButtonMouseLook}
            onMouseUp={(e) => endButtonMouseLook(e)}
            style={{
              ...posStyle('ability'),
              touchAction: 'none',
              borderColor: hud.abilityCooldownSec <= 0 || hud.abilityActiveSec > 0 ? hud.abilityAccent : undefined,
              color: hud.abilityCooldownSec <= 0 || hud.abilityActiveSec > 0 ? hud.abilityAccent : undefined,
            }}
            className={`absolute z-20 w-11 h-11 rounded-full border-2 text-[10px] font-black flex flex-col items-center justify-center pointer-events-auto select-none cursor-pointer data-[pressed=true]:brightness-125 data-[pressed=true]:ring-2 data-[pressed=true]:ring-white/80 ${
              hud.abilityActiveSec > 0
                ? 'bg-slate-900/95'
                : hud.abilityCooldownSec > 0
                  ? 'bg-slate-950/85 border-slate-700 text-slate-400 opacity-75'
                  : 'bg-slate-900/90'
            }`}
          >
            <Zap className="w-3.5 h-3.5 pointer-events-none" />
            <span className="pointer-events-none font-mono-num leading-none mt-0.5 text-[9px]">
              {hud.abilityActiveSec > 0
                ? `${hud.abilityActiveSec.toFixed(1)}s`
                : hud.abilityCooldownSec > 0
                  ? `${Math.ceil(hud.abilityCooldownSec)}`
                  : 'قدرة'}
            </span>
          </div>

          {/* Heal (Medkit) */}
          <div
            role="button"
            tabIndex={-1}
            data-hud-btn="heal"
            onMouseDown={(e) => {
              if (isMouseFallbackBlocked()) return;
              startButtonMouseLook(e);
              engineRef.current?.triggerHeal();
            }}
            onMouseMove={moveButtonMouseLook}
            onMouseUp={(e) => endButtonMouseLook(e)}
            style={{ ...posStyle('heal'), touchAction: 'none' }}
            className={`absolute z-20 w-11 h-11 rounded-full border-2 text-[10px] font-black flex flex-col items-center justify-center pointer-events-auto select-none cursor-pointer data-[pressed=true]:brightness-125 data-[pressed=true]:ring-2 data-[pressed=true]:ring-white/80 ${
              hud.healing
                ? 'bg-emerald-600/90 border-emerald-200 text-white'
                : hud.medkits > 0 && hud.hp < hud.maxHp
                  ? 'bg-emerald-950/90 border-emerald-400 text-emerald-300'
                  : 'bg-slate-950/85 border-slate-700 text-slate-400 opacity-75'
            }`}
          >
            <HeartPulse className="w-3.5 h-3.5 pointer-events-none" />
            <span className="pointer-events-none font-mono-num leading-none mt-0.5 text-[9px]">
              {hud.healing ? `${Math.round(hud.healProgress * 100)}%` : `هيل (${hud.medkits})`}
            </span>
          </div>

          {/* Interact (always shown when an interaction prompt is active) */}
          {hud.interactPromptAr && (
            <div
              role="button"
              tabIndex={-1}
              data-hud-btn="interact"
              onMouseDown={(e) => {
                if (isMouseFallbackBlocked()) return;
                startButtonMouseLook(e);
                engineRef.current?.triggerInteract();
              }}
              onMouseMove={moveButtonMouseLook}
              onMouseUp={(e) => endButtonMouseLook(e)}
              style={{ ...posStyle('interact'), touchAction: 'none' }}
              className="absolute z-20 w-12 h-10 rounded-lg bg-amber-500 border border-amber-200 text-slate-950 text-[10px] font-black flex items-center justify-center pointer-events-auto select-none cursor-pointer data-[pressed=true]:brightness-125 data-[pressed=true]:ring-2 data-[pressed=true]:ring-white/80"
            >
              <span className="pointer-events-none">تفاعل</span>
            </div>
          )}
        </div>
      )}

      {/* Cinematic Intro Overlay */}
      {hud.cinematicActive && mission && (
        <div className="absolute inset-0 z-20 flex flex-col justify-between p-4 pointer-events-auto">
          <div className="bg-[#090e14]/90 border border-amber-500/50 rounded-xl px-4 py-2 self-start">
            <div className="text-[10px] font-tactical text-amber-400">{mission.code}</div>
            <div className="text-base font-black text-white">
              {mission.titleAr} — {mission.subtitleAr}
            </div>
          </div>

          <div className="flex items-end justify-between gap-3">
            <div className="bg-[#090e14]/90 border border-slate-700 rounded-xl px-4 py-2.5 max-w-xl">
              <p className="text-xs sm:text-sm text-slate-100 font-semibold">{hud.cinematicCaptionAr}</p>
            </div>
            <button
              type="button"
              onClick={() => engineRef.current?.skipCinematic()}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer shrink-0"
            >
              تخطي المقدمة
            </button>
          </div>
        </div>
      )}

      {/* In-Match Chat Box (Multiplayer) */}
      {mode !== 'campaign' && (chatOpen || chatMessages.length > 0) && (
        <div
          data-ui-control="true"
          className={`absolute right-3 bottom-20 z-20 w-60 rounded-xl bg-[#090e14]/90 border border-slate-700 p-2 space-y-1.5 ${
            chatOpen ? 'pointer-events-auto' : 'pointer-events-none opacity-80'
          }`}
        >
          <div className="max-h-20 overflow-y-auto tactical-scroll space-y-0.5 text-[10px]">
            {chatMessages.slice(-4).map((m) => (
              <div key={m.id}>
                <span
                  className={
                    m.team === 'alpha'
                      ? 'text-sky-400 font-bold'
                      : m.team === 'bravo'
                        ? 'text-red-400 font-bold'
                        : 'text-amber-400 font-bold'
                  }
                >
                  {m.senderName}:{' '}
                </span>
                <span className="text-slate-200">{m.text}</span>
              </div>
            ))}
          </div>
          {chatOpen && (
            <form onSubmit={handleChatSubmit} className="flex gap-1">
              <input
                autoFocus
                type="text"
                value={chatText}
                maxLength={150}
                onChange={(e) => setChatText(e.target.value)}
                placeholder="رسالة..."
                className="flex-1 px-2 py-1 rounded bg-slate-900 border border-slate-700 text-[11px] text-white outline-none"
              />
              <button type="submit" className="p-1 rounded bg-amber-500 text-slate-950 cursor-pointer">
                <Send className="w-3 h-3" />
              </button>
            </form>
          )}
        </div>
      )}

      {/* Scoreboard Overlay (Tab) */}
      {showScoreboard && room && (
        <div className="absolute inset-0 z-30 bg-black/75 flex items-center justify-center p-3">
          <div className="max-w-lg w-full bg-[#0d131c] border border-slate-700 rounded-xl p-4 space-y-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-sm font-black text-white">{room.name} — لوحة النتائج</h3>
              <span className="font-mono-num text-xs text-amber-400">
                ألفا {room.alphaScore} : {room.bravoScore} برافو
              </span>
            </div>
            <div className="space-y-1 text-[11px] font-mono-num">
              {room.players
                .slice()
                .sort((a, b) => b.score - a.score)
                .map((p) => (
                  <div
                    key={p.id}
                    className={`p-2 rounded-lg flex items-center justify-between ${
                      p.id === localPlayerId ? 'bg-amber-500/20 border border-amber-500/40' : 'bg-slate-900'
                    }`}
                  >
                    <span className={p.team === 'alpha' ? 'text-sky-300 font-bold' : 'text-red-300 font-bold'}>
                      {p.callsign} ({p.team === 'alpha' ? 'ألفا' : 'برافو'})
                    </span>
                    <div className="flex gap-3 text-slate-200">
                      <span>قتل: {p.kills}</span>
                      <span>موت: {p.deaths}</span>
                      <span className="text-amber-400 font-bold">{p.score}</span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* Pause Modal */}
      {paused && !missionResult && !mpMatchEnded && (
        <div className="absolute inset-0 z-30 bg-black/78 flex items-center justify-center p-3 pointer-events-auto">
          <div className="max-w-xs w-full bg-[#0d131c] border border-slate-700 rounded-2xl p-4 space-y-2 text-center">
            <h2 className="text-lg font-black text-white mb-1">إيقاف مؤقت</h2>
            <button
              type="button"
              onClick={onResume}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-slate-950" />
              <span>استئناف القتال</span>
            </button>
            <button
              type="button"
              onClick={onOpenLayoutEditor}
              className="w-full py-2 rounded-xl bg-sky-700 hover:bg-sky-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Move className="w-3.5 h-3.5" />
              <span>تغيير أماكن الأزرار</span>
            </button>
            <button
              type="button"
              onClick={onOpenSettings}
              className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer"
            >
              إعدادات الرسومات والصوت
            </button>
            {mode === 'campaign' && (
              <button
                type="button"
                onClick={onRestartMission}
                className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>إعادة المرحلة</span>
              </button>
            )}
            <button
              type="button"
              onClick={onExitToMenu}
              className="w-full py-2 rounded-xl bg-red-950/60 hover:bg-red-900/70 border border-red-700/50 text-red-200 font-bold text-xs cursor-pointer"
            >
              العودة إلى القائمة الرئيسية
            </button>
          </div>
        </div>
      )}

      {/* Campaign Victory / Defeat Modal */}
      {missionResult && (
        <div className="absolute inset-0 z-30 bg-black/82 flex items-center justify-center p-3 pointer-events-auto">
          <div className="max-w-sm w-full bg-[#0d131c] border border-slate-700 rounded-2xl p-4 space-y-3 text-center">
            <div
              className={`text-xl font-black ${
                missionResult.victory ? 'text-emerald-400' : 'text-red-400'
              }`}
            >
              {missionResult.victory ? 'تم إنجاز المهمة بنجاح!' : 'فشلت المهمة'}
            </div>

            {missionResult.victory && (
              <div className="flex items-center justify-center gap-1.5">
                {[1, 2, 3].map((s) => (
                  <Star
                    key={s}
                    className={`w-6 h-6 ${
                      missionResult.stars >= s ? 'text-amber-400 fill-amber-400' : 'text-slate-700'
                    }`}
                  />
                ))}
              </div>
            )}

            <div className="grid grid-cols-3 gap-2 font-mono-num text-[11px]">
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-slate-400">النقاط</div>
                <div className="text-amber-400 font-bold text-sm mt-0.5">{missionResult.score}</div>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-slate-400">الأعداء</div>
                <div className="text-white font-bold text-sm mt-0.5">{missionResult.kills}</div>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-slate-400">الزمن</div>
                <div className="text-sky-300 font-bold text-sm mt-0.5">{missionResult.timeSec} ث</div>
              </div>
            </div>

            <div className="space-y-1.5 pt-1 text-xs">
              {missionResult.victory && missionResult.missionId < 10 && (
                <button
                  type="button"
                  onClick={onNextMission}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black cursor-pointer"
                >
                  الانتقال للمرحلة التالية ({missionResult.missionId + 1})
                </button>
              )}
              <button
                type="button"
                onClick={onRestartMission}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black cursor-pointer"
              >
                إعادة لعب المرحلة
              </button>
              <button
                type="button"
                onClick={onExitToMenu}
                className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold cursor-pointer"
              >
                العودة للقائمة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Multiplayer Match Ended Modal */}
      {mpMatchEnded && room && (
        <div className="absolute inset-0 z-30 bg-black/82 flex items-center justify-center p-3 pointer-events-auto">
          <div className="max-w-md w-full bg-[#0d131c] border border-slate-700 rounded-2xl p-4 space-y-3 text-center">
            <Trophy className="w-8 h-8 text-amber-400 mx-auto" />
            <h2 className="text-lg font-black text-white">
              {room.winner === 'draw'
                ? 'تعادل الفريقين'
                : room.winner === 'alpha'
                  ? 'انتصار فريق ألفا!'
                  : 'انتصار فريق برافو!'}
            </h2>
            <div className="font-mono-num text-sm font-bold text-amber-400">
              ألفا {room.alphaScore} — {room.bravoScore} برافو
            </div>

            <div className="space-y-1 text-[11px] font-mono-num text-right max-h-36 overflow-y-auto tactical-scroll">
              {room.players
                .slice()
                .sort((a, b) => b.score - a.score)
                .map((p) => (
                  <div key={p.id} className="p-2 rounded-lg bg-slate-900 flex justify-between">
                    <span className={p.team === 'alpha' ? 'text-sky-300 font-bold' : 'text-red-300 font-bold'}>
                      {p.callsign}
                    </span>
                    <span className="text-slate-200">
                      {p.kills} قتل / {p.deaths} موت · {p.score} نقطة
                    </span>
                  </div>
                ))}
            </div>

            <div className="flex gap-2 pt-1 text-xs">
              {room.hostId === localPlayerId && (
                <button
                  type="button"
                  onClick={() => mpClient.returnToLobby()}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black cursor-pointer"
                >
                  العودة لغرفة اللعب
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  mpClient.leaveRoom();
                  onExitToMenu();
                }}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold cursor-pointer"
              >
                مغادرة الغرفة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
