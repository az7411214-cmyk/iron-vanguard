import React, { useEffect, useState } from 'react';
import { Trophy, X } from 'lucide-react';
import type { LeaderboardEntry } from '../game/types';
import { fetchLeaderboard } from '../services/progressionService';

interface LeaderboardModalProps {
  isSignedIn: boolean;
  onSignIn: () => void;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  isSignedIn,
  onSignIn,
  onClose,
}) => {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadFailed, setLoadFailed] = useState(false);

  useEffect(() => {
    if (!isSignedIn) return;
    setLoading(true);
    setLoadFailed(false);
    fetchLeaderboard()
      .then((list) => setEntries(list))
      .catch(() => {
        setEntries([]);
        setLoadFailed(true);
      })
      .finally(() => setLoading(false));
  }, [isSignedIn]);

  return (
    <div className="absolute inset-0 z-40 bg-black/80 flex items-center justify-center p-3">
      <div className="max-w-lg w-full bg-[#0d131c] border border-slate-700 rounded-2xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm sm:text-base font-black text-white">لوحة المتصدرين العالمية</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 max-h-[70vh] overflow-y-auto tactical-scroll">
          {!isSignedIn ? (
            <div className="text-center py-6 space-y-3">
              <p className="text-sm text-slate-300">
                سجّل الدخول بحساب Google لعرض ترتيب القادة العالميين ومنافسة اللاعبين الآخرين.
              </p>
              <button
                type="button"
                onClick={onSignIn}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm cursor-pointer"
              >
                تسجيل الدخول الآن
              </button>
            </div>
          ) : loading ? (
            <div className="text-center py-8 text-sm text-slate-400">جاري تحميل الترتيب...</div>
          ) : loadFailed ? (
            <div className="text-center py-8 text-sm text-amber-400">
              تعذر الاتصال بخادم الترتيب حالياً، يرجى المحاولة لاحقاً.
            </div>
          ) : entries.length === 0 ? (
            <div className="text-center py-8 text-sm text-slate-400">لا توجد نتائج مسجلة بعد.</div>
          ) : (
            <div className="space-y-2">
              {entries.map((entry, idx) => (
                <div
                  key={entry.userId}
                  className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between text-xs sm:text-sm"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-lg bg-amber-500/15 text-amber-400 font-mono-num font-bold flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <div>
                      <div className="font-bold text-white">{entry.callsign}</div>
                      <div className="text-[11px] text-slate-400 font-mono-num">
                        رتبة {entry.rank} · {entry.kills} قتل · {entry.wins} فوز
                      </div>
                    </div>
                  </div>
                  <div className="font-mono-num font-bold text-emerald-400">{entry.xp.toLocaleString()} XP</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
