import type { HudButtonPlacement, HudControlId, HudLayoutConfig } from './types';

export type HudPresetId = 'default' | 'left_hand' | 'claw_4';

export interface HudControlMeta {
  id: HudControlId;
  labelAr: string;
  touchOnly: boolean;
}

export const HUD_CONTROL_META: Record<HudControlId, HudControlMeta> = {
  joystick: { id: 'joystick', labelAr: 'عصا الحركة', touchOnly: true },
  fire: { id: 'fire', labelAr: 'إطلاق النار', touchOnly: true },
  ads: { id: 'ads', labelAr: 'منظار', touchOnly: true },
  reload: { id: 'reload', labelAr: 'تلقيم', touchOnly: true },
  jump: { id: 'jump', labelAr: 'قفز', touchOnly: true },
  crouch: { id: 'crouch', labelAr: 'انحناء', touchOnly: true },
  grenade: { id: 'grenade', labelAr: 'قنبلة', touchOnly: true },
  swap: { id: 'swap', labelAr: 'تبديل سلاح', touchOnly: true },
  ability: { id: 'ability', labelAr: 'القدرة الخاصة', touchOnly: true },
  heal: { id: 'heal', labelAr: 'هيل (علاج)', touchOnly: true },
  interact: { id: 'interact', labelAr: 'تفاعل', touchOnly: true },
  pause: { id: 'pause', labelAr: 'إيقاف / دردشة', touchOnly: false },
  radar: { id: 'radar', labelAr: 'الرادار', touchOnly: false },
  objective: { id: 'objective', labelAr: 'المهام / النتيجة', touchOnly: false },
  vitals: { id: 'vitals', labelAr: 'الصحة والدرع', touchOnly: false },
  ammo: { id: 'ammo', labelAr: 'الذخيرة والسلاح', touchOnly: false },
};

export const HUD_CONTROL_IDS = Object.keys(HUD_CONTROL_META) as HudControlId[];

export const DEFAULT_HUD_LAYOUT: HudLayoutConfig = {
  radar: { x: 7, y: 11, scale: 0.9, opacity: 0.92 },
  objective: { x: 50, y: 7, scale: 0.9, opacity: 0.92 },
  pause: { x: 93, y: 8, scale: 0.9, opacity: 0.95 },
  vitals: { x: 14, y: 89, scale: 0.92, opacity: 0.92 },
  ammo: { x: 86, y: 89, scale: 0.92, opacity: 0.92 },
  joystick: { x: 14, y: 70, scale: 1.0, opacity: 0.88 },
  fire: { x: 87, y: 69, scale: 1.05, opacity: 0.92 },
  ads: { x: 76, y: 63, scale: 0.95, opacity: 0.9 },
  reload: { x: 76, y: 76, scale: 0.92, opacity: 0.9 },
  jump: { x: 93, y: 51, scale: 0.92, opacity: 0.9 },
  crouch: { x: 84, y: 51, scale: 0.92, opacity: 0.9 },
  grenade: { x: 67, y: 76, scale: 0.9, opacity: 0.9 },
  swap: { x: 67, y: 63, scale: 0.9, opacity: 0.9 },
  ability: { x: 75, y: 50, scale: 0.95, opacity: 0.94 },
  heal: { x: 65, y: 50, scale: 0.95, opacity: 0.94 },
  interact: { x: 50, y: 68, scale: 0.95, opacity: 0.95 },
};

export const HUD_PRESETS: Record<HudPresetId, { labelAr: string; layout: HudLayoutConfig }> = {
  default: {
    labelAr: 'افتراضي (حركة يسار / إطلاق يمين)',
    layout: DEFAULT_HUD_LAYOUT,
  },
  left_hand: {
    labelAr: 'معكوس (حركة يمين / إطلاق يسار)',
    layout: {
      ...DEFAULT_HUD_LAYOUT,
      joystick: { x: 86, y: 70, scale: 1.0, opacity: 0.88 },
      fire: { x: 13, y: 69, scale: 1.05, opacity: 0.92 },
      ads: { x: 24, y: 63, scale: 0.95, opacity: 0.9 },
      reload: { x: 24, y: 76, scale: 0.92, opacity: 0.9 },
      jump: { x: 7, y: 51, scale: 0.92, opacity: 0.9 },
      crouch: { x: 16, y: 51, scale: 0.92, opacity: 0.9 },
      grenade: { x: 33, y: 76, scale: 0.9, opacity: 0.9 },
      swap: { x: 33, y: 63, scale: 0.9, opacity: 0.9 },
      ability: { x: 25, y: 50, scale: 0.95, opacity: 0.94 },
      heal: { x: 35, y: 50, scale: 0.95, opacity: 0.94 },
    },
  },
  claw_4: {
    labelAr: 'احترافي 4 أصابع (Claw)',
    layout: {
      ...DEFAULT_HUD_LAYOUT,
      joystick: { x: 14, y: 73, scale: 1.0, opacity: 0.88 },
      fire: { x: 16, y: 27, scale: 1.1, opacity: 0.92 },
      ads: { x: 84, y: 27, scale: 1.0, opacity: 0.92 },
      jump: { x: 91, y: 53, scale: 0.95, opacity: 0.9 },
      crouch: { x: 82, y: 59, scale: 0.92, opacity: 0.9 },
      reload: { x: 91, y: 68, scale: 0.92, opacity: 0.9 },
      grenade: { x: 74, y: 74, scale: 0.9, opacity: 0.9 },
      swap: { x: 82, y: 74, scale: 0.9, opacity: 0.9 },
      ability: { x: 73, y: 58, scale: 0.95, opacity: 0.94 },
      heal: { x: 64, y: 58, scale: 0.95, opacity: 0.94 },
      radar: { x: 31, y: 11, scale: 0.82, opacity: 0.9 },
    },
  },
};

export function clampPlacement(p: Partial<HudButtonPlacement> | undefined, fallback: HudButtonPlacement): HudButtonPlacement {
  return {
    x: Math.max(3, Math.min(97, Number.isFinite(p?.x) ? Number(p!.x) : fallback.x)),
    y: Math.max(4, Math.min(96, Number.isFinite(p?.y) ? Number(p!.y) : fallback.y)),
    scale: Math.max(0.65, Math.min(1.45, Number.isFinite(p?.scale) ? Number(p!.scale) : fallback.scale)),
    opacity: Math.max(0.4, Math.min(1.0, Number.isFinite(p?.opacity) ? Number(p!.opacity) : fallback.opacity)),
  };
}

export function resolveHudLayout(partial?: Partial<HudLayoutConfig>): HudLayoutConfig {
  const result = {} as HudLayoutConfig;
  for (const id of HUD_CONTROL_IDS) {
    result[id] = clampPlacement(partial?.[id], DEFAULT_HUD_LAYOUT[id]);
  }
  return result;
}
