export type GraphicsQuality = 'ultra' | 'high' | 'medium' | 'low';
export type FpsCap = 60 | 120 | 0; // 0 = unlimited / native display refresh

export type WeaponId =
  | 'm4a1'
  | 'ak74m'
  | 'mp5sd'
  | 'spas12'
  | 'scarh'
  | 'm249'
  | 'awm'
  | 'p226';

export type CharacterId =
  | 'striker'
  | 'vanguard'
  | 'ghost'
  | 'falcon'
  | 'medic'
  | 'pyro'
  | 'spectre'
  | 'titan';
export type SkinId = 'olive' | 'desert' | 'nightops' | 'arctic' | 'crimson';

export type GameMode = 'campaign' | 'tdm' | 'domination';
export type TeamId = 'alpha' | 'bravo';
export type TeamSizeMode = '2v2' | '5v5';

export type HudControlId =
  | 'joystick'
  | 'fire'
  | 'ads'
  | 'reload'
  | 'jump'
  | 'crouch'
  | 'grenade'
  | 'swap'
  | 'ability'
  | 'heal'
  | 'interact'
  | 'pause'
  | 'radar'
  | 'objective'
  | 'vitals'
  | 'ammo';

export interface HudButtonPlacement {
  x: number; // percentage 0..100 inside 16:9 stage
  y: number; // percentage 0..100 inside 16:9 stage
  scale: number; // 0.7..1.4
  opacity: number; // 0.45..1.0
}

export type HudLayoutConfig = Record<HudControlId, HudButtonPlacement>;

export interface GameSettings {
  graphics: GraphicsQuality;
  fpsCap: FpsCap;
  sensitivity: number;
  fov: number;
  invertY: boolean;
  masterVolume: number;
  sfxVolume: number;
  ambientVolume: number;
  muted: boolean;
  showFps: boolean;
  touchControls: 'auto' | 'always' | 'off';
  hudLayout?: Partial<HudLayoutConfig>;
}

export interface WeaponDef {
  id: WeaponId;
  name: string;
  nameAr: string;
  category: 'rifle' | 'smg' | 'shotgun' | 'lmg' | 'sniper' | 'pistol';
  categoryAr: string;
  damage: number;
  headshotMult: number;
  fireRateRpm: number;
  magSize: number;
  reserveAmmo: number;
  reloadTimeSec: number;
  spreadHip: number;
  spreadAds: number;
  recoilPitch: number;
  recoilYaw: number;
  range: number;
  pellets?: number;
  adsFov: number;
  auto: boolean;
  suppressed?: boolean;
  unlockCost: number;
  unlockMission?: number;
  descriptionAr: string;
  accentColor: string;
}

export interface CharacterDef {
  id: CharacterId;
  name: string;
  nameAr: string;
  roleAr: string;
  helmetType: 'tactical' | 'heavy' | 'hood' | 'beret' | 'medic' | 'pyro' | 'recon' | 'juggernaut';
  armorBonus: number;
  speedMult: number;
  unlockCost: number;
  descriptionAr: string;
  abilityNameAr: string;
  abilityDescAr: string;
  abilityCooldownSec: number;
  abilityDurationSec: number;
  abilityAccent: string;
}

export interface SkinDef {
  id: SkinId;
  nameAr: string;
  primaryHex: number;
  secondaryHex: number;
  accentHex: number;
  swatchCss: string;
  unlockCost: number;
}

export type BiomeType =
  | 'urban'
  | 'desert'
  | 'nightbase'
  | 'city_liberation'
  | 'defense_fort'
  | 'mountain'
  | 'harbor'
  | 'storm'
  | 'warfront'
  | 'citadel';

export type ObjectiveKind =
  | 'eliminate_squads'
  | 'destroy_targets'
  | 'hack_terminals'
  | 'rescue_civilians'
  | 'defend_core'
  | 'capture_zone'
  | 'boss_citadel';

export interface MissionDef {
  id: number;
  code: string;
  titleAr: string;
  subtitleAr: string;
  locationAr: string;
  biome: BiomeType;
  difficulty: 1 | 2 | 3 | 4 | 5;
  briefingAr: string;
  cinematicLinesAr: string[];
  objectiveKind: ObjectiveKind;
  objectiveLabelAr: string;
  targetCount: number;
  enemyCount: number;
  waves?: number;
  hasAllies?: boolean;
  hasBoss?: boolean;
  rewardXp: number;
  rewardCredits: number;
  unlockWeapon?: WeaponId;
  unlockSkin?: SkinId;
  skyHex: number;
  fogHex: number;
  fogDensity: number;
  sunColor: number;
  sunIntensity: number;
  hemiSky: number;
  hemiGround: number;
  ambientWeather: 'clear' | 'dust' | 'night' | 'rain_storm' | 'embers';
}

export interface MissionRecord {
  missionId: number;
  stars: number;
  bestScore: number;
  bestTimeSec: number;
}

export interface PlayerProfile {
  userId: string;
  callsign: string;
  xp: number;
  credits: number;
  rank: number;
  unlockedMission: number;
  completedMissions: number[];
  unlockedWeapons: WeaponId[];
  unlockedSkins: SkinId[];
  selectedCharacter: CharacterId;
  selectedSkin: SkinId;
  primaryWeapon: WeaponId;
  secondaryWeapon: WeaponId;
  kills: number;
  deaths: number;
  wins: number;
  missionRecords?: Record<number, MissionRecord>;
}

export interface LeaderboardEntry {
  userId: string;
  callsign: string;
  rank: number;
  xp: number;
  kills: number;
  wins: number;
}

export interface MultiplayerPlayerInfo {
  id: string;
  callsign: string;
  team: TeamId;
  ready: boolean;
  isHost: boolean;
  characterId: CharacterId;
  skinId: SkinId;
  weaponId: WeaponId;
  kills: number;
  deaths: number;
  assists: number;
  score: number;
  hp: number;
  alive: boolean;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  crouching: boolean;
  moving: boolean;
}

export interface CapturePointState {
  id: 'A' | 'B' | 'C';
  x: number;
  z: number;
  owner: TeamId | 'neutral';
  progress: number; // -100 (bravo) to +100 (alpha)
  capturingTeam: TeamId | null;
}

export interface MultiplayerRoomState {
  roomId: string;
  code: string;
  name: string;
  isPrivate: boolean;
  mode: 'tdm' | 'domination';
  teamSize: TeamSizeMode;
  maxPlayers: number;
  mapId: 'urban_arena' | 'harbor_arena';
  status: 'lobby' | 'playing' | 'ended';
  hostId: string;
  alphaScore: number;
  bravoScore: number;
  scoreLimit: number;
  timeRemainingSec: number;
  winner: TeamId | 'draw' | null;
  players: MultiplayerPlayerInfo[];
  capturePoints: CapturePointState[];
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  team: TeamId | 'system';
  text: string;
  timestamp: number;
}

export interface KillFeedItem {
  id: string;
  killerName: string;
  killerTeam: TeamId | 'enemy';
  victimName: string;
  victimTeam: TeamId | 'enemy';
  weaponId: WeaponId;
  headshot: boolean;
  timestamp: number;
}

export interface ProjectedNametag {
  id: string;
  name: string;
  team: TeamId;
  hp: number;
  screenX: number;
  screenY: number;
  distance: number;
  visible: boolean;
}

export interface HudSnapshot {
  hp: number;
  maxHp: number;
  armor: number;
  maxArmor: number;
  stamina: number;
  weaponId: WeaponId;
  ammo: number;
  reserve: number;
  reloading: boolean;
  reloadProgress: number;
  grenades: number;
  ads: boolean;
  crouching: boolean;
  sprinting: boolean;
  fps: number;
  score: number;
  kills: number;
  deaths: number;
  objectiveTextAr: string;
  objectiveProgress: number;
  objectiveTarget: number;
  secondaryObjectiveAr?: string;
  timerSec: number;
  wave?: number;
  maxWaves?: number;
  baseCoreHp?: number;
  alphaScore?: number;
  bravoScore?: number;
  scoreLimit?: number;
  capturePoints?: CapturePointState[];
  hitmarkerKind: 'none' | 'normal' | 'headshot' | 'kill';
  damageFlash: number;
  lowHealth: boolean;
  pointerLocked: boolean;
  cinematicActive: boolean;
  cinematicCaptionAr: string;
  interactPromptAr: string | null;
  playerPos: { x: number; z: number; yaw: number };
  radarBlips: Array<{ x: number; z: number; kind: 'enemy' | 'ally' | 'objective' | 'civilian' }>;
  nametags: ProjectedNametag[];
  respawnTimerSec: number;
  abilityNameAr: string;
  abilityCooldownSec: number;
  abilityMaxCooldownSec: number;
  abilityActiveSec: number;
  abilityAccent: string;
  medkits: number;
  healing: boolean;
  healProgress: number;
  healFlash: number;
}
