import { onAuthStateChanged, type User } from 'firebase/auth';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ArmoryScreen } from './components/ArmoryScreen';
import { CampaignSelect } from './components/CampaignSelect';
import { ErrorBoundary } from './components/ErrorBoundary';
import { GameHUD } from './components/GameHUD';
import { HudLayoutEditor } from './components/HudLayoutEditor';
import { LeaderboardModal } from './components/LeaderboardModal';
import { MultiplayerLobby } from './components/MultiplayerLobby';
import { SettingsModal } from './components/SettingsModal';
import { TitleMenu } from './components/TitleMenu';
import { audioEngine } from './engine/AudioEngine';
import { GameEngine, type MissionResultPayload } from './engine/GameEngine';
import { DEFAULT_HUD_LAYOUT } from './game/hudLayout';
import { getMissionById } from './game/missions';
import type {
  CharacterId,
  ChatMessage,
  GameMode,
  GameSettings,
  HudSnapshot,
  KillFeedItem,
  MissionDef,
  MultiplayerRoomState,
  PlayerProfile,
  SkinId,
  WeaponId,
} from './game/types';
import { auth } from './services/firebase';
import { mpClient } from './services/multiplayerClient';
import {
  computeRankFromXp,
  loadLocalProfile,
  loadOrCreateCloudProfile,
  saveLoadoutToCloud,
  saveLocalProfile,
  saveMissionRecordToCloud,
  saveProgressionToCloud,
  signInWithGoogleAccount,
  signOutAccount,
} from './services/progressionService';

const SETTINGS_KEY = 'iron_vanguard_settings_v1';

const DEFAULT_SETTINGS: GameSettings = {
  graphics: 'high',
  fpsCap: 60,
  sensitivity: 1.0,
  fov: 76,
  invertY: false,
  masterVolume: 0.8,
  sfxVolume: 0.85,
  ambientVolume: 0.45,
  muted: false,
  showFps: false,
  touchControls: 'auto',
  hudLayout: DEFAULT_HUD_LAYOUT,
};

function loadInitialSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<GameSettings>) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

const INITIAL_HUD: HudSnapshot = {
  hp: 100,
  maxHp: 100,
  armor: 25,
  maxArmor: 25,
  stamina: 100,
  weaponId: 'm4a1',
  ammo: 30,
  reserve: 150,
  reloading: false,
  reloadProgress: 0,
  grenades: 3,
  ads: false,
  crouching: false,
  sprinting: false,
  fps: 60,
  score: 0,
  kills: 0,
  deaths: 0,
  objectiveTextAr: '',
  objectiveProgress: 0,
  objectiveTarget: 10,
  timerSec: 0,
  hitmarkerKind: 'none',
  damageFlash: 0,
  lowHealth: false,
  pointerLocked: false,
  cinematicActive: false,
  cinematicCaptionAr: '',
  interactPromptAr: null,
  playerPos: { x: 0, z: 0, yaw: 0 },
  radarBlips: [],
  nametags: [],
  respawnTimerSec: 0,
  abilityNameAr: 'اندفاع الأدرينالين',
  abilityCooldownSec: 0,
  abilityMaxCooldownSec: 18,
  abilityActiveSec: 0,
  abilityAccent: '#f59e0b',
  medkits: 3,
  healing: false,
  healProgress: 0,
  healFlash: 0,
};

type ScreenView = 'menu' | 'campaign' | 'multiplayer' | 'armory' | 'playing';

function MainApp() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [screen, setScreen] = useState<ScreenView>(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('room') ? 'multiplayer' : 'menu';
  });
  const [showSettings, setShowSettings] = useState(false);
  const [showLayoutEditor, setShowLayoutEditor] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const [settings, setSettings] = useState<GameSettings>(loadInitialSettings);
  const [profile, setProfile] = useState<PlayerProfile>(loadLocalProfile);
  const [authUser, setAuthUser] = useState<{
    uid: string;
    email: string | null;
    displayName: string | null;
  } | null>(null);

  // Active Match State
  const [gameMode, setGameMode] = useState<GameMode>('campaign');
  const [activeMission, setActiveMission] = useState<MissionDef | null>(null);
  const [paused, setPaused] = useState(false);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [missionResult, setMissionResult] = useState<MissionResultPayload | null>(null);
  const [killFeed, setKillFeed] = useState<KillFeedItem[]>([]);

  // Multiplayer State
  const [mpConnected, setMpConnected] = useState(false);
  const [mpPlayerId, setMpPlayerId] = useState<string | null>(null);
  const [mpRoom, setMpRoom] = useState<MultiplayerRoomState | null>(null);
  const [mpChat, setMpChat] = useState<ChatMessage[]>([]);
  const [mpError, setMpError] = useState<string | null>(null);

  // Keep latest profile & screen accessible inside engine callbacks without tearing down WebGL
  const profileRef = useRef(profile);
  profileRef.current = profile;
  const screenRef = useRef(screen);
  screenRef.current = screen;

  // Firebase Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user: User | null) => {
      if (user) {
        setAuthUser({ uid: user.uid, email: user.email, displayName: user.displayName });
        try {
          const loaded = await loadOrCreateCloudProfile(user.uid, user.displayName);
          setProfile(loaded);
        } catch (err) {
          console.error('Failed to load cloud profile:', err);
        }
      } else {
        setAuthUser(null);
        setProfile(loadLocalProfile());
      }
    });
    return () => unsub();
  }, []);

  // Fullscreen listener
  useEffect(() => {
    const onFs = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFs);
    return () => document.removeEventListener('fullscreenchange', onFs);
  }, []);

  const handleToggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      void document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      void document.exitFullscreen?.().catch(() => {});
    }
  }, []);

  const handleMissionEnd = useCallback((result: MissionResultPayload) => {
    setMissionResult(result);
    const mission = getMissionById(result.missionId);
    const prev = profileRef.current;

    const gainedXp = result.victory ? mission.rewardXp + result.kills * 15 : Math.round(result.kills * 10);
    const gainedCredits = result.victory ? mission.rewardCredits : Math.round(result.kills * 8);
    const nextXp = prev.xp + gainedXp;
    const nextRank = computeRankFromXp(nextXp);

    const nextUnlockedWeapons = [...prev.unlockedWeapons];
    if (result.victory && mission.unlockWeapon && !nextUnlockedWeapons.includes(mission.unlockWeapon)) {
      nextUnlockedWeapons.push(mission.unlockWeapon);
    }

    const nextUnlockedSkins = [...prev.unlockedSkins];
    if (result.victory && mission.unlockSkin && !nextUnlockedSkins.includes(mission.unlockSkin)) {
      nextUnlockedSkins.push(mission.unlockSkin);
    }

    const nextCompleted = result.victory
      ? Array.from(new Set([...prev.completedMissions, mission.id])).slice(0, 10)
      : prev.completedMissions;

    const nextUnlockedMission = result.victory
      ? Math.min(10, Math.max(prev.unlockedMission, mission.id + 1))
      : prev.unlockedMission;

    const prevRec = prev.missionRecords?.[mission.id];
    const nextRecords = {
      ...(prev.missionRecords || {}),
      ...(result.victory
        ? {
            [mission.id]: {
              missionId: mission.id,
              stars: Math.max(prevRec?.stars || 0, result.stars),
              bestScore: Math.max(prevRec?.bestScore || 0, result.score),
              bestTimeSec: prevRec?.bestTimeSec
                ? Math.min(prevRec.bestTimeSec, result.timeSec)
                : result.timeSec,
            },
          }
        : {}),
    };

    const updated: PlayerProfile = {
      ...prev,
      xp: nextXp,
      credits: prev.credits + gainedCredits,
      rank: nextRank,
      unlockedMission: nextUnlockedMission,
      completedMissions: nextCompleted,
      unlockedWeapons: nextUnlockedWeapons,
      unlockedSkins: nextUnlockedSkins,
      kills: prev.kills + result.kills,
      deaths: prev.deaths + result.deaths,
      wins: prev.wins + (result.victory ? 1 : 0),
      missionRecords: nextRecords,
    };

    setProfile(updated);
    saveLocalProfile(updated);
    if (auth.currentUser && updated.userId === auth.currentUser.uid) {
      void saveProgressionToCloud(updated).catch(console.error);
      if (result.victory) {
        void saveMissionRecordToCloud(updated.userId, nextRecords[mission.id]).catch(console.error);
      }
    }
  }, []);

  // Initialize isolated Three.js GameEngine ONCE
  useEffect(() => {
    if (!canvasMountRef.current) return;
    const engine = new GameEngine(canvasMountRef.current, settings, {
      onHudUpdate: (snap) => setHud(snap),
      onMissionEnd: handleMissionEnd,
      onPauseRequest: () => {
        setPaused((prev) => {
          const next = !prev;
          engine.setPaused(next);
          return next;
        });
      },
      onLocalKillFeed: (killer, victim, weaponId, headshot, isAlly) => {
        setKillFeed((prev) => [
          ...prev.slice(-5),
          {
            id: `${Date.now()}_${Math.random()}`,
            killerName: killer,
            killerTeam: isAlly ? 'alpha' : 'bravo',
            victimName: victim,
            victimTeam: isAlly ? 'bravo' : 'alpha',
            weaponId,
            headshot,
            timestamp: Date.now(),
          },
        ]);
      },
    });
    engineRef.current = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [handleMissionEnd]);

  // Apply settings updates to engine + localStorage
  const handleUpdateSettings = useCallback((next: GameSettings) => {
    setSettings(next);
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
    } catch {
      // ignore
    }
    engineRef.current?.applySettings(next);
  }, []);

  // Sync loadout changes into engine
  useEffect(() => {
    engineRef.current?.setLoadout(
      profile.selectedCharacter,
      profile.selectedSkin,
      profile.primaryWeapon,
      profile.secondaryWeapon
    );
  }, [
    profile.selectedCharacter,
    profile.selectedSkin,
    profile.primaryWeapon,
    profile.secondaryWeapon,
  ]);

  // Multiplayer WebSocket event bindings
  useEffect(() => {
    const unsubs = [
      mpClient.on('connected', (pid) => {
        setMpConnected(true);
        setMpPlayerId(pid);
      }),
      mpClient.on('disconnected', () => {
        setMpConnected(false);
      }),
      mpClient.on('error', (message) => {
        setMpError(message);
      }),
      mpClient.on('chat', (msg) => {
        setMpChat((prev) => [...prev.slice(-40), msg]);
      }),
      mpClient.on('roomState', (room) => {
        setMpRoom(room);
        if (!room) {
          setMpChat([]);
          if (screenRef.current === 'playing' && gameMode !== 'campaign') {
            engineRef.current?.enterMenuDiorama();
            setScreen('multiplayer');
          }
          return;
        }
        if (room.status === 'lobby' && screenRef.current === 'playing') {
          engineRef.current?.enterMenuDiorama();
          setScreen('multiplayer');
        } else if (room.status === 'playing' && mpClient.playerId) {
          engineRef.current?.syncRoomPlayers(room, mpClient.playerId);
        }
      }),
      mpClient.on('matchStarted', (room) => {
        setMpRoom(room);
        setGameMode(room.mode);
        setActiveMission(null);
        setMissionResult(null);
        setPaused(false);
        setKillFeed([]);
        const prof = profileRef.current;
        engineRef.current?.setLoadout(
          prof.selectedCharacter,
          prof.selectedSkin,
          prof.primaryWeapon,
          prof.secondaryWeapon
        );
        if (mpClient.playerId) {
          engineRef.current?.startMultiplayerMatch(room, mpClient.playerId);
        }
        setScreen('playing');
      }),
      mpClient.on('matchEnded', (room) => {
        setMpRoom(room);
        engineRef.current?.exitPointerLock();
        const me = room.players.find((p) => p.id === mpClient.playerId);
        if (me) {
          const won = room.winner === me.team;
          const prev = profileRef.current;
          const gainedXp = (won ? 400 : 150) + me.kills * 35;
          const gainedCredits = (won ? 450 : 180) + me.kills * 25;
          const nextXp = prev.xp + gainedXp;
          const updated: PlayerProfile = {
            ...prev,
            xp: nextXp,
            credits: prev.credits + gainedCredits,
            rank: computeRankFromXp(nextXp),
            kills: prev.kills + me.kills,
            deaths: prev.deaths + me.deaths,
            wins: prev.wins + (won ? 1 : 0),
          };
          setProfile(updated);
          saveLocalProfile(updated);
          if (auth.currentUser && updated.userId === auth.currentUser.uid) {
            void saveProgressionToCloud(updated).catch(console.error);
          }
        }
      }),
      mpClient.on('playerDelta', (delta) => {
        engineRef.current?.applyRemoteDelta(delta);
      }),
      mpClient.on('remoteFire', (fire) => {
        engineRef.current?.applyRemoteFire(fire);
      }),
      mpClient.on('tookDamage', (dmg) => {
        engineRef.current?.handleLocalDamage(dmg.hp);
      }),
      mpClient.on('respawned', (sp) => {
        engineRef.current?.handleLocalRespawn(sp.x, sp.y, sp.z, sp.yaw);
      }),
      mpClient.on('killEvent', (ev) => {
        setKillFeed((prev) => [
          ...prev.slice(-5),
          {
            id: `${Date.now()}_${Math.random()}`,
            killerName: ev.killerName,
            killerTeam: ev.killerTeam,
            victimName: ev.victimName,
            victimTeam: ev.victimTeam,
            weaponId: ev.weaponId,
            headshot: ev.headshot,
            timestamp: Date.now(),
          },
        ]);
      }),
    ];
    return () => unsubs.forEach((fn) => fn());
  }, [gameMode]);

  const handleStartCampaignMission = (mission: MissionDef) => {
    audioEngine.unlock();
    setGameMode('campaign');
    setActiveMission(mission);
    setMissionResult(null);
    setPaused(false);
    setKillFeed([]);
    engineRef.current?.setLoadout(
      profile.selectedCharacter,
      profile.selectedSkin,
      profile.primaryWeapon,
      profile.secondaryWeapon
    );
    engineRef.current?.startCampaignMission(mission);
    setScreen('playing');
  };

  const handleExitToMenu = () => {
    if (gameMode !== 'campaign') {
      mpClient.leaveRoom();
    }
    setPaused(false);
    setMissionResult(null);
    setActiveMission(null);
    engineRef.current?.enterMenuDiorama();
    setScreen('menu');
  };

  // Armory Handlers
  const persistLoadout = (next: PlayerProfile) => {
    setProfile(next);
    void saveLoadoutToCloud(next).catch(console.error);
  };

  const persistProgress = (next: PlayerProfile) => {
    setProfile(next);
    saveLocalProfile(next);
    if (auth.currentUser && next.userId === auth.currentUser.uid) {
      void saveProgressionToCloud(next).catch(console.error);
    }
  };

  return (
    <div className="w-screen h-screen bg-[#030508] flex items-center justify-center overflow-hidden">
      <div className="stage-16-9 shadow-[0_0_60px_rgba(0,0,0,0.95)] ring-1 ring-slate-800/70">
        {/* Dedicated Isolated WebGL Container (16:9) */}
        <div ref={canvasMountRef} className="absolute inset-0 z-0" />

      {screen === 'menu' && (
        <TitleMenu
          profile={profile}
          authUser={authUser}
          isFullscreen={isFullscreen}
          onToggleFullscreen={handleToggleFullscreen}
          onSignIn={() => void signInWithGoogleAccount().catch(console.error)}
          onSignOut={() => void signOutAccount().catch(console.error)}
          onOpenCampaign={() => setScreen('campaign')}
          onOpenMultiplayer={() => setScreen('multiplayer')}
          onOpenArmory={() => setScreen('armory')}
          onOpenLeaderboard={() => setShowLeaderboard(true)}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}

      {screen === 'campaign' && (
        <CampaignSelect
          profile={profile}
          onStartMission={handleStartCampaignMission}
          onBack={() => setScreen('menu')}
        />
      )}

      {screen === 'multiplayer' && (
        <MultiplayerLobby
          profile={profile}
          connected={mpConnected}
          localPlayerId={mpPlayerId}
          room={mpRoom}
          chatMessages={mpChat}
          errorMsg={mpError}
          onClearError={() => setMpError(null)}
          onBack={() => setScreen('menu')}
        />
      )}

      {screen === 'armory' && (
        <ArmoryScreen
          profile={profile}
          onUpdateCallsign={(callsign) => {
            const clean = callsign.trim().slice(0, 24);
            if (clean.length >= 2) {
              persistLoadout({ ...profile, callsign: clean });
            }
          }}
          onEquipWeapon={(weaponId: WeaponId) => {
            persistLoadout({ ...profile, primaryWeapon: weaponId });
          }}
          onUnlockWeapon={(weaponId: WeaponId, cost: number) => {
            if (profile.credits < cost || profile.unlockedWeapons.includes(weaponId)) return;
            persistProgress({
              ...profile,
              credits: profile.credits - cost,
              unlockedWeapons: [...profile.unlockedWeapons, weaponId],
              primaryWeapon: weaponId,
            });
          }}
          onEquipCharacter={(characterId: CharacterId) => {
            persistLoadout({ ...profile, selectedCharacter: characterId });
          }}
          onUnlockCharacter={(characterId: CharacterId, cost: number) => {
            const tag = `char_${characterId}` as SkinId;
            if (profile.credits < cost) return;
            persistProgress({
              ...profile,
              credits: profile.credits - cost,
              unlockedSkins: Array.from(new Set([...profile.unlockedSkins, tag])),
              selectedCharacter: characterId,
            });
          }}
          onEquipSkin={(skinId: SkinId) => {
            persistLoadout({ ...profile, selectedSkin: skinId });
          }}
          onUnlockSkin={(skinId: SkinId, cost: number) => {
            if (profile.credits < cost || profile.unlockedSkins.includes(skinId)) return;
            persistProgress({
              ...profile,
              credits: profile.credits - cost,
              unlockedSkins: [...profile.unlockedSkins, skinId],
              selectedSkin: skinId,
            });
          }}
          onBack={() => setScreen('menu')}
        />
      )}

      {screen === 'playing' && (
        <GameHUD
          engineRef={engineRef}
          mode={gameMode}
          mission={activeMission}
          room={mpRoom}
          localPlayerId={mpPlayerId}
          hud={hud}
          settings={settings}
          paused={paused}
          missionResult={missionResult}
          killFeed={killFeed}
          chatMessages={mpChat}
          onResume={() => {
            setPaused(false);
            engineRef.current?.setPaused(false);
            if (window.matchMedia('(pointer: fine)').matches) {
              engineRef.current?.requestPointerLock();
            }
          }}
          onPause={() => {
            setPaused(true);
            engineRef.current?.setPaused(true);
          }}
          onOpenSettings={() => setShowSettings(true)}
          onOpenLayoutEditor={() => setShowLayoutEditor(true)}
          onRestartMission={() => {
            if (activeMission) handleStartCampaignMission(activeMission);
          }}
          onNextMission={() => {
            if (activeMission && activeMission.id < 10) {
              handleStartCampaignMission(getMissionById(activeMission.id + 1));
            }
          }}
          onExitToMenu={handleExitToMenu}
        />
      )}

      {showSettings && (
        <SettingsModal
          settings={settings}
          isFullscreen={isFullscreen}
          onToggleFullscreen={handleToggleFullscreen}
          onChange={handleUpdateSettings}
          onOpenLayoutEditor={() => {
            setShowSettings(false);
            setShowLayoutEditor(true);
          }}
          onClose={() => setShowSettings(false)}
        />
      )}

      {showLayoutEditor && (
        <HudLayoutEditor
          initialLayout={settings.hudLayout}
          onSave={(hudLayout) => {
            handleUpdateSettings({ ...settings, hudLayout });
            setShowLayoutEditor(false);
          }}
          onCancel={() => setShowLayoutEditor(false)}
        />
      )}

      {showLeaderboard && (
        <LeaderboardModal
          isSignedIn={Boolean(authUser)}
          onSignIn={() => void signInWithGoogleAccount().catch(console.error)}
          onClose={() => setShowLeaderboard(false)}
        />
      )}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}
