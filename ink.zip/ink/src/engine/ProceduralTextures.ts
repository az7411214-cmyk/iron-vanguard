import * as THREE from 'three';
import { SKINS } from '../game/characters';
import type { SkinId } from '../game/types';

export interface TextureBundle {
  asphalt: THREE.CanvasTexture;
  concrete: THREE.CanvasTexture;
  desertSand: THREE.CanvasTexture;
  mountainRock: THREE.CanvasTexture;
  citadelMetal: THREE.CanvasTexture;
  containerMetal: THREE.CanvasTexture;
  woodCrate: THREE.CanvasTexture;
  sandbag: THREE.CanvasTexture;
  water: THREE.CanvasTexture;
  bumpRough: THREE.CanvasTexture;
  camoSkins: Record<SkinId, THREE.CanvasTexture>;
  contactShadow: THREE.CanvasTexture;
  dispose: () => void;
}

function makeCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  return [c, ctx];
}

function finalizeTexture(
  canvas: HTMLCanvasElement,
  anisotropy: number,
  srgb: boolean,
  repeatX = 1,
  repeatY = 1
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = anisotropy;
  tex.needsUpdate = true;
  return tex;
}

function createNoiseBumpTexture(anisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(256, 256);
  const img = ctx.createImageData(256, 256);
  for (let i = 0; i < img.data.length; i += 4) {
    const v = 100 + Math.floor(Math.random() * 110);
    img.data[i] = v;
    img.data[i + 1] = v;
    img.data[i + 2] = v;
    img.data[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return finalizeTexture(c, anisotropy, false, 6, 6);
}

function createAsphaltTexture(anisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(512, 512);
  ctx.fillStyle = '#25282c';
  ctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 9000; i++) {
    const shade = 26 + Math.floor(Math.random() * 28);
    ctx.fillStyle = `rgb(${shade},${shade},${shade + 3})`;
    ctx.fillRect(Math.random() * 512, Math.random() * 512, 2, 2);
  }
  ctx.strokeStyle = 'rgba(230, 185, 65, 0.35)';
  ctx.lineWidth = 8;
  ctx.setLineDash([36, 28]);
  ctx.beginPath();
  ctx.moveTo(256, 0);
  ctx.lineTo(256, 512);
  ctx.stroke();
  return finalizeTexture(c, anisotropy, true, 16, 16);
}

function createConcreteTexture(anisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(512, 512);
  ctx.fillStyle = '#6c7075';
  ctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 6500; i++) {
    const s = 88 + Math.floor(Math.random() * 44);
    ctx.fillStyle = `rgba(${s},${s},${s - 2},0.45)`;
    ctx.fillRect(Math.random() * 512, Math.random() * 512, 3, 3);
  }
  ctx.strokeStyle = 'rgba(30, 34, 38, 0.45)';
  ctx.lineWidth = 3;
  for (let p = 0; p < 512; p += 128) {
    ctx.beginPath();
    ctx.moveTo(p, 0);
    ctx.lineTo(p, 512);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, p);
    ctx.lineTo(512, p);
    ctx.stroke();
  }
  return finalizeTexture(c, anisotropy, true, 4, 4);
}

function createDesertSandTexture(anisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(512, 512);
  ctx.fillStyle = '#c49d68';
  ctx.fillRect(0, 0, 512, 512);
  for (let y = 0; y < 512; y += 6) {
    const wave = Math.sin(y * 0.08) * 14;
    ctx.fillStyle = wave > 0 ? 'rgba(222, 184, 128, 0.25)' : 'rgba(138, 98, 54, 0.2)';
    ctx.fillRect(0, y, 512, 4);
  }
  for (let i = 0; i < 6000; i++) {
    const r = 175 + Math.floor(Math.random() * 55);
    const g = 135 + Math.floor(Math.random() * 45);
    const b = 80 + Math.floor(Math.random() * 35);
    ctx.fillStyle = `rgba(${r},${g},${b},0.45)`;
    ctx.fillRect(Math.random() * 512, Math.random() * 512, 2, 2);
  }
  return finalizeTexture(c, anisotropy, true, 18, 18);
}

function createMountainRockTexture(anisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(512, 512);
  ctx.fillStyle = '#4e555e';
  ctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 1200; i++) {
    const s = 50 + Math.floor(Math.random() * 65);
    ctx.fillStyle = `rgba(${s},${s + 4},${s + 8},0.35)`;
    ctx.fillRect(Math.random() * 512, Math.random() * 512, 14, 7);
  }
  return finalizeTexture(c, anisotropy, true, 12, 12);
}

function createCitadelMetalTexture(anisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(512, 512);
  ctx.fillStyle = '#1f2329';
  ctx.fillRect(0, 0, 512, 512);
  ctx.strokeStyle = '#333a44';
  ctx.lineWidth = 2;
  for (let x = 0; x < 512; x += 32) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 512);
    ctx.stroke();
  }
  for (let y = 0; y < 512; y += 32) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }
  // Hazard stripe border
  ctx.fillStyle = '#d97706';
  for (let i = -64; i < 512; i += 32) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i + 16, 0);
    ctx.lineTo(i + 32, 18);
    ctx.lineTo(i + 16, 18);
    ctx.closePath();
    ctx.fill();
  }
  return finalizeTexture(c, anisotropy, true, 8, 8);
}

function createContainerTexture(anisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(512, 512);
  ctx.fillStyle = '#b7c1c9';
  ctx.fillRect(0, 0, 512, 512);
  for (let x = 0; x < 512; x += 24) {
    ctx.fillStyle = 'rgba(0,0,0,0.22)';
    ctx.fillRect(x, 0, 8, 512);
    ctx.fillStyle = 'rgba(255,255,255,0.16)';
    ctx.fillRect(x + 8, 0, 6, 512);
  }
  ctx.fillStyle = 'rgba(110, 52, 24, 0.16)';
  for (let i = 0; i < 18; i++) {
    ctx.fillRect(Math.random() * 512, Math.random() * 512, 42, 18);
  }
  return finalizeTexture(c, anisotropy, true, 1, 1);
}

function createWoodCrateTexture(anisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(256, 256);
  ctx.fillStyle = '#6c5234';
  ctx.fillRect(0, 0, 256, 256);
  ctx.strokeStyle = '#3b2b18';
  ctx.lineWidth = 6;
  ctx.strokeRect(6, 6, 244, 244);
  for (let y = 32; y < 256; y += 36) {
    ctx.fillStyle = 'rgba(30,20,10,0.35)';
    ctx.fillRect(0, y, 256, 3);
  }
  ctx.fillStyle = 'rgba(245, 180, 60, 0.55)';
  ctx.fillRect(24, 112, 208, 28);
  return finalizeTexture(c, anisotropy, true, 1, 1);
}

function createSandbagTexture(anisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(256, 256);
  ctx.fillStyle = '#9c8a66';
  ctx.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 32) {
    ctx.fillStyle = 'rgba(40, 32, 20, 0.25)';
    ctx.fillRect(0, y, 256, 4);
    for (let x = (y % 64 === 0 ? 0 : 32); x < 256; x += 64) {
      ctx.fillRect(x, y, 4, 32);
    }
  }
  return finalizeTexture(c, anisotropy, true, 2, 1);
}

function createWaterTexture(anisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(512, 512);
  ctx.fillStyle = '#123147';
  ctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 650; i++) {
    ctx.fillStyle = 'rgba(72, 155, 198, 0.16)';
    ctx.fillRect(Math.random() * 512, Math.random() * 512, 34, 3);
  }
  return finalizeTexture(c, anisotropy, true, 10, 10);
}

function createCamoTexture(skinId: SkinId, anisotropy: number): THREE.CanvasTexture {
  const skin = SKINS[skinId];
  const [c, ctx] = makeCanvas(256, 256);
  const base = new THREE.Color(skin.primaryHex);
  const sec = new THREE.Color(skin.secondaryHex);
  const acc = new THREE.Color(skin.accentHex);

  ctx.fillStyle = `#${base.getHexString()}`;
  ctx.fillRect(0, 0, 256, 256);

  ctx.fillStyle = `#${sec.getHexString()}`;
  for (let i = 0; i < 120; i++) {
    ctx.fillRect(
      Math.floor(Math.random() * 16) * 16,
      Math.floor(Math.random() * 16) * 16,
      24 + Math.random() * 18,
      12 + Math.random() * 16
    );
  }

  ctx.fillStyle = `#${acc.getHexString()}`;
  ctx.globalAlpha = 0.22;
  for (let i = 0; i < 24; i++) {
    ctx.fillRect(
      Math.floor(Math.random() * 16) * 16,
      Math.floor(Math.random() * 16) * 16,
      14,
      8
    );
  }
  ctx.globalAlpha = 1;
  return finalizeTexture(c, anisotropy, true, 2, 2);
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(128, 128);
  const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 62);
  grad.addColorStop(0, 'rgba(0,0,0,0.68)');
  grad.addColorStop(0.6, 'rgba(0,0,0,0.28)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createTextureBundle(renderer: THREE.WebGLRenderer): TextureBundle {
  const anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy() || 1);

  const asphalt = createAsphaltTexture(anisotropy);
  const concrete = createConcreteTexture(anisotropy);
  const desertSand = createDesertSandTexture(anisotropy);
  const mountainRock = createMountainRockTexture(anisotropy);
  const citadelMetal = createCitadelMetalTexture(anisotropy);
  const containerMetal = createContainerTexture(anisotropy);
  const woodCrate = createWoodCrateTexture(anisotropy);
  const sandbag = createSandbagTexture(anisotropy);
  const water = createWaterTexture(anisotropy);
  const bumpRough = createNoiseBumpTexture(anisotropy);
  const contactShadow = createContactShadowTexture();

  const camoSkins: Record<SkinId, THREE.CanvasTexture> = {
    olive: createCamoTexture('olive', anisotropy),
    desert: createCamoTexture('desert', anisotropy),
    nightops: createCamoTexture('nightops', anisotropy),
    arctic: createCamoTexture('arctic', anisotropy),
    crimson: createCamoTexture('crimson', anisotropy),
  };

  return {
    asphalt,
    concrete,
    desertSand,
    mountainRock,
    citadelMetal,
    containerMetal,
    woodCrate,
    sandbag,
    water,
    bumpRough,
    camoSkins,
    contactShadow,
    dispose: () => {
      asphalt.dispose();
      concrete.dispose();
      desertSand.dispose();
      mountainRock.dispose();
      citadelMetal.dispose();
      containerMetal.dispose();
      woodCrate.dispose();
      sandbag.dispose();
      water.dispose();
      bumpRough.dispose();
      contactShadow.dispose();
      Object.values(camoSkins).forEach((t) => t.dispose());
    },
  };
}
