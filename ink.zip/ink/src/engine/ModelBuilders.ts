import * as THREE from 'three';
import { CHARACTERS, SKINS } from '../game/characters';
import type { CharacterId, SkinId, WeaponId } from '../game/types';
import type { TextureBundle } from './ProceduralTextures';

export interface SoldierRig {
  root: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  muzzlePoint: THREE.Object3D;
  bodyHitbox: THREE.Mesh;
  headHitbox: THREE.Mesh;
}

export function buildWeaponMesh(weaponId: WeaponId, includeHands = false, skinId: SkinId = 'olive', textures?: TextureBundle): THREE.Group {
  const group = new THREE.Group();

  const gunMetal = new THREE.MeshStandardMaterial({
    color: weaponId === 'scarh' ? 0xb59c72 : weaponId === 'awm' ? 0x3b4a3a : 0x22262b,
    metalness: 0.85,
    roughness: 0.28,
  });
  const darkPolymer = new THREE.MeshStandardMaterial({
    color: 0x15181c,
    metalness: 0.2,
    roughness: 0.72,
  });
  const woodTrim = new THREE.MeshStandardMaterial({
    color: 0x6e3d21,
    metalness: 0.05,
    roughness: 0.65,
  });
  const opticGlass = new THREE.MeshPhysicalMaterial({
    color: 0x1e88e5,
    metalness: 0.1,
    roughness: 0.05,
    clearcoat: 1.0,
    emissive: 0x0a2e4a,
    emissiveIntensity: 0.5,
  });

  if (weaponId === 'p226') {
    // Pistol: Slide, Frame, Grip, Barrel, Trigger Guard, Sight
    const slide = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.04, 0.21), gunMetal);
    slide.position.set(0, 0.04, -0.02);
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.025, 0.18), darkPolymer);
    frame.position.set(0, 0.014, -0.01);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.11, 0.05), darkPolymer);
    grip.position.set(0, -0.04, 0.05);
    grip.rotation.x = 0.24;
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.05, 10), gunMetal);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.04, -0.14);
    const frontSight = new THREE.Mesh(new THREE.BoxGeometry(0.006, 0.01, 0.01), new THREE.MeshStandardMaterial({ color: 0x22c55e, emissive: 0x22c55e }));
    frontSight.position.set(0, 0.065, -0.11);
    group.add(slide, frame, grip, barrel, frontSight);
  } else {
    // Rifle / SMG / Shotgun / Sniper / LMG
    const isSniper = weaponId === 'awm';
    const isSmg = weaponId === 'mp5sd';
    const isShotgun = weaponId === 'spas12';
    const isLmg = weaponId === 'm249';
    const isAk = weaponId === 'ak74m';

    const receiverLen = isSmg ? 0.26 : isSniper ? 0.36 : 0.32;
    const receiver = new THREE.Mesh(
      new THREE.BoxGeometry(0.052, 0.075, receiverLen),
      gunMetal
    );
    receiver.position.set(0, 0.02, 0);
    group.add(receiver);

    const handguardLen = isSmg ? 0.18 : isSniper ? 0.28 : isLmg ? 0.26 : 0.24;
    const handguard = new THREE.Mesh(
      new THREE.BoxGeometry(0.046, 0.056, handguardLen),
      isAk ? woodTrim : darkPolymer
    );
    handguard.position.set(0, 0.022, -(receiverLen * 0.5 + handguardLen * 0.5 - 0.02));
    group.add(handguard);

    // Barrel
    const barrelLen = isSniper ? 0.52 : isSmg ? 0.2 : isShotgun ? 0.36 : 0.32;
    const barrelRadius = isSmg ? 0.019 : isShotgun ? 0.016 : 0.011;
    const barrel = new THREE.Mesh(
      new THREE.CylinderGeometry(barrelRadius, barrelRadius, barrelLen, 12),
      isSmg ? darkPolymer : gunMetal
    );
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.03, -(receiverLen * 0.5 + handguardLen * 0.5 + barrelLen * 0.35));
    group.add(barrel);

    // Under-barrel tube for shotgun or gas block for rifles
    if (isShotgun) {
      const pump = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.24, 12), darkPolymer);
      pump.rotation.x = Math.PI / 2;
      pump.position.set(0, -0.004, -0.28);
      group.add(pump);
    } else if (isLmg) {
      // Box ammo drum
      const drum = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.13, 0.11), new THREE.MeshStandardMaterial({ color: 0x3b4d36, roughness: 0.65, metalness: 0.3 }));
      drum.position.set(-0.02, -0.08, -0.02);
      const feedTray = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.03, 0.12), gunMetal);
      feedTray.position.set(0, 0.065, -0.01);
      group.add(drum, feedTray);
    } else {
      // Magazine
      const magH = isSniper ? 0.08 : 0.14;
      const mag = new THREE.Mesh(new THREE.BoxGeometry(0.032, magH, 0.062), darkPolymer);
      mag.position.set(0, -0.065, -0.05);
      mag.rotation.x = isAk ? -0.22 : -0.1;
      group.add(mag);
    }

    // Pistol grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.1, 0.044), darkPolymer);
    grip.position.set(0, -0.055, 0.09);
    grip.rotation.x = 0.28;
    group.add(grip);

    // Stock
    const stock = new THREE.Mesh(
      new THREE.BoxGeometry(0.04, 0.085, 0.22),
      isAk ? woodTrim : darkPolymer
    );
    stock.position.set(0, 0.005, receiverLen * 0.5 + 0.1);
    group.add(stock);

    // Optic / Scope
    if (isSniper) {
      const scopeTube = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.02, 0.26, 14), darkPolymer);
      scopeTube.rotation.x = Math.PI / 2;
      scopeTube.position.set(0, 0.092, -0.02);
      const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.01, 14), opticGlass);
      lens.rotation.x = Math.PI / 2;
      lens.position.set(0, 0.092, 0.11);
      group.add(scopeTube, lens);
    } else if (!isShotgun) {
      const opticHousing = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.036, 0.075), darkPolymer);
      opticHousing.position.set(0, 0.078, 0.01);
      const opticLens = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.024, 0.008), opticGlass);
      opticLens.position.set(0, 0.078, 0.048);
      group.add(opticHousing, opticLens);
    }

    // Muzzle brake
    if (!isSmg) {
      const muzzle = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.014, 0.045, 10), gunMetal);
      muzzle.rotation.x = Math.PI / 2;
      muzzle.position.set(0, 0.03, barrel.position.z - barrelLen * 0.5);
      group.add(muzzle);
    }
  }

  if (includeHands) {
    const skinDef = SKINS[skinId];
    const sleeveMat = new THREE.MeshStandardMaterial({
      color: skinDef.primaryHex,
      map: textures ? textures.camoSkins[skinId] : null,
      roughness: 0.78,
      metalness: 0.08,
    });
    const gloveMat = new THREE.MeshStandardMaterial({
      color: 0x1c1f24,
      roughness: 0.85,
      metalness: 0.05,
    });

    const rightHand = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.065, 0.07), gloveMat);
    rightHand.position.set(0, -0.055, 0.09);
    const rightForearm = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.048, 0.34, 10), sleeveMat);
    rightForearm.rotation.x = Math.PI * 0.46;
    rightForearm.rotation.z = -0.22;
    rightForearm.position.set(0.09, -0.1, 0.25);

    const leftHand = new THREE.Mesh(new THREE.BoxGeometry(0.058, 0.06, 0.075), gloveMat);
    leftHand.position.set(-0.01, -0.015, weaponId === 'p226' ? 0.04 : -0.18);
    const leftForearm = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.046, 0.36, 10), sleeveMat);
    leftForearm.rotation.x = Math.PI * 0.42;
    leftForearm.rotation.z = 0.42;
    leftForearm.position.set(-0.14, -0.1, 0.0);

    group.add(rightHand, rightForearm, leftHand, leftForearm);
  }

  group.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = false;
      obj.receiveShadow = false;
    }
  });

  return group;
}

export function buildSoldierModel(opts: {
  actorId: string;
  characterId: CharacterId;
  skinId: SkinId;
  teamColorHex: number;
  weaponId: WeaponId;
  textures: TextureBundle;
  isBoss?: boolean;
  isCivilian?: boolean;
}): SoldierRig {
  const root = new THREE.Group();
  const charDef = CHARACTERS[opts.characterId];
  const skinDef = SKINS[opts.skinId];
  const scale = opts.isBoss ? 1.38 : 1.0;

  const uniformMat = new THREE.MeshStandardMaterial({
    color: opts.isCivilian ? 0x2563eb : skinDef.primaryHex,
    map: opts.isCivilian ? null : opts.textures.camoSkins[opts.skinId],
    roughness: 0.78,
    metalness: 0.08,
  });
  const armorMat = new THREE.MeshStandardMaterial({
    color: opts.isBoss ? 0x1a1517 : skinDef.secondaryHex,
    roughness: 0.42,
    metalness: opts.isBoss ? 0.65 : 0.35,
  });
  const skinToneMat = new THREE.MeshStandardMaterial({
    color: 0xc99674,
    roughness: 0.7,
    metalness: 0.02,
  });
  const bootMat = new THREE.MeshStandardMaterial({
    color: 0x181a1f,
    roughness: 0.85,
    metalness: 0.1,
  });
  const teamBandMat = new THREE.MeshStandardMaterial({
    color: opts.teamColorHex,
    emissive: opts.teamColorHex,
    emissiveIntensity: 0.45,
    roughness: 0.35,
    metalness: 0.2,
  });

  // Contact shadow disc grounded at y=0.02
  const shadowPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(1.15, 1.15),
    new THREE.MeshBasicMaterial({
      map: opts.textures.contactShadow,
      transparent: true,
      depthWrite: false,
      opacity: 0.55,
    })
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = 0.02;
  root.add(shadowPlane);

  // Legs (pivot at hip y = 0.86)
  const makeLeg = (xOffset: number) => {
    const legGroup = new THREE.Group();
    legGroup.position.set(xOffset, 0.86, 0);
    const thigh = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.42, 0.2), uniformMat);
    thigh.position.y = -0.21;
    const kneePad = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.12, 0.22), armorMat);
    kneePad.position.y = -0.43;
    const shin = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.36, 0.18), uniformMat);
    shin.position.y = -0.64;
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.12, 0.26), bootMat);
    boot.position.set(0, -0.8, 0.03);
    legGroup.add(thigh, kneePad, shin, boot);
    return legGroup;
  };
  const leftLeg = makeLeg(-0.13);
  const rightLeg = makeLeg(0.13);
  root.add(leftLeg, rightLeg);

  // Torso (pivot at waist y = 0.88)
  const torso = new THREE.Group();
  torso.position.set(0, 0.88, 0);
  const chest = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.54, 0.26), uniformMat);
  chest.position.y = 0.27;
  const plateVest = new THREE.Mesh(new THREE.BoxGeometry(0.49, 0.4, 0.31), armorMat);
  plateVest.position.y = 0.3;
  const pouch1 = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.06), bootMat);
  pouch1.position.set(-0.12, 0.22, 0.17);
  const pouch2 = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.06), bootMat);
  pouch2.position.set(0.12, 0.22, 0.17);
  const backpack = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.36, 0.14), armorMat);
  backpack.position.set(0, 0.32, -0.19);
  const teamBand = new THREE.Mesh(new THREE.BoxGeometry(0.51, 0.06, 0.32), teamBandMat);
  teamBand.position.set(0, 0.45, 0);
  torso.add(chest, plateVest, pouch1, pouch2, backpack, teamBand);
  root.add(torso);

  // Head (pivot at neck y = 0.56 relative to torso)
  const head = new THREE.Group();
  head.position.set(0, 0.58, 0);
  const skull = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.26, 0.25), skinToneMat);
  skull.position.y = 0.13;
  head.add(skull);

  if (!opts.isCivilian) {
    const hType = charDef.helmetType;
    const helmetColor = opts.isBoss
      ? 0x7f1d1d
      : hType === 'beret'
        ? 0x991b1b
        : hType === 'medic'
          ? 0xecfdf5
          : hType === 'pyro'
            ? 0x431407
            : hType === 'juggernaut'
              ? 0x334155
              : armorMat.color.getHex();
    const helmetMat = new THREE.MeshStandardMaterial({
      color: helmetColor,
      roughness: 0.42,
      metalness: hType === 'juggernaut' ? 0.65 : 0.35,
    });
    const helmet = new THREE.Mesh(
      new THREE.BoxGeometry(
        hType === 'juggernaut' ? 0.32 : 0.28,
        hType === 'beret' ? 0.1 : hType === 'juggernaut' ? 0.22 : 0.17,
        hType === 'juggernaut' ? 0.32 : 0.29
      ),
      helmetMat
    );
    helmet.position.y = hType === 'beret' ? 0.24 : 0.2;
    head.add(helmet);

    if (hType === 'medic') {
      const crossMat = new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x059669, emissiveIntensity: 0.45 });
      const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.1, 0.02), crossMat);
      crossV.position.set(0, 0.22, 0.15);
      const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.04, 0.02), crossMat);
      crossH.position.set(0, 0.22, 0.15);
      head.add(crossV, crossH);
    } else if (hType === 'pyro') {
      const breather = new THREE.Mesh(
        new THREE.CylinderGeometry(0.06, 0.07, 0.1, 10),
        new THREE.MeshStandardMaterial({ color: 0xf97316, emissive: 0x9a3412, emissiveIntensity: 0.4, metalness: 0.6, roughness: 0.3 })
      );
      breather.rotation.x = Math.PI / 2;
      breather.position.set(0, 0.07, 0.15);
      head.add(breather);
    } else if (hType === 'recon') {
      const nvgMat = new THREE.MeshStandardMaterial({ color: 0x06b6d4, emissive: 0x0891b2, emissiveIntensity: 0.6, metalness: 0.7, roughness: 0.2 });
      const lensL = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.08, 10), nvgMat);
      lensL.rotation.x = Math.PI / 2;
      lensL.position.set(-0.065, 0.17, 0.16);
      const lensR = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.08, 10), nvgMat);
      lensR.rotation.x = Math.PI / 2;
      lensR.position.set(0.065, 0.17, 0.16);
      head.add(lensL, lensR);
    }

    const visorColor = opts.isBoss
      ? 0xef4444
      : hType === 'pyro'
        ? 0xf97316
        : hType === 'recon'
          ? 0x06b6d4
          : hType === 'juggernaut'
            ? 0xfacc15
            : hType === 'medic'
              ? 0x10b981
              : 0x0ea5e9;
    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(hType === 'juggernaut' ? 0.26 : 0.23, hType === 'juggernaut' ? 0.11 : 0.08, 0.05),
      new THREE.MeshPhysicalMaterial({
        color: visorColor,
        emissive: visorColor,
        emissiveIntensity: 0.45,
        roughness: 0.1,
        metalness: 0.4,
      })
    );
    visor.position.set(0, 0.16, 0.13);
    head.add(visor);
  }
  torso.add(head);

  // Arms
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.3, 0.48, 0);
  const lUpper = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.44, 0.14), uniformMat);
  lUpper.position.set(0, -0.18, 0.08);
  lUpper.rotation.x = -0.6;
  leftArm.add(lUpper);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.3, 0.48, 0);
  const rUpper = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.44, 0.14), uniformMat);
  rUpper.position.set(0, -0.18, 0.1);
  rUpper.rotation.x = -1.05;
  rightArm.add(rUpper);

  const muzzlePoint = new THREE.Object3D();
  muzzlePoint.position.set(0, -0.24, 0.58);
  rightArm.add(muzzlePoint);

  if (!opts.isCivilian) {
    const weaponMesh = buildWeaponMesh(opts.weaponId, false, opts.skinId);
    weaponMesh.rotation.y = Math.PI;
    weaponMesh.position.set(-0.08, -0.24, 0.26);
    rightArm.add(weaponMesh);
  }

  torso.add(leftArm, rightArm);

  // Invisible fast-raycast Hitboxes (tagged for headshot / body detection)
  const hitboxMat = new THREE.MeshBasicMaterial({ visible: false });
  const bodyHitbox = new THREE.Mesh(new THREE.BoxGeometry(0.68, 1.35, 0.55), hitboxMat);
  bodyHitbox.position.set(0, 0.72, 0);
  bodyHitbox.userData = { actorId: opts.actorId, hitPart: 'body' };

  const headHitbox = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.36, 0.4), hitboxMat);
  headHitbox.position.set(0, 1.56, 0);
  headHitbox.userData = { actorId: opts.actorId, hitPart: 'head' };

  root.add(bodyHitbox, headHitbox);
  root.scale.setScalar(scale);

  root.traverse((obj) => {
    const m = obj as THREE.Mesh;
    if (m.isMesh && m !== shadowPlane && m !== bodyHitbox && m !== headHitbox) {
      m.castShadow = true;
      m.receiveShadow = true;
    }
  });

  return {
    root,
    leftLeg,
    rightLeg,
    leftArm,
    rightArm,
    torso,
    head,
    muzzlePoint,
    bodyHitbox,
    headHitbox,
  };
}

export function buildArmoredVehicle(colorHex = 0x4b5340, textures?: TextureBundle): THREE.Group {
  const g = new THREE.Group();
  const hullMat = new THREE.MeshStandardMaterial({
    color: colorHex,
    map: textures ? textures.concrete : null,
    roughness: 0.6,
    metalness: 0.35,
  });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x1c2026, roughness: 0.35, metalness: 0.8 });
  const tireMat = new THREE.MeshStandardMaterial({ color: 0x121417, roughness: 0.9, metalness: 0.05 });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x162938,
    roughness: 0.1,
    metalness: 0.2,
    clearcoat: 1,
  });

  // Lower chassis
  const chassis = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.85, 5.2), hullMat);
  chassis.position.y = 0.95;
  // Upper cabin
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(2.25, 0.9, 2.7), hullMat);
  cabin.position.set(0, 1.8, -0.2);
  // Sloped hood
  const hood = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.55, 1.45), hullMat);
  hood.position.set(0, 1.35, 1.75);
  hood.rotation.x = 0.12;
  // Windshield
  const windshield = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.52, 0.1), glassMat);
  windshield.position.set(0, 1.82, 1.15);
  windshield.rotation.x = -0.28;
  // Roof turret ring + gun
  const turretRing = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.55, 0.26, 12), metalMat);
  turretRing.position.set(0, 2.35, -0.2);
  const turretGun = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 1.4, 8), metalMat);
  turretGun.rotation.x = Math.PI / 2;
  turretGun.position.set(0, 2.52, 0.45);
  // Bumpers
  const bumper = new THREE.Mesh(new THREE.BoxGeometry(2.55, 0.35, 0.35), metalMat);
  bumper.position.set(0, 0.72, 2.65);

  g.add(chassis, cabin, hood, windshield, turretRing, turretGun, bumper);

  // 4 Wheels + rims
  const wheelGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.42, 14);
  wheelGeo.rotateZ(Math.PI / 2);
  const rimGeo = new THREE.CylinderGeometry(0.28, 0.28, 0.44, 10);
  rimGeo.rotateZ(Math.PI / 2);
  const wheelCoords = [
    [-1.3, 0.55, 1.65],
    [1.3, 0.55, 1.65],
    [-1.3, 0.55, -1.65],
    [1.3, 0.55, -1.65],
  ];
  for (const [wx, wy, wz] of wheelCoords) {
    const tire = new THREE.Mesh(wheelGeo, tireMat);
    tire.position.set(wx, wy, wz);
    const rim = new THREE.Mesh(rimGeo, metalMat);
    rim.position.set(wx, wy, wz);
    g.add(tire, rim);
  }

  g.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });
  return g;
}

export function buildShippingContainer(colorHex: number, textures: TextureBundle): THREE.Group {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({
    color: colorHex,
    map: textures.containerMetal,
    bumpMap: textures.bumpRough,
    bumpScale: 0.04,
    roughness: 0.58,
    metalness: 0.45,
  });
  const frameMat = new THREE.MeshStandardMaterial({
    color: 0x1d2228,
    roughness: 0.45,
    metalness: 0.75,
  });
  const main = new THREE.Mesh(new THREE.BoxGeometry(3.0, 2.9, 6.8), bodyMat);
  main.position.y = 1.45;
  const topTrim = new THREE.Mesh(new THREE.BoxGeometry(3.08, 0.16, 6.88), frameMat);
  topTrim.position.y = 2.86;
  const botTrim = new THREE.Mesh(new THREE.BoxGeometry(3.08, 0.16, 6.88), frameMat);
  botTrim.position.y = 0.08;
  g.add(main, topTrim, botTrim);
  g.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });
  return g;
}

export function buildWatchtower(textures: TextureBundle): THREE.Group {
  const g = new THREE.Group();
  const steelMat = new THREE.MeshStandardMaterial({ color: 0x2f353d, roughness: 0.48, metalness: 0.7 });
  const woodMat = new THREE.MeshStandardMaterial({ map: textures.woodCrate, roughness: 0.85, metalness: 0.05 });

  // 4 stilts
  [
    [-1.4, -1.4],
    [1.4, -1.4],
    [-1.4, 1.4],
    [1.4, 1.4],
  ].forEach(([px, pz]) => {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.24, 5.5, 0.24), steelMat);
    leg.position.set(px, 2.75, pz);
    g.add(leg);
  });

  const deck = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.28, 3.6), woodMat);
  deck.position.y = 5.4;
  const wall1 = new THREE.Mesh(new THREE.BoxGeometry(3.6, 1.0, 0.2), steelMat);
  wall1.position.set(0, 6.0, 1.7);
  const wall2 = new THREE.Mesh(new THREE.BoxGeometry(3.6, 1.0, 0.2), steelMat);
  wall2.position.set(0, 6.0, -1.7);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(4.0, 0.24, 4.0), steelMat);
  roof.position.y = 8.0;
  // Pillars for roof
  [
    [-1.6, -1.6],
    [1.6, -1.6],
    [-1.6, 1.6],
    [1.6, 1.6],
  ].forEach(([px, pz]) => {
    const p = new THREE.Mesh(new THREE.BoxGeometry(0.16, 2.6, 0.16), steelMat);
    p.position.set(px, 6.7, pz);
    g.add(p);
  });
  g.add(deck, wall1, wall2, roof);
  g.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });
  return g;
}

export function buildRadarArray(): { group: THREE.Group; dish: THREE.Group } {
  const group = new THREE.Group();
  const baseMat = new THREE.MeshStandardMaterial({ color: 0x3b424d, roughness: 0.45, metalness: 0.65 });
  const dishMat = new THREE.MeshStandardMaterial({ color: 0xc8d0d8, roughness: 0.3, metalness: 0.75 });
  const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.3, 2.8, 10), baseMat);
  ped.position.y = 1.4;
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.35, 1.8, 8), baseMat);
  mast.position.y = 3.5;

  const dish = new THREE.Group();
  dish.position.y = 4.4;
  const bowl = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 0.4, 0.7, 16), dishMat);
  bowl.rotation.x = Math.PI * 0.36;
  const spike = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 1.4, 8), baseMat);
  spike.rotation.x = Math.PI * 0.36;
  spike.position.set(0, 0.35, 0.55);
  dish.add(bowl, spike);

  group.add(ped, mast, dish);
  group.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });
  return { group, dish };
}

export function buildFuelTankTarget(): THREE.Group {
  const g = new THREE.Group();
  const tankMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.42, metalness: 0.55 });
  const steelMat = new THREE.MeshStandardMaterial({ color: 0x2b3038, roughness: 0.45, metalness: 0.75 });
  const body = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 3.2, 16), tankMat);
  body.rotation.z = Math.PI / 2;
  body.position.y = 1.45;
  const stripe = new THREE.Mesh(new THREE.CylinderGeometry(1.13, 1.13, 0.45, 16), new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.4 }));
  stripe.rotation.z = Math.PI / 2;
  stripe.position.y = 1.45;
  const leg1 = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.1, 1.8), steelMat);
  leg1.position.set(-1.0, 0.55, 0);
  const leg2 = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.1, 1.8), steelMat);
  leg2.position.set(1.0, 0.55, 0);
  const beacon = new THREE.Mesh(
    new THREE.SphereGeometry(0.2, 10, 10),
    new THREE.MeshBasicMaterial({ color: 0xff4422 })
  );
  beacon.position.set(0, 2.75, 0);
  g.add(body, stripe, leg1, leg2, beacon);
  g.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });
  return g;
}

export function buildTerminalTarget(): THREE.Group {
  const g = new THREE.Group();
  const cabinetMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.35, metalness: 0.75 });
  const screenMat = new THREE.MeshStandardMaterial({
    color: 0x0ea5e9,
    emissive: 0x0284c7,
    emissiveIntensity: 1.4,
    roughness: 0.15,
  });
  const base = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.6, 0.8), cabinetMat);
  base.position.y = 0.8;
  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.55, 0.08), screenMat);
  screen.position.set(0, 1.35, 0.42);
  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.04, 0.9, 8), cabinetMat);
  antenna.position.set(0.4, 2.0, -0.2);
  const led = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), new THREE.MeshBasicMaterial({ color: 0x38bdf8 }));
  led.position.set(0.4, 2.45, -0.2);
  g.add(base, screen, antenna, led);
  return g;
}

export function buildHelicopter(): { group: THREE.Group; mainRotor: THREE.Group; tailRotor: THREE.Group } {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2c3430, roughness: 0.45, metalness: 0.55 });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x15181c, roughness: 0.35, metalness: 0.8 });
  const glassMat = new THREE.MeshPhysicalMaterial({ color: 0x1e3a5f, roughness: 0.08, clearcoat: 1 });

  const fuselage = new THREE.Mesh(new THREE.BoxGeometry(2.1, 1.8, 6.2), bodyMat);
  fuselage.position.y = 1.6;
  const nose = new THREE.Mesh(new THREE.BoxGeometry(1.85, 1.4, 1.6), glassMat);
  nose.position.set(0, 1.45, 3.6);
  nose.rotation.x = 0.25;
  const tailBoom = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.7, 5.2), bodyMat);
  tailBoom.position.set(0, 1.85, -5.2);
  const tailFin = new THREE.Mesh(new THREE.BoxGeometry(0.25, 1.6, 1.1), bodyMat);
  tailFin.position.set(0, 2.5, -7.4);
  const skidL = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 5.6, 8), darkMat);
  skidL.rotation.x = Math.PI / 2;
  skidL.position.set(-1.1, 0.2, 0.2);
  const skidR = skidL.clone();
  skidR.position.x = 1.1;

  const mainRotor = new THREE.Group();
  mainRotor.position.set(0, 2.75, 0);
  const blade1 = new THREE.Mesh(new THREE.BoxGeometry(9.6, 0.06, 0.34), darkMat);
  const blade2 = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.06, 9.6), darkMat);
  mainRotor.add(blade1, blade2);

  const tailRotor = new THREE.Group();
  tailRotor.position.set(0.35, 2.6, -7.4);
  const tBlade1 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 1.7, 0.16), darkMat);
  const tBlade2 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.16, 1.7), darkMat);
  tailRotor.add(tBlade1, tBlade2);

  group.add(fuselage, nose, tailBoom, tailFin, skidL, skidR, mainRotor, tailRotor);
  group.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });
  return { group, mainRotor, tailRotor };
}
