import type { WeaponId } from '../game/types';

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private masterGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private ambientSource: AudioBufferSourceNode | null = null;

  private masterVol = 0.8;
  private sfxVol = 0.85;
  private ambientVol = 0.4;
  private muted = false;

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();
      this.ambientGain = this.ctx.createGain();
      this.sfxGain.connect(this.masterGain);
      this.ambientGain.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);
      this.applyVolumes();
      this.buildNoiseBuffer();
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  private buildNoiseBuffer(): void {
    if (!this.ctx) return;
    const len = this.ctx.sampleRate * 1.5;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    this.noiseBuffer = buf;
  }

  setVolumes(master: number, sfx: number, ambient: number, muted: boolean): void {
    this.masterVol = master;
    this.sfxVol = sfx;
    this.ambientVol = ambient;
    this.muted = muted;
    this.applyVolumes();
  }

  private applyVolumes(): void {
    if (!this.ctx || !this.masterGain || !this.sfxGain || !this.ambientGain) return;
    const now = this.ctx.currentTime;
    this.masterGain.gain.setTargetAtTime(this.muted ? 0 : this.masterVol, now, 0.02);
    this.sfxGain.gain.setTargetAtTime(this.sfxVol, now, 0.02);
    this.ambientGain.gain.setTargetAtTime(this.ambientVol, now, 0.05);
  }

  unlock(): void {
    this.ensureContext();
  }

  playWeaponFire(weaponId: WeaponId, distanceAttenuation = 1): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain || !this.noiseBuffer || this.muted) return;
    const t = ctx.currentTime;
    const vol = Math.max(0.05, Math.min(1, distanceAttenuation));

    // Noise burst for gunshot crack
    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;

    const filter = ctx.createBiquadFilter();
    const nGain = ctx.createGain();

    // Punchy low-end body oscillator
    const osc = ctx.createOscillator();
    const oGain = ctx.createGain();

    if (weaponId === 'mp5sd') {
      // Suppressed tactical hiss
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(2200, t);
      filter.Q.setValueAtTime(1.4, t);
      nGain.gain.setValueAtTime(0.32 * vol, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(190, t);
      osc.frequency.exponentialRampToValueAtTime(75, t + 0.05);
      oGain.gain.setValueAtTime(0.28 * vol, t);
      oGain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
    } else if (weaponId === 'awm') {
      // Booming .338 magnum crack + long tail
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(4800, t);
      filter.frequency.exponentialRampToValueAtTime(320, t + 0.42);
      nGain.gain.setValueAtTime(0.95 * vol, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, t);
      osc.frequency.exponentialRampToValueAtTime(36, t + 0.25);
      oGain.gain.setValueAtTime(0.8 * vol, t);
      oGain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
    } else if (weaponId === 'spas12') {
      // Heavy shotgun blast
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(3400, t);
      filter.frequency.exponentialRampToValueAtTime(240, t + 0.3);
      nGain.gain.setValueAtTime(0.9 * vol, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.32);
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(115, t);
      osc.frequency.exponentialRampToValueAtTime(32, t + 0.18);
      oGain.gain.setValueAtTime(0.85 * vol, t);
      oGain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    } else if (weaponId === 'ak74m' || weaponId === 'scarh') {
      // Deep punchy 7.62/5.45 thump
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(weaponId === 'scarh' ? 1100 : 1400, t);
      filter.Q.setValueAtTime(0.7, t);
      nGain.gain.setValueAtTime(0.68 * vol, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(160, t);
      osc.frequency.exponentialRampToValueAtTime(48, t + 0.11);
      oGain.gain.setValueAtTime(0.6 * vol, t);
      oGain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
    } else if (weaponId === 'm249') {
      // Sharp LMG bark
      filter.type = 'highpass';
      filter.frequency.setValueAtTime(650, t);
      nGain.gain.setValueAtTime(0.58 * vol, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
      osc.type = 'square';
      osc.frequency.setValueAtTime(180, t);
      osc.frequency.exponentialRampToValueAtTime(55, t + 0.08);
      oGain.gain.setValueAtTime(0.45 * vol, t);
      oGain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
    } else if (weaponId === 'p226') {
      // Crisp 9mm pistol snap
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1950, t);
      nGain.gain.setValueAtTime(0.48 * vol, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(220, t);
      osc.frequency.exponentialRampToValueAtTime(65, t + 0.07);
      oGain.gain.setValueAtTime(0.45 * vol, t);
      oGain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    } else {
      // M4A1 balanced crisp rifle crack
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1750, t);
      filter.Q.setValueAtTime(0.8, t);
      nGain.gain.setValueAtTime(0.56 * vol, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.13);
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(175, t);
      osc.frequency.exponentialRampToValueAtTime(52, t + 0.09);
      oGain.gain.setValueAtTime(0.5 * vol, t);
      oGain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    }

    noise.connect(filter);
    filter.connect(nGain);
    nGain.connect(this.sfxGain);

    osc.connect(oGain);
    oGain.connect(this.sfxGain);

    noise.start(t);
    noise.stop(t + 0.48);
    osc.start(t);
    osc.stop(t + 0.3);
  }

  playReload(): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain || this.muted) return;
    const t = ctx.currentTime;
    // Metallic click-clack sequence
    [0, 0.45, 0.95].forEach((offset, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = idx === 1 ? 'triangle' : 'square';
      osc.frequency.setValueAtTime(idx === 0 ? 520 : idx === 1 ? 310 : 780, t + offset);
      osc.frequency.exponentialRampToValueAtTime(140, t + offset + 0.06);
      gain.gain.setValueAtTime(0.18, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.07);
      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(t + offset);
      osc.stop(t + offset + 0.08);
    });
  }

  playHitmarker(headshot: boolean): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain || this.muted) return;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = headshot ? 'sine' : 'triangle';
    osc.frequency.setValueAtTime(headshot ? 1680 : 940, t);
    osc.frequency.exponentialRampToValueAtTime(headshot ? 2350 : 540, t + 0.055);
    gain.gain.setValueAtTime(headshot ? 0.32 : 0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.065);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.07);
  }

  playExplosion(distanceAttenuation = 1): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain || !this.noiseBuffer || this.muted) return;
    const t = ctx.currentTime;
    const vol = Math.max(0.1, Math.min(1, distanceAttenuation));

    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(900, t);
    filter.frequency.exponentialRampToValueAtTime(85, t + 1.1);
    const nGain = ctx.createGain();
    nGain.gain.setValueAtTime(0.95 * vol, t);
    nGain.gain.exponentialRampToValueAtTime(0.001, t + 1.25);
    noise.connect(filter);
    filter.connect(nGain);
    nGain.connect(this.sfxGain);

    const sub = ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(95, t);
    sub.frequency.exponentialRampToValueAtTime(24, t + 0.65);
    const sGain = ctx.createGain();
    sGain.gain.setValueAtTime(0.9 * vol, t);
    sGain.gain.exponentialRampToValueAtTime(0.001, t + 0.7);
    sub.connect(sGain);
    sGain.connect(this.sfxGain);

    noise.start(t);
    noise.stop(t + 1.3);
    sub.start(t);
    sub.stop(t + 0.75);
  }

  playThunder(): void {
    this.playExplosion(0.55);
  }

  playFootstep(): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain || !this.noiseBuffer || this.muted) return;
    const t = ctx.currentTime;
    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(280, t);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.09, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    noise.start(t);
    noise.stop(t + 0.09);
  }

  playUiConfirm(victory = true): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain || this.muted) return;
    const t = ctx.currentTime;
    const notes = victory ? [440, 554.37, 659.25] : [330, 261.63, 196];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + i * 0.11);
      gain.gain.setValueAtTime(0.22, t + i * 0.11);
      gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.11 + 0.32);
      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(t + i * 0.11);
      osc.stop(t + i * 0.11 + 0.35);
    });
  }

  playAbilityActivate(): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain || this.muted) return;
    const t = ctx.currentTime;
    [392, 587.33, 880].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = i === 2 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, t + i * 0.055);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.15, t + i * 0.055 + 0.18);
      gain.gain.setValueAtTime(0.24, t + i * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.055 + 0.22);
      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(t + i * 0.055);
      osc.stop(t + i * 0.055 + 0.24);
    });
  }

  playHeal(): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain || this.muted) return;
    const t = ctx.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + i * 0.065);
      gain.gain.setValueAtTime(0.18, t + i * 0.065);
      gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.065 + 0.26);
      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(t + i * 0.065);
      osc.stop(t + i * 0.065 + 0.28);
    });
  }

  startAmbient(kind: 'wind' | 'storm' | 'none'): void {
    this.stopAmbient();
    if (kind === 'none') return;
    const ctx = this.ensureContext();
    if (!ctx || !this.ambientGain || !this.noiseBuffer) return;

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = kind === 'storm' ? 420 : 240;
    filter.Q.value = kind === 'storm' ? 0.6 : 1.2;

    const gain = ctx.createGain();
    gain.gain.value = kind === 'storm' ? 0.38 : 0.16;

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.ambientGain);
    src.start();
    this.ambientSource = src;
  }

  stopAmbient(): void {
    if (this.ambientSource) {
      try {
        this.ambientSource.stop();
        this.ambientSource.disconnect();
      } catch {
        // ignore
      }
      this.ambientSource = null;
    }
  }
}

export const audioEngine = new AudioEngine();
