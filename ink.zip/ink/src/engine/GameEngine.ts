import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { CHARACTERS } from '../game/characters';
import type {
  CharacterId,
  GameSettings,
  HudSnapshot,
  MissionDef,
  MultiplayerRoomState,
  ProjectedNametag,
  SkinId,
  TeamId,
  WeaponId,
} from '../game/types';
import { WEAPONS } from '../game/weapons';
import type { MpDeltaPacket, MpFirePacket } from '../services/multiplayerClient';
import { mpClient } from '../services/multiplayerClient';
import { audioEngine } from './AudioEngine';
import {
  buildCampaignMap,
  buildMenuDiorama,
  buildMultiplayerArena,
  type BuiltMap,
  type ColliderBox,
} from './MapBuilder';
import { buildSoldierModel, buildWeaponMesh, type SoldierRig } from './ModelBuilders';
import { ParticleSystem } from './ParticleSystem';
import { createTextureBundle, type TextureBundle } from './ProceduralTextures';

// Pre-allocated math helpers (zero GC in tick)
const _vec3 = new THREE.Vector3();
const _vec3b = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _proj = new THREE.Vector3();
const _rayOrigin = new THREE.Vector3();

interface AiUnit {
  id: string;
  isAlly: boolean;
  isCivilian: boolean;
  isBoss: boolean;
  archetype: 'rifle' | 'heavy' | 'sniper' | 'rusher';
  rig: SoldierRig;
  hp: number;
  maxHp: number;
  alive: boolean;
  x: number;
  y: number;
  z: number;
  yaw: number;
  speed: number;
  fireCooldown: number;
  strafeDir: number;
  strafeTimer: number;
  walkPhase: number;
  deathTimer: number;
  deathDir: 1 | -1;
  deathTilt: number;
  rescued?: boolean;
}

interface RemotePlayerVisual {
  id: string;
  callsign: string;
  team: TeamId;
  characterId: CharacterId;
  skinId: SkinId;
  weaponId: WeaponId;
  rig: SoldierRig;
  hp: number;
  alive: boolean;
  targetX: number;
  targetY: number;
  targetZ: number;
  targetYaw: number;
  crouching: boolean;
  moving: boolean;
  walkPhase: number;
  deathTimer: number;
  deathDir: 1 | -1;
}

interface GrenadeItem {
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  fuse: number;
}

export interface MissionResultPayload {
  victory: boolean;
  missionId: number;
  score: number;
  kills: number;
  deaths: number;
  timeSec: number;
  stars: number;
}

export interface EngineCallbacks {
  onHudUpdate: (snapshot: HudSnapshot) => void;
  onMissionEnd: (result: MissionResultPayload) => void;
  onPauseRequest: () => void;
  onLocalKillFeed?: (killer: string, victim: string, weaponId: WeaponId, headshot: boolean, isAlly: boolean) => void;
}

export class GameEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private composer: EffectComposer | null = null;
  private bloomPass: UnrealBloomPass | null = null;
  private isSoftwareGl = false;

  private textures: TextureBundle;
  private particles: ParticleSystem;
  private keyLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private muzzleLight: THREE.PointLight;
  private lightningTimer = 0;

  private settings: GameSettings;
  private callbacks: EngineCallbacks;

  private frameId = 0;
  private resizeObserver: ResizeObserver | null = null;
  private disposed = false;
  private lastFrameMs = performance.now();
  private lastRenderMs = performance.now();
  private fpsAccum = 0;
  private fpsFrames = 0;
  private currentFps = 60;
  private hudEmitTimer = 0;
  private smokeEmitTimer = 0;

  // Scene mode
  private mode: 'menu' | 'campaign' | 'multiplayer' = 'menu';
  private paused = false;
  private menuDiorama: ReturnType<typeof buildMenuDiorama> | null = null;
  private activeMap: BuiltMap | null = null;
  private currentMission: MissionDef | null = null;
  private mpRoom: MultiplayerRoomState | null = null;
  private mpLocalTeam: TeamId = 'alpha';
  private mpZonesMeshes: Array<{ id: 'A' | 'B' | 'C'; ring: THREE.Mesh; beacon: THREE.Mesh }> = [];

  // Player state
  private playerPos = new THREE.Vector3(0, 0, 38);
  private playerVelY = 0;
  private grounded = true;
  private yaw = 0;
  private pitch = 0;
  private hp = 100;
  private maxHp = 100;
  private armor = 25;
  private maxArmor = 25;
  private stamina = 100;
  private crouching = false;
  private sprinting = false;
  private ads = false;
  private grenades = 3;
  private score = 0;
  private kills = 0;
  private deaths = 0;
  private respawnTimerSec = 0;
  private stepTimer = 0;

  // Player Loadout & ViewModel
  private characterId: CharacterId = 'striker';
  private skinId: SkinId = 'olive';
  private primaryWeaponId: WeaponId = 'm4a1';
  private secondaryWeaponId: WeaponId = 'p226';
  private activeSlot: 1 | 2 = 1;
  private ammoState: Record<1 | 2, { mag: number; reserve: number }> = {
    1: { mag: 30, reserve: 150 },
    2: { mag: 15, reserve: 75 },
  };
  private fireCooldown = 0;
  private reloading = false;
  private reloadTimer = 0;
  private recoilPitchOffset = 0;
  private recoilYawOffset = 0;
  private viewModelRoot = new THREE.Group();
  private viewModelMesh: THREE.Group | null = null;
  private viewModelKick = 0;
  private walkBobPhase = 0;

  // Camera shake & death state
  private shakeIntensity = 0;
  private hitstopTimer = 0;
  private hitmarkerKind: HudSnapshot['hitmarkerKind'] = 'none';
  private hitmarkerTimer = 0;
  private damageFlash = 0;
  private playerDying = false;
  private playerDeathTimer = 0;

  // Special Character Ability
  private abilityCooldown = 0;
  private abilityActiveTimer = 0;
  private enemyStunTimer = 0;

  // Medkit Healing
  private medkits = 3;
  private healing = false;
  private healTimer = 0;
  private readonly healDuration = 1.2;
  private healFlash = 0;

  // Cinematic intro
  private cinematicActive = false;
  private cinematicTimer = 0;
  private cinematicDuration = 3.2;

  // Campaign AI & Objectives
  private aiUnits: AiUnit[] = [];
  private aiHitboxes: THREE.Object3D[] = [];
  private grenadesActive: GrenadeItem[] = [];
  private matchTimerSec = 0;
  private currentWave = 1;
  private objectiveProgress = 0;
  private objectiveTarget = 10;
  private missionEnded = false;
  private hackProgress = 0;

  // Multiplayer remotes
  private remotePlayers = new Map<string, RemotePlayerVisual>();
  private mpSyncTimer = 0;

  // Input state
  private keys = new Set<string>();
  private mouseFireHeld = false;
  private touchMoveX = 0;
  private touchMoveY = 0;
  private touchFireHeld = false;
  private pointerLocked = false;
  private raycaster = new THREE.Raycaster();

  constructor(container: HTMLElement, settings: GameSettings, callbacks: EngineCallbacks) {
    this.container = container;
    this.settings = settings;
    this.callbacks = callbacks;

    // Detect Software WebGL cleanly
    this.isSoftwareGl = (() => {
      const probe = document.createElement('canvas').getContext('webgl2');
      if (!probe) return true;
      const ext = probe.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0b1017);
    this.scene.fog = new THREE.FogExp2(0x0b1017, 0.008);

    // Mandatory studio/sky IBL reflection map
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    const aspect = (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight);
    this.camera = new THREE.PerspectiveCamera(settings.fov, aspect, 0.08, 360);
    this.camera.rotation.order = 'YXZ';
    this.scene.add(this.camera);

    // ViewModel attached to camera
    this.camera.add(this.viewModelRoot);
    this.viewModelRoot.visible = false;

    // 3-point lighting rig
    this.hemiLight = new THREE.HemisphereLight(0x9ec0db, 0x3b352d, 0.75);
    this.scene.add(this.hemiLight);

    this.keyLight = new THREE.DirectionalLight(0xfff1d6, 2.0);
    this.keyLight.position.set(35, 55, 28);
    this.keyLight.castShadow = true;
    this.keyLight.shadow.camera.near = 2;
    this.keyLight.shadow.camera.far = 160;
    const d = 58;
    this.keyLight.shadow.camera.left = -d;
    this.keyLight.shadow.camera.right = d;
    this.keyLight.shadow.camera.top = d;
    this.keyLight.shadow.camera.bottom = -d;
    this.keyLight.shadow.bias = -0.0005;
    this.keyLight.shadow.normalBias = 0.02;
    this.scene.add(this.keyLight);

    const rimLight = new THREE.DirectionalLight(0x7ca7d9, 0.55);
    rimLight.position.set(-40, 22, -35);
    this.scene.add(rimLight);

    this.muzzleLight = new THREE.PointLight(0xffaa44, 0, 14, 2);
    this.camera.add(this.muzzleLight);
    this.muzzleLight.position.set(0.25, -0.15, -0.9);

    this.textures = createTextureBundle(this.renderer);
    this.particles = new ParticleSystem(this.scene);

    // Post-processing composer for High/Ultra hardware GPUs (with MSAA + OutputPass + proper DPR)
    if (!this.isSoftwareGl) {
      const initW = container.clientWidth || window.innerWidth;
      const initH = container.clientHeight || window.innerHeight;
      const rt = new THREE.WebGLRenderTarget(initW, initH, {
        type: THREE.HalfFloatType,
        samples: 4,
      });
      this.composer = new EffectComposer(this.renderer, rt);
      this.composer.addPass(new RenderPass(this.scene, this.camera));
      this.bloomPass = new UnrealBloomPass(
        new THREE.Vector2(initW * 0.5, initH * 0.5),
        0.14,
        0.22,
        0.96
      );
      this.composer.addPass(this.bloomPass);
      this.composer.addPass(new OutputPass());
    }

    this.applySettings(settings);
    this.enterMenuDiorama();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.scheduleNextFrame();
  }

  private bindEvents(): void {
    window.addEventListener('resize', this.onResize);
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.onResize());
      this.resizeObserver.observe(this.container);
    }
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    document.addEventListener('pointerlockchange', this.onPointerLockChange);
    document.addEventListener('mousemove', this.onMouseMove);
    this.renderer.domElement.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
    this.renderer.domElement.addEventListener('contextmenu', this.onContextMenu);
  }

  private unbindEvents(): void {
    window.removeEventListener('resize', this.onResize);
    this.resizeObserver?.disconnect();
    this.resizeObserver = null;
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    document.removeEventListener('pointerlockchange', this.onPointerLockChange);
    document.removeEventListener('mousemove', this.onMouseMove);
    this.renderer.domElement.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mouseup', this.onMouseUp);
    this.renderer.domElement.removeEventListener('contextmenu', this.onContextMenu);
  }

  private onContextMenu = (e: Event) => e.preventDefault();

  private getTargetPixelRatio(): number {
    if (this.isSoftwareGl) return 1;
    const dpr = window.devicePixelRatio || 1;
    const w = this.container.clientWidth || window.innerWidth;
    // Boost effective DPR slightly on compact 16:9 mobile containers so 3D edges remain crisp
    const effectiveDpr = w < 780 ? Math.max(dpr, 1.75) : dpr;
    const ratioMap = {
      ultra: Math.min(effectiveDpr, 2.25),
      high: Math.min(effectiveDpr, 1.75),
      medium: Math.min(effectiveDpr, 1.25),
      low: 1.0,
    };
    return ratioMap[this.settings.graphics];
  }

  private onResize = () => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    const pr = this.getTargetPixelRatio();
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h);
    if (this.composer) {
      this.composer.setPixelRatio(pr);
      this.composer.setSize(w, h);
    }
    if (this.bloomPass) {
      this.bloomPass.resolution.set(w * 0.5, h * 0.5);
    }
  };

  private onBlur = () => {
    this.keys.clear();
    this.mouseFireHeld = false;
    this.touchFireHeld = false;
  };

  private onPointerLockChange = () => {
    this.pointerLocked = document.pointerLockElement === this.renderer.domElement;
    if (!this.pointerLocked && (this.mode === 'campaign' || this.mode === 'multiplayer') && !this.paused && !this.missionEnded) {
      // Allow mobile or cursor mode seamlessly; don't force pause on pointer unlock unless Escape was pressed
    }
  };

  private onKeyDown = (e: KeyboardEvent) => {
    if (this.mode === 'menu') return;
    // Do not capture movement keys when typing in chat input
    const tag = (e.target as HTMLElement)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;

    this.keys.add(e.code);

    if (e.code === 'Escape') {
      if (!this.missionEnded && (this.mode === 'campaign' || this.mode === 'multiplayer')) {
        this.callbacks.onPauseRequest();
      }
      return;
    }

    if (this.cinematicActive && (e.code === 'Space' || e.code === 'Enter')) {
      this.skipCinematic();
      return;
    }

    if (this.paused || this.missionEnded) return;

    if (e.code === 'KeyR') this.triggerReload();
    if (e.code === 'Digit1') this.switchWeaponSlot(1);
    if (e.code === 'Digit2') this.switchWeaponSlot(2);
    if (e.code === 'KeyG') this.triggerGrenade();
    if (e.code === 'KeyQ' || e.code === 'KeyF') this.triggerAbility();
    if (e.code === 'KeyH') this.triggerHeal();
    if (e.code === 'KeyE') this.triggerInteract();
    if (e.code === 'KeyC' || e.code === 'ControlLeft') {
      this.crouching = !this.crouching;
    }
    if (e.code === 'Space' && this.grounded && !this.cinematicActive) {
      this.playerVelY = 7.4;
      this.grounded = false;
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onMouseDown = (e: MouseEvent) => {
    audioEngine.unlock();
    if (this.mode === 'menu' || this.paused || this.missionEnded) return;
    if (this.cinematicActive) {
      this.skipCinematic();
      return;
    }
    if (!this.pointerLocked && this.settings.touchControls !== 'always' && window.matchMedia('(pointer: fine)').matches) {
      this.requestPointerLock();
    }
    if (e.button === 0) {
      this.mouseFireHeld = true;
      this.tryFire(true);
    } else if (e.button === 2) {
      this.ads = true;
    }
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) this.mouseFireHeld = false;
    if (e.button === 2) this.ads = false;
  };

  private onMouseMove = (e: MouseEvent) => {
    if (!this.pointerLocked || this.paused || this.cinematicActive || this.missionEnded) return;
    const sens = 0.0022 * this.settings.sensitivity * (this.ads ? 0.58 : 1.0);
    const inv = this.settings.invertY ? -1 : 1;
    this.yaw -= e.movementX * sens;
    this.pitch = THREE.MathUtils.clamp(this.pitch - e.movementY * sens * inv, -Math.PI * 0.46, Math.PI * 0.46);
  };

  requestPointerLock(): void {
    try {
      if (this.renderer.domElement.requestPointerLock) {
        void this.renderer.domElement.requestPointerLock();
      }
    } catch {
      // ignore on mobile/unsupported browsers
    }
  }

  exitPointerLock(): void {
    if (document.pointerLockElement) {
      document.exitPointerLock();
    }
  }

  // Imperative Touch / UI Controls
  setTouchMove(x: number, y: number): void {
    this.touchMoveX = x;
    this.touchMoveY = y;
  }

  addLookDelta(dx: number, dy: number): void {
    if (this.paused || this.cinematicActive || this.missionEnded) return;
    const sens = 0.0042 * this.settings.sensitivity * (this.ads ? 0.6 : 1.0);
    const inv = this.settings.invertY ? -1 : 1;
    this.yaw -= dx * sens;
    this.pitch = THREE.MathUtils.clamp(this.pitch - dy * sens * inv, -Math.PI * 0.46, Math.PI * 0.46);
  }

  setTouchFire(held: boolean): void {
    audioEngine.unlock();
    this.touchFireHeld = held;
    if (held) this.tryFire(true);
  }

  toggleAds(): void {
    this.ads = !this.ads;
  }

  triggerJump(): void {
    if (this.grounded && !this.paused && !this.cinematicActive) {
      this.playerVelY = 7.4;
      this.grounded = false;
    }
  }

  triggerCrouch(): void {
    this.crouching = !this.crouching;
  }

  skipCinematic(): void {
    this.cinematicActive = false;
    this.viewModelRoot.visible = true;
  }

  setPaused(p: boolean): void {
    this.paused = p;
    if (p) {
      this.keys.clear();
      this.mouseFireHeld = false;
      this.touchFireHeld = false;
      this.exitPointerLock();
    }
  }

  applySettings(settings: GameSettings): void {
    this.settings = settings;
    audioEngine.setVolumes(settings.masterVolume, settings.sfxVolume, settings.ambientVolume, settings.muted);

    if (this.isSoftwareGl) {
      this.renderer.setPixelRatio(1);
      this.renderer.shadowMap.enabled = false;
    } else {
      const pr = this.getTargetPixelRatio();
      this.renderer.setPixelRatio(pr);
      if (this.composer) {
        this.composer.setPixelRatio(pr);
        const w = this.container.clientWidth || window.innerWidth;
        const h = this.container.clientHeight || window.innerHeight;
        this.composer.setSize(w, h);
      }
      const shadowsOn = settings.graphics !== 'low';
      this.renderer.shadowMap.enabled = shadowsOn;
      const shadowRes = settings.graphics === 'ultra' ? 2048 : settings.graphics === 'high' ? 1536 : 1024;
      if (this.keyLight.shadow.mapSize.width !== shadowRes) {
        this.keyLight.shadow.mapSize.set(shadowRes, shadowRes);
        this.keyLight.shadow.map?.dispose();
        this.keyLight.shadow.map = null;
      }
      if (this.bloomPass) {
        this.bloomPass.enabled = settings.graphics === 'ultra' || settings.graphics === 'high';
      }
    }

    this.camera.fov = settings.fov;
    this.camera.updateProjectionMatrix();
  }

  setLoadout(characterId: CharacterId, skinId: SkinId, primary: WeaponId, secondary: WeaponId): void {
    this.characterId = characterId;
    this.skinId = skinId;
    this.primaryWeaponId = primary;
    this.secondaryWeaponId = secondary;
    if (this.mode !== 'menu') {
      this.rebuildViewModel();
    }
  }

  private getActiveWeaponId(): WeaponId {
    return this.activeSlot === 1 ? this.primaryWeaponId : this.secondaryWeaponId;
  }

  private rebuildViewModel(): void {
    if (this.viewModelMesh) {
      this.viewModelRoot.remove(this.viewModelMesh);
      this.viewModelMesh = null;
    }
    const wId = this.getActiveWeaponId();
    this.viewModelMesh = buildWeaponMesh(wId, true, this.skinId, this.textures);
    this.viewModelRoot.add(this.viewModelMesh);
  }

  switchWeaponSlot(slot: 1 | 2): void {
    if (this.activeSlot === slot || this.reloading) return;
    this.activeSlot = slot;
    this.ads = false;
    this.rebuildViewModel();
    this.viewModelKick = 0.08;
  }

  triggerReload(): void {
    if (this.reloading || this.paused || this.cinematicActive) return;
    const w = WEAPONS[this.getActiveWeaponId()];
    const state = this.ammoState[this.activeSlot];
    if (state.mag >= w.magSize || state.reserve <= 0) return;
    this.reloading = true;
    this.ads = false;
    const fastReload = this.characterId === 'striker' && this.abilityActiveTimer > 0 ? 0.55 : 1.0;
    this.reloadTimer = w.reloadTimeSec * fastReload;
    audioEngine.playReload();
  }

  triggerAbility(): void {
    if (this.paused || this.cinematicActive || this.missionEnded || this.mode === 'menu' || this.hp <= 0) return;
    if (this.abilityCooldown > 0) return;

    const charDef = CHARACTERS[this.characterId];
    this.abilityCooldown = charDef.abilityCooldownSec;
    this.abilityActiveTimer = charDef.abilityDurationSec;
    audioEngine.playAbilityActivate();

    if (this.characterId === 'striker') {
      this.hp = Math.min(this.maxHp, this.hp + 20);
      this.stamina = 100;
    } else if (this.characterId === 'vanguard') {
      this.armor = Math.min(120, this.armor + 60);
    } else if (this.characterId === 'medic') {
      this.hp = Math.min(this.maxHp, this.hp + 45);
    } else if (this.characterId === 'pyro') {
      this.grenades = Math.min(5, this.grenades + 1);
      this.camera.getWorldDirection(_dir);
      const blastCenter = this.playerPos.clone().add(new THREE.Vector3(0, 1.1, 0)).addScaledVector(_dir, 5.5);
      this.particles.spawnExplosion(blastCenter, 9);
      audioEngine.playExplosion(0.95);
      this.shakeIntensity = Math.max(this.shakeIntensity, 0.42);
      if (this.mode === 'campaign') {
        for (const u of this.aiUnits) {
          if (!u.alive || u.isAlly || u.isCivilian) continue;
          const distFromPlayer = Math.hypot(u.x - this.playerPos.x, u.z - this.playerPos.z);
          const distFromBlast = Math.hypot(u.x - blastCenter.x, u.z - blastCenter.z);
          if (distFromPlayer < 10.5 || distFromBlast < 7.5) {
            const dmg = Math.round(Math.max(80, 180 - distFromBlast * 12));
            u.hp -= dmg;
            this.particles.spawnImpact(new THREE.Vector3(u.x, 1.2, u.z), 0xf97316, 8);
            if (u.hp <= 0) this.onAiKilled(u, this.primaryWeaponId, false);
          }
        }
      }
    } else if (this.characterId === 'spectre') {
      this.enemyStunTimer = 3.5;
      this.particles.spawnImpact(this.playerPos.clone().add(new THREE.Vector3(0, 1.4, 0)), 0x06b6d4, 14);
    } else if (this.characterId === 'titan') {
      const w = WEAPONS[this.getActiveWeaponId()];
      this.ammoState[this.activeSlot].mag = w.magSize;
      this.reloading = false;
    }
  }

  triggerHeal(): void {
    if (this.paused || this.cinematicActive || this.missionEnded || this.mode === 'menu' || this.hp <= 0) return;
    if (this.medkits <= 0 || this.healing || this.hp >= this.maxHp) return;
    this.medkits -= 1;
    this.healing = true;
    this.healTimer = this.healDuration;
    this.ads = false;
    audioEngine.playHeal();
  }

  triggerGrenade(): void {
    if (this.grenades <= 0 || this.paused || this.cinematicActive || this.mode === 'menu') return;
    this.grenades -= 1;
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.14, 10, 10),
      new THREE.MeshStandardMaterial({ color: 0x3b4a34, roughness: 0.4, metalness: 0.6 })
    );
    this.camera.getWorldDirection(_dir);
    const startPos = this.playerPos.clone().add(new THREE.Vector3(0, 1.5, 0)).addScaledVector(_dir, 0.8);
    mesh.position.copy(startPos);
    this.scene.add(mesh);
    const vel = _dir.clone().multiplyScalar(19);
    vel.y += 4.5;
    this.grenadesActive.push({ mesh, pos: startPos, vel, fuse: 1.65 });
  }

  triggerInteract(): void {
    if (this.mode !== 'campaign' || !this.activeMap || !this.currentMission) return;
    if (this.currentMission.objectiveKind === 'rescue_civilians') {
      for (const u of this.aiUnits) {
        if (u.isCivilian && !u.rescued) {
          const dist = Math.hypot(u.x - this.playerPos.x, u.z - this.playerPos.z);
          if (dist < 4.5) {
            u.rescued = true;
            u.rig.root.visible = false;
            this.objectiveProgress += 1;
            this.score += 200;
            audioEngine.playUiConfirm(true);
            this.checkCampaignWin();
          }
        }
      }
    } else if (this.currentMission.objectiveKind === 'hack_terminals' || this.currentMission.objectiveKind === 'boss_citadel') {
      for (const node of this.activeMap.objectiveNodes) {
        if (node.completed) continue;
        const dist = Math.hypot(node.x - this.playerPos.x, node.z - this.playerPos.z);
        if (dist < 4.5) {
          node.completed = true;
          node.beacon.visible = false;
          this.objectiveProgress += 1;
          this.score += 250;
          audioEngine.playUiConfirm(true);
          this.checkCampaignWin();
        }
      }
    }
  }

  private clearActiveWorld(): void {
    if (this.menuDiorama) {
      this.scene.remove(this.menuDiorama.root);
      this.menuDiorama.dispose();
      this.menuDiorama = null;
    }
    if (this.activeMap) {
      this.scene.remove(this.activeMap.root);
      this.activeMap.dispose();
      this.activeMap = null;
    }
    for (const u of this.aiUnits) {
      this.scene.remove(u.rig.root);
    }
    this.aiUnits = [];
    this.aiHitboxes = [];
    for (const r of this.remotePlayers.values()) {
      this.scene.remove(r.rig.root);
    }
    this.remotePlayers.clear();
    for (const g of this.grenadesActive) {
      this.scene.remove(g.mesh);
    }
    this.grenadesActive = [];
    for (const zm of this.mpZonesMeshes) {
      this.scene.remove(zm.ring);
      this.scene.remove(zm.beacon);
    }
    this.mpZonesMeshes = [];
    audioEngine.stopAmbient();
  }

  enterMenuDiorama(): void {
    this.clearActiveWorld();
    this.mode = 'menu';
    this.paused = false;
    this.playerDying = false;
    this.playerDeathTimer = 0;
    this.camera.rotation.z = 0;
    this.viewModelRoot.visible = false;
    this.exitPointerLock();

    this.scene.background = new THREE.Color(0x0d1520);
    this.scene.fog = new THREE.FogExp2(0x0d1520, 0.011);
    this.keyLight.color.setHex(0xffd7a8);
    this.keyLight.intensity = 1.9;
    this.hemiLight.color.setHex(0x527394);
    this.hemiLight.groundColor.setHex(0x1b2129);
    this.particles.setupWeather('embers');

    this.menuDiorama = buildMenuDiorama(this.textures);
    this.scene.add(this.menuDiorama.root);
  }

  startCampaignMission(mission: MissionDef): void {
    this.clearActiveWorld();
    this.mode = 'campaign';
    this.currentMission = mission;
    this.missionEnded = false;
    this.paused = false;
    this.playerDying = false;
    this.playerDeathTimer = 0;
    this.camera.rotation.z = 0;
    this.hp = 100;
    this.maxHp = 100;
    const charDef = CHARACTERS[this.characterId];
    this.maxArmor = charDef.armorBonus;
    this.armor = this.maxArmor;
    this.stamina = 100;
    this.grenades = 3;
    this.score = 0;
    this.kills = 0;
    this.deaths = 0;
    this.matchTimerSec = 0;
    this.currentWave = 1;
    this.objectiveProgress = 0;
    this.objectiveTarget = mission.targetCount;
    this.reloading = false;
    this.ads = false;
    this.crouching = false;
    this.abilityCooldown = 0;
    this.abilityActiveTimer = 0;
    this.enemyStunTimer = 0;
    this.medkits = 3;
    this.healing = false;
    this.healTimer = 0;
    this.healFlash = 0;

    const w1 = WEAPONS[this.primaryWeaponId];
    const w2 = WEAPONS[this.secondaryWeaponId];
    this.activeSlot = 1;
    this.ammoState = {
      1: { mag: w1.magSize, reserve: w1.reserveAmmo },
      2: { mag: w2.magSize, reserve: w2.reserveAmmo },
    };
    this.rebuildViewModel();

    // Lighting & atmosphere
    this.scene.background = new THREE.Color(mission.skyHex);
    this.scene.fog = new THREE.FogExp2(mission.fogHex, mission.fogDensity);
    this.keyLight.color.setHex(mission.sunColor);
    this.keyLight.intensity = mission.sunIntensity;
    this.hemiLight.color.setHex(mission.hemiSky);
    this.hemiLight.groundColor.setHex(mission.hemiGround);
    this.particles.setupWeather(mission.ambientWeather);

    if (mission.ambientWeather === 'rain_storm') audioEngine.startAmbient('storm');
    else if (mission.ambientWeather === 'dust' || mission.ambientWeather === 'embers') audioEngine.startAmbient('wind');

    this.activeMap = buildCampaignMap(mission, this.textures);
    this.scene.add(this.activeMap.root);

    this.playerPos.copy(this.activeMap.playerSpawn);
    this.yaw = 0;
    this.pitch = 0;

    // Spawn Enemies
    if (mission.objectiveKind === 'defend_core') {
      this.spawnWaveEnemies(1, 6);
    } else {
      this.spawnCampaignEnemies(mission);
    }

    // Spawn Civilians for Mission 4
    if (mission.objectiveKind === 'rescue_civilians') {
      const civCoords = [
        [-28, -20],
        [28, -20],
        [-22, 14],
        [22, 14],
      ];
      civCoords.forEach(([x, z], i) => {
        const rig = buildSoldierModel({
          actorId: `civ_${i}`,
          characterId: 'striker',
          skinId: 'arctic',
          teamColorHex: 0x38bdf8,
          weaponId: 'p226',
          textures: this.textures,
          isCivilian: true,
        });
        rig.root.position.set(x, 0, z);
        this.scene.add(rig.root);
        this.aiUnits.push({
          id: `civ_${i}`,
          isAlly: true,
          isCivilian: true,
          isBoss: false,
          archetype: 'rifle',
          rig,
          hp: 100,
          maxHp: 100,
          alive: true,
          x,
          y: 0,
          z,
          yaw: 0,
          speed: 0,
          fireCooldown: 0,
          strafeDir: 1,
          strafeTimer: 1,
          walkPhase: 0,
          deathTimer: 0,
          deathDir: -1,
          deathTilt: 0,
          rescued: false,
        });
      });
    }

    // Spawn Allies for Missions 9 & 10
    if (mission.hasAllies && this.activeMap) {
      this.activeMap.allySpawns.forEach((sp, i) => {
        const rig = buildSoldierModel({
          actorId: `ally_${i}`,
          characterId: 'striker',
          skinId: 'olive',
          teamColorHex: 0x10b981,
          weaponId: 'm4a1',
          textures: this.textures,
        });
        rig.root.position.copy(sp);
        this.scene.add(rig.root);
        this.aiUnits.push({
          id: `ally_${i}`,
          isAlly: true,
          isCivilian: false,
          isBoss: false,
          archetype: 'rifle',
          rig,
          hp: 160,
          maxHp: 160,
          alive: true,
          x: sp.x,
          y: 0,
          z: sp.z,
          yaw: 0,
          speed: 4.5,
          fireCooldown: 0.4,
          strafeDir: 1,
          strafeTimer: 1.5,
          walkPhase: 0,
          deathTimer: 0,
          deathDir: -1,
          deathTilt: 0,
        });
      });
    }

    // Boss for Mission 10
    if (mission.hasBoss) {
      const rig = buildSoldierModel({
        actorId: 'boss_korsakov',
        characterId: 'vanguard',
        skinId: 'crimson',
        teamColorHex: 0xef4444,
        weaponId: 'm249',
        textures: this.textures,
        isBoss: true,
      });
      rig.root.position.set(0, 0, -34);
      this.scene.add(rig.root);
      this.aiHitboxes.push(rig.bodyHitbox, rig.headHitbox);
      this.aiUnits.push({
        id: 'boss_korsakov',
        isAlly: false,
        isCivilian: false,
        isBoss: true,
        archetype: 'heavy',
        rig,
        hp: 650,
        maxHp: 650,
        alive: true,
        x: 0,
        y: 0,
        z: -34,
        yaw: 0,
        speed: 3.1,
        fireCooldown: 1.0,
        strafeDir: 1,
        strafeTimer: 2,
        walkPhase: 0,
        deathTimer: 0,
        deathDir: -1,
        deathTilt: 0,
      });
    }

    // Start Cinematic Intro
    this.cinematicActive = true;
    this.cinematicTimer = 0;
    this.viewModelRoot.visible = false;
  }

  private spawnCampaignEnemies(mission: MissionDef): void {
    if (!this.activeMap) return;
    const total = mission.enemyCount;
    for (let i = 0; i < total; i++) {
      const sp = this.activeMap.enemySpawns[i % this.activeMap.enemySpawns.length];
      const jitterX = (Math.random() - 0.5) * 9;
      const jitterZ = (Math.random() - 0.5) * 9;
      const x = THREE.MathUtils.clamp(sp.x + jitterX, -46, 46);
      const z = THREE.MathUtils.clamp(sp.z + jitterZ, -46, 46);
      const arch: AiUnit['archetype'] =
        i % 5 === 0 ? 'heavy' : i % 4 === 0 ? 'sniper' : i % 3 === 0 ? 'rusher' : 'rifle';
      this.spawnSingleEnemy(`enemy_${i}`, x, z, arch, mission.difficulty);
    }
  }

  private spawnWaveEnemies(wave: number, count: number): void {
    if (!this.activeMap || !this.currentMission) return;
    for (let i = 0; i < count; i++) {
      const sp = this.activeMap.enemySpawns[i % this.activeMap.enemySpawns.length];
      const x = THREE.MathUtils.clamp(sp.x + (Math.random() - 0.5) * 10, -46, 46);
      const z = THREE.MathUtils.clamp(sp.z + (Math.random() - 0.5) * 8, -46, 10);
      const arch: AiUnit['archetype'] = i % 4 === 0 ? 'heavy' : i % 2 === 0 ? 'rusher' : 'rifle';
      this.spawnSingleEnemy(`wave_${wave}_${i}`, x, z, arch, this.currentMission.difficulty);
    }
  }

  private spawnSingleEnemy(
    id: string,
    x: number,
    z: number,
    archetype: AiUnit['archetype'],
    difficulty: number
  ): void {
    const weaponId: WeaponId =
      archetype === 'sniper' ? 'awm' : archetype === 'heavy' ? 'm249' : archetype === 'rusher' ? 'mp5sd' : 'ak74m';
    const rig = buildSoldierModel({
      actorId: id,
      characterId: archetype === 'heavy' ? 'vanguard' : archetype === 'sniper' ? 'ghost' : 'striker',
      skinId: archetype === 'heavy' ? 'crimson' : 'nightops',
      teamColorHex: 0xef4444,
      weaponId,
      textures: this.textures,
    });
    rig.root.position.set(x, 0, z);
    this.scene.add(rig.root);
    this.aiHitboxes.push(rig.bodyHitbox, rig.headHitbox);

    const baseHp = archetype === 'heavy' ? 165 : archetype === 'rusher' ? 85 : 100;
    const scaledHp = Math.round(baseHp * (0.85 + difficulty * 0.12));

    this.aiUnits.push({
      id,
      isAlly: false,
      isCivilian: false,
      isBoss: false,
      archetype,
      rig,
      hp: scaledHp,
      maxHp: scaledHp,
      alive: true,
      x,
      y: 0,
      z,
      yaw: 0,
      speed: archetype === 'rusher' ? 5.6 : archetype === 'heavy' ? 3.2 : 4.2,
      fireCooldown: 0.7 + Math.random() * 1.1,
      strafeDir: Math.random() > 0.5 ? 1 : -1,
      strafeTimer: 1 + Math.random() * 1.5,
      walkPhase: Math.random() * Math.PI * 2,
      deathTimer: 0,
      deathDir: -1,
      deathTilt: 0,
    });
  }

  startMultiplayerMatch(room: MultiplayerRoomState, localPlayerId: string): void {
    this.clearActiveWorld();
    this.mode = 'multiplayer';
    this.mpRoom = room;
    this.missionEnded = false;
    this.paused = false;
    this.playerDying = false;
    this.playerDeathTimer = 0;
    this.camera.rotation.z = 0;
    this.cinematicActive = false;
    this.hp = 100;
    this.maxHp = 100;
    this.maxArmor = CHARACTERS[this.characterId].armorBonus;
    this.armor = this.maxArmor;
    this.stamina = 100;
    this.grenades = 2;
    this.score = 0;
    this.kills = 0;
    this.deaths = 0;
    this.respawnTimerSec = 0;
    this.abilityCooldown = 0;
    this.abilityActiveTimer = 0;
    this.enemyStunTimer = 0;
    this.medkits = 2;
    this.healing = false;
    this.healTimer = 0;
    this.healFlash = 0;

    const w1 = WEAPONS[this.primaryWeaponId];
    const w2 = WEAPONS[this.secondaryWeaponId];
    this.activeSlot = 1;
    this.ammoState = {
      1: { mag: w1.magSize, reserve: w1.reserveAmmo },
      2: { mag: w2.magSize, reserve: w2.reserveAmmo },
    };
    this.rebuildViewModel();
    this.viewModelRoot.visible = true;

    const isHarbor = room.mapId === 'harbor_arena';
    this.scene.background = new THREE.Color(isHarbor ? 0x6f8fa8 : 0x8da4b8);
    this.scene.fog = new THREE.FogExp2(isHarbor ? 0x6f8fa8 : 0x8da4b8, 0.0075);
    this.keyLight.color.setHex(0xfff1d6);
    this.keyLight.intensity = 2.1;
    this.hemiLight.color.setHex(0x9ec0db);
    this.hemiLight.groundColor.setHex(0x3a4048);
    this.particles.setupWeather('clear');

    this.activeMap = buildMultiplayerArena(room.mapId, this.textures);
    this.scene.add(this.activeMap.root);

    // Domination capture zones visual rings
    if (room.mode === 'domination') {
      room.capturePoints.forEach((cp) => {
        const ring = new THREE.Mesh(
          new THREE.RingGeometry(5.6, 6.2, 32),
          new THREE.MeshBasicMaterial({ color: 0xf59e0b, side: THREE.DoubleSide })
        );
        ring.rotation.x = -Math.PI / 2;
        ring.position.set(cp.x, 0.06, cp.z);
        const beacon = new THREE.Mesh(
          new THREE.CylinderGeometry(0.16, 0.16, 20, 10, 1, true),
          new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false })
        );
        beacon.position.set(cp.x, 10, cp.z);
        this.scene.add(ring, beacon);
        this.mpZonesMeshes.push({ id: cp.id, ring, beacon });
      });
    }

    const me = room.players.find((p) => p.id === localPlayerId);
    if (me) {
      this.mpLocalTeam = me.team;
      this.playerPos.set(me.x, me.y, me.z);
      this.yaw = me.yaw;
    }

    this.syncRoomPlayers(room, localPlayerId);
  }

  syncRoomPlayers(room: MultiplayerRoomState, localPlayerId: string): void {
    this.mpRoom = room;
    const me = room.players.find((p) => p.id === localPlayerId);
    if (me) {
      this.mpLocalTeam = me.team;
      this.hp = me.hp;
      this.kills = me.kills;
      this.deaths = me.deaths;
      this.score = me.score;
      if (!me.alive && this.respawnTimerSec <= 0) {
        this.respawnTimerSec = 3.5;
      }
    }

    // Update capture point ring colors
    room.capturePoints.forEach((cp) => {
      const zm = this.mpZonesMeshes.find((m) => m.id === cp.id);
      if (zm) {
        const c = cp.owner === 'alpha' ? 0x3b82f6 : cp.owner === 'bravo' ? 0xef4444 : 0xf59e0b;
        (zm.ring.material as THREE.MeshBasicMaterial).color.setHex(c);
        (zm.beacon.material as THREE.MeshBasicMaterial).color.setHex(c);
      }
    });

    const activeIds = new Set<string>();
    for (const p of room.players) {
      if (p.id === localPlayerId) continue;
      activeIds.add(p.id);
      let rem = this.remotePlayers.get(p.id);
      if (!rem) {
        const rig = buildSoldierModel({
          actorId: p.id,
          characterId: p.characterId,
          skinId: p.skinId,
          teamColorHex: p.team === 'alpha' ? 0x3b82f6 : 0xef4444,
          weaponId: p.weaponId,
          textures: this.textures,
        });
        rig.root.position.set(p.x, p.y, p.z);
        this.scene.add(rig.root);
        rem = {
          id: p.id,
          callsign: p.callsign,
          team: p.team,
          characterId: p.characterId,
          skinId: p.skinId,
          weaponId: p.weaponId,
          rig,
          hp: p.hp,
          alive: p.alive,
          targetX: p.x,
          targetY: p.y,
          targetZ: p.z,
          targetYaw: p.yaw,
          crouching: p.crouching,
          moving: p.moving,
          walkPhase: 0,
          deathTimer: 0,
          deathDir: -1,
        };
        this.remotePlayers.set(p.id, rem);
      }
      rem.hp = p.hp;
      if (rem.alive && !p.alive) {
        // Trigger smooth death fall animation instead of vanishing immediately
        rem.alive = false;
        rem.deathTimer = 0.001;
        rem.deathDir = -1;
      } else if (!rem.alive && p.alive) {
        // Respawned cleanly
        rem.alive = true;
        rem.deathTimer = 0;
        rem.rig.root.visible = true;
        rem.rig.root.rotation.set(0, p.yaw + Math.PI, 0);
        rem.rig.root.position.set(p.x, p.y, p.z);
        rem.rig.leftLeg.rotation.set(0, 0, 0);
        rem.rig.rightLeg.rotation.set(0, 0, 0);
        rem.rig.leftArm.rotation.set(0, 0, 0);
        rem.rig.rightArm.rotation.set(0, 0, 0);
      }
      rem.team = p.team;
      rem.callsign = p.callsign;
    }

    for (const [id, rem] of this.remotePlayers.entries()) {
      if (!activeIds.has(id)) {
        this.scene.remove(rem.rig.root);
        this.remotePlayers.delete(id);
      }
    }
  }

  applyRemoteDelta(delta: MpDeltaPacket): void {
    const rem = this.remotePlayers.get(delta.id);
    if (!rem) return;
    rem.targetX = delta.x;
    rem.targetY = delta.y;
    rem.targetZ = delta.z;
    rem.targetYaw = delta.yaw;
    rem.crouching = delta.crouching;
    rem.moving = delta.moving;
  }

  applyRemoteFire(fire: MpFirePacket): void {
    const start = new THREE.Vector3(fire.ox, fire.oy, fire.oz);
    const dir = new THREE.Vector3(fire.dx, fire.dy, fire.dz).normalize();
    const end = start.clone().addScaledVector(dir, 65);
    this.particles.spawnTracer(start, end, 0xffaa44);
    const dist = start.distanceTo(this.playerPos);
    audioEngine.playWeaponFire(fire.weaponId, Math.max(0.1, 1 - dist / 65));
  }

  handleLocalDamage(hp: number): void {
    this.hp = hp;
    this.damageFlash = 1.0;
    this.shakeIntensity = Math.max(this.shakeIntensity, 0.25);
    if (hp <= 0) {
      this.respawnTimerSec = 3.5;
      this.ads = false;
      this.touchFireHeld = false;
      this.mouseFireHeld = false;
      if (!this.playerDying) {
        this.playerDying = true;
        this.playerDeathTimer = 0.001;
      }
    }
  }

  handleLocalRespawn(x: number, y: number, z: number, yaw: number): void {
    this.playerPos.set(x, y, z);
    this.yaw = yaw;
    this.pitch = 0;
    this.camera.rotation.z = 0;
    this.playerDying = false;
    this.playerDeathTimer = 0;
    this.viewModelRoot.visible = true;
    this.hp = 100;
    this.armor = this.maxArmor;
    this.respawnTimerSec = 0;
    this.medkits = 2;
    this.healing = false;
    this.healTimer = 0;
    const w1 = WEAPONS[this.primaryWeaponId];
    const w2 = WEAPONS[this.secondaryWeaponId];
    this.ammoState = {
      1: { mag: w1.magSize, reserve: w1.reserveAmmo },
      2: { mag: w2.magSize, reserve: w2.reserveAmmo },
    };
  }

  private tryFire(isInitialClick: boolean): void {
    if (this.paused || this.cinematicActive || this.missionEnded || this.reloading || this.hp <= 0) return;
    if (this.fireCooldown > 0) return;

    const weapon = WEAPONS[this.getActiveWeaponId()];
    if (!weapon.auto && !isInitialClick) return;

    const slotAmmo = this.ammoState[this.activeSlot];
    const isTitanOverload = this.characterId === 'titan' && this.abilityActiveTimer > 0;
    const isStrikerActive = this.characterId === 'striker' && this.abilityActiveTimer > 0;
    const isFalconActive = this.characterId === 'falcon' && this.abilityActiveTimer > 0;
    const isSpectreActive = this.characterId === 'spectre' && this.abilityActiveTimer > 0;

    if (!isTitanOverload && slotAmmo.mag <= 0) {
      this.triggerReload();
      return;
    }

    if (!isTitanOverload) {
      slotAmmo.mag -= 1;
    }
    this.fireCooldown = (60 / weapon.fireRateRpm) * (isStrikerActive ? 0.68 : 1.0);
    this.viewModelKick = 0.095;
    this.muzzleLight.intensity = weapon.suppressed ? 0.8 : 4.2;
    this.shakeIntensity = Math.max(this.shakeIntensity, weapon.category === 'sniper' || weapon.category === 'shotgun' ? 0.18 : 0.055);
    audioEngine.playWeaponFire(weapon.id, 1);

    // Recoil kick
    const recoilScale = isFalconActive ? 0.25 : 1.0;
    this.recoilPitchOffset += weapon.recoilPitch * (this.ads ? 0.65 : 1.0) * recoilScale;
    this.recoilYawOffset += (Math.random() - 0.5) * weapon.recoilYaw * recoilScale;

    // Raycast pellets
    const pellets = weapon.pellets || 1;
    const spread = (this.ads ? weapon.spreadAds : weapon.spreadHip) * (isFalconActive ? 0.25 : 1.0);
    const abilityDmgMult = isFalconActive ? 1.45 : isTitanOverload || isSpectreActive ? 1.3 : 1.0;

    this.camera.getWorldPosition(_rayOrigin);
    this.camera.getWorldDirection(_dir);

    if (this.mode === 'multiplayer') {
      mpClient.sendFire({
        weaponId: weapon.id,
        ox: _rayOrigin.x + _dir.x * 0.7,
        oy: _rayOrigin.y - 0.15,
        oz: _rayOrigin.z + _dir.z * 0.7,
        dx: _dir.x,
        dy: _dir.y,
        dz: _dir.z,
      });
    }

    for (let p = 0; p < pellets; p++) {
      const shotDir = _dir.clone();
      shotDir.x += (Math.random() - 0.5) * spread * 2;
      shotDir.y += (Math.random() - 0.5) * spread * 2;
      shotDir.z += (Math.random() - 0.5) * spread * 2;
      shotDir.normalize();

      this.raycaster.set(_rayOrigin, shotDir);
      this.raycaster.far = weapon.range;

      // Collect targets
      const targets: THREE.Object3D[] = [...(this.activeMap?.raycastObstacles || [])];
      if (this.mode === 'campaign') {
        for (const u of this.aiUnits) {
          if (u.alive && !u.isAlly && !u.isCivilian) {
            targets.push(u.rig.headHitbox, u.rig.bodyHitbox);
          }
        }
      } else if (this.mode === 'multiplayer') {
        for (const rem of this.remotePlayers.values()) {
          if (rem.alive && rem.team !== this.mpLocalTeam) {
            targets.push(rem.rig.headHitbox, rem.rig.bodyHitbox);
          }
        }
      }

      const hits = this.raycaster.intersectObjects(targets, true);
      const tracerStart = _rayOrigin.clone().addScaledVector(shotDir, 0.9);
      tracerStart.y -= 0.12;

      if (hits.length > 0) {
        const hit = hits[0];
        this.particles.spawnTracer(tracerStart, hit.point, 0xffe082);

        const actorId = hit.object.userData?.actorId as string | undefined;
        const hitPart = hit.object.userData?.hitPart as 'head' | 'body' | undefined;

        if (actorId && this.mode === 'campaign') {
          const unit = this.aiUnits.find((u) => u.id === actorId);
          if (unit && unit.alive) {
            const isHead = hitPart === 'head';
            let dmg = Math.round(weapon.damage * abilityDmgMult * (isHead ? weapon.headshotMult : 1));
            // Boss shield damage reduction if shield cores still active
            if (unit.isBoss && this.activeMap) {
              const activeShields = this.activeMap.objectiveNodes.some((n) => !n.completed);
              if (activeShields) dmg = Math.round(dmg * 0.25);
            }
            unit.hp -= dmg;
            this.particles.spawnImpact(hit.point, 0xef4444, 7);
            this.hitmarkerKind = unit.hp <= 0 ? 'kill' : isHead ? 'headshot' : 'normal';
            this.hitmarkerTimer = 0.22;
            audioEngine.playHitmarker(isHead);

            if (unit.hp <= 0) {
              this.onAiKilled(unit, weapon.id, isHead);
            }
          }
        } else if (actorId && this.mode === 'multiplayer') {
          const isHead = hitPart === 'head';
          this.particles.spawnImpact(hit.point, 0xef4444, 7);
          this.hitmarkerKind = isHead ? 'headshot' : 'normal';
          this.hitmarkerTimer = 0.22;
          audioEngine.playHitmarker(isHead);
          mpClient.sendHitClaim(actorId, isHead);
        } else {
          // Check if hit an objective fuel tank / destructible target
          const objNode = this.findObjectiveNodeFromHit(hit.object);
          if (objNode && !objNode.completed && this.currentMission?.objectiveKind === 'destroy_targets') {
            objNode.hp -= weapon.damage;
            this.particles.spawnImpact(hit.point, 0xffaa33, 10);
            this.hitmarkerKind = 'normal';
            this.hitmarkerTimer = 0.16;
            if (objNode.hp <= 0) {
              objNode.completed = true;
              objNode.beacon.visible = false;
              objNode.mesh.visible = false;
              this.particles.spawnExplosion(new THREE.Vector3(objNode.x, 1, objNode.z), 8);
              audioEngine.playExplosion(1);
              this.shakeIntensity = 0.55;
              this.hitstopTimer = 0.045;
              this.objectiveProgress += 1;
              this.score += 300;
              this.checkCampaignWin();
            }
          } else {
            this.particles.spawnImpact(hit.point, 0xfbbf24, 5);
          }
        }
      } else {
        const end = tracerStart.clone().addScaledVector(shotDir, 60);
        this.particles.spawnTracer(tracerStart, end, 0xffe082);
      }
    }
  }

  private findObjectiveNodeFromHit(obj: THREE.Object3D) {
    if (!this.activeMap) return null;
    let cur: THREE.Object3D | null = obj;
    while (cur) {
      const found = this.activeMap.objectiveNodes.find((n) => n.mesh === cur);
      if (found) return found;
      cur = cur.parent;
    }
    return null;
  }

  private onAiKilled(unit: AiUnit, weaponId: WeaponId, headshot: boolean): void {
    unit.alive = false;
    unit.deathTimer = 0.001;
    unit.deathDir = headshot ? -1 : Math.random() > 0.45 ? -1 : 1;
    unit.deathTilt = (Math.random() - 0.5) * 1.4;
    this.kills += 1;
    this.score += unit.isBoss ? 1200 : headshot ? 150 : 100;
    if (this.kills % 3 === 0 || unit.isBoss) {
      this.medkits = Math.min(5, this.medkits + 1);
    }
    if (unit.isBoss) {
      this.particles.spawnExplosion(new THREE.Vector3(unit.x, 1.2, unit.z), 8);
      audioEngine.playExplosion(1);
    }
    this.callbacks.onLocalKillFeed?.('أنت', unit.isBoss ? 'الجنرال كورساكوف' : 'جندي معادٍ', weaponId, headshot, true);

    if (this.currentMission?.objectiveKind === 'eliminate_squads') {
      this.objectiveProgress = Math.min(this.objectiveTarget, this.objectiveProgress + 1);
      this.checkCampaignWin();
    } else if (this.currentMission?.objectiveKind === 'boss_citadel' && unit.isBoss) {
      this.objectiveProgress += 1;
      this.checkCampaignWin();
    } else if (this.currentMission?.objectiveKind === 'defend_core') {
      const aliveEnemies = this.aiUnits.some((u) => !u.isAlly && u.alive);
      if (!aliveEnemies) {
        if (this.currentWave < (this.currentMission.waves || 4)) {
          this.currentWave += 1;
          this.objectiveProgress = this.currentWave - 1;
          this.spawnWaveEnemies(this.currentWave, 5 + this.currentWave * 2);
          audioEngine.playUiConfirm(true);
        } else {
          this.objectiveProgress = this.objectiveTarget;
          this.checkCampaignWin();
        }
      }
    }
  }

  private checkCampaignWin(): void {
    if (this.missionEnded || !this.currentMission) return;
    if (this.objectiveProgress >= this.objectiveTarget) {
      this.missionEnded = true;
      this.exitPointerLock();
      audioEngine.playUiConfirm(true);
      const timeBonus = Math.max(0, 600 - Math.round(this.matchTimerSec * 2));
      const finalScore = this.score + timeBonus + this.currentMission.rewardXp;
      const stars = this.hp >= 65 && this.deaths === 0 ? 3 : this.hp >= 30 ? 2 : 1;
      this.callbacks.onMissionEnd({
        victory: true,
        missionId: this.currentMission.id,
        score: finalScore,
        kills: this.kills,
        deaths: this.deaths,
        timeSec: Math.max(1, Math.round(this.matchTimerSec)),
        stars,
      });
    }
  }

  private failCampaignMission(): void {
    if (this.missionEnded || !this.currentMission) return;
    this.missionEnded = true;
    this.exitPointerLock();
    audioEngine.playUiConfirm(false);
    this.callbacks.onMissionEnd({
      victory: false,
      missionId: this.currentMission.id,
      score: this.score,
      kills: this.kills,
      deaths: this.deaths,
      timeSec: Math.max(1, Math.round(this.matchTimerSec)),
      stars: 0,
    });
  }

  private resolveCollisions(pos: THREE.Vector3, radius: number): void {
    if (!this.activeMap) return;
    const b = this.activeMap.playBounds - 1.2;
    pos.x = THREE.MathUtils.clamp(pos.x, -b, b);
    pos.z = THREE.MathUtils.clamp(pos.z, -b, b);

    for (const c of this.activeMap.colliders) {
      if (pos.y > c.maxY) continue;
      const closestX = THREE.MathUtils.clamp(pos.x, c.minX, c.maxX);
      const closestZ = THREE.MathUtils.clamp(pos.z, c.minZ, c.maxZ);
      const dx = pos.x - closestX;
      const dz = pos.z - closestZ;
      const distSq = dx * dx + dz * dz;
      if (distSq < radius * radius) {
        const dist = Math.sqrt(distSq);
        if (dist > 0.0001) {
          const push = radius - dist;
          pos.x += (dx / dist) * push;
          pos.z += (dz / dist) * push;
        } else {
          // Inside box fallback
          pos.z = c.maxZ + radius;
        }
      }
    }
  }

  private hasLineOfSight(a: THREE.Vector3, b: THREE.Vector3, colliders: ColliderBox[]): boolean {
    const dir = _vec3b.copy(b).sub(a);
    const dist = dir.length();
    if (dist < 0.5) return true;
    dir.divideScalar(dist);
    // Sample steps against AABBs for ultra-fast LOS without expensive mesh raycasting
    const steps = Math.min(18, Math.ceil(dist / 2.2));
    for (let i = 1; i < steps; i++) {
      const t = (i / steps) * dist;
      const px = a.x + dir.x * t;
      const py = a.y + dir.y * t;
      const pz = a.z + dir.z * t;
      for (const c of colliders) {
        if (px >= c.minX && px <= c.maxX && py >= c.minY && py <= c.maxY && pz >= c.minZ && pz <= c.maxZ) {
          return false;
        }
      }
    }
    return true;
  }

  private scheduleNextFrame(): void {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(() => this.tick());
    } else {
      this.frameId = requestAnimationFrame(() => this.tick());
    }
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || !gl.fenceSync) {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick(): void {
    if (this.disposed) return;

    const now = performance.now();

    // Optional FPS cap pacing for 60 / 120 FPS hardware displays
    if (!this.isSoftwareGl && this.settings.fpsCap > 0) {
      const minInterval = 1000 / this.settings.fpsCap;
      if (now - this.lastRenderMs < minInterval * 0.92) {
        this.frameId = requestAnimationFrame(() => this.tick());
        return;
      }
    }

    const rawDt = (now - this.lastFrameMs) / 1000;
    this.lastFrameMs = now;
    this.lastRenderMs = now;
    const dt = Math.min(rawDt, 0.05);

    this.fpsAccum += rawDt;
    this.fpsFrames += 1;
    if (this.fpsAccum >= 0.5) {
      this.currentFps = Math.round(this.fpsFrames / this.fpsAccum);
      this.fpsAccum = 0;
      this.fpsFrames = 0;
    }

    const elapsed = now * 0.001;

    if (this.mode === 'menu') {
      if (this.menuDiorama) {
        this.menuDiorama.animate(dt, elapsed);
      }
      const camAng = elapsed * 0.14;
      this.camera.position.set(Math.cos(camAng) * 24, 9.5 + Math.sin(elapsed * 0.4) * 1.2, Math.sin(camAng) * 24);
      this.camera.lookAt(0, 2.2, -3);
      this.particles.update(dt, 0, 0);
      this.renderFrame();
      this.scheduleNextFrame();
      return;
    }

    if (!this.paused && !this.missionEnded) {
      this.updateSimulation(dt, elapsed);
    }

    this.renderFrame();
    this.scheduleNextFrame();
  }

  private renderFrame(): void {
    if (this.composer && !this.isSoftwareGl && (this.settings.graphics === 'ultra' || this.settings.graphics === 'high')) {
      this.composer.render();
    } else {
      this.renderer.render(this.scene, this.camera);
    }
  }

  private updateSimulation(dt: number, elapsed: number): void {
    this.matchTimerSec += dt;

    // Animated map props & fire site smoke
    if (this.activeMap) {
      for (const fn of this.activeMap.animatedObjects) fn(dt, elapsed);
      this.smokeEmitTimer += dt;
      if (this.smokeEmitTimer >= 0.28) {
        this.smokeEmitTimer = 0;
        for (const fs of this.activeMap.fireSites) {
          this.particles.spawnSmokeColumn(fs);
        }
      }
    }

    // Storm lightning flashes in Mission 8
    if (this.currentMission?.ambientWeather === 'rain_storm') {
      this.lightningTimer -= dt;
      if (this.lightningTimer <= 0) {
        this.lightningTimer = 4 + Math.random() * 6;
        this.keyLight.intensity = 6.5;
        audioEngine.playThunder();
      } else {
        this.keyLight.intensity = THREE.MathUtils.damp(this.keyLight.intensity, this.currentMission.sunIntensity, 7, dt);
      }
    }

    // Cinematic intro pan
    if (this.cinematicActive) {
      this.cinematicTimer += dt;
      const t = this.cinematicTimer / this.cinematicDuration;
      this.camera.position.set(
        THREE.MathUtils.lerp(-24, 0, t),
        THREE.MathUtils.lerp(18, 5.5, t),
        THREE.MathUtils.lerp(14, this.playerPos.z + 4, t)
      );
      this.camera.lookAt(0, 1.5, -16);
      if (t >= 1) {
        this.skipCinematic();
      }
      this.particles.update(dt, 0, 0);
      this.emitHudSnapshot();
      return;
    }

    // Timers & Special Ability Cooldown/Regen
    if (this.fireCooldown > 0) this.fireCooldown -= dt;
    if (this.abilityCooldown > 0) this.abilityCooldown = Math.max(0, this.abilityCooldown - dt);
    if (this.abilityActiveTimer > 0) {
      this.abilityActiveTimer = Math.max(0, this.abilityActiveTimer - dt);
      if (this.characterId === 'medic' && this.hp > 0 && this.hp < this.maxHp) {
        this.hp = Math.min(this.maxHp, this.hp + 8 * dt);
      }
    }
    if (this.enemyStunTimer > 0) this.enemyStunTimer = Math.max(0, this.enemyStunTimer - dt);
    if (this.hitmarkerTimer > 0) {
      this.hitmarkerTimer -= dt;
      if (this.hitmarkerTimer <= 0) this.hitmarkerKind = 'none';
    }
    if (this.damageFlash > 0) this.damageFlash = Math.max(0, this.damageFlash - dt * 2.5);
    if (this.healFlash > 0) this.healFlash = Math.max(0, this.healFlash - dt * 2.2);
    if (this.muzzleLight.intensity > 0) this.muzzleLight.intensity = Math.max(0, this.muzzleLight.intensity - dt * 45);
    if (this.respawnTimerSec > 0) this.respawnTimerSec = Math.max(0, this.respawnTimerSec - dt);

    // Medkit healing channel
    if (this.healing) {
      if (this.hp <= 0) {
        this.healing = false;
        this.healTimer = 0;
      } else {
        this.healTimer -= dt;
        if (this.healTimer <= 0) {
          this.healing = false;
          this.healTimer = 0;
          this.hp = Math.min(this.maxHp, this.hp + 50);
          this.armor = Math.min(this.maxArmor + 20, this.armor + 15);
          this.healFlash = 1.0;
          if (this.mode === 'multiplayer') {
            mpClient.sendHeal();
          }
        }
      }
    }

    // Reloading
    if (this.reloading) {
      this.reloadTimer -= dt;
      if (this.reloadTimer <= 0) {
        this.reloading = false;
        const w = WEAPONS[this.getActiveWeaponId()];
        const st = this.ammoState[this.activeSlot];
        const needed = w.magSize - st.mag;
        const transfer = Math.min(needed, st.reserve);
        st.mag += transfer;
        st.reserve -= transfer;
      }
    }

    // Player movement
    let moveFwd = 0;
    let moveStrafe = 0;
    if (this.hp > 0) {
      if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) moveFwd += 1;
      if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) moveFwd -= 1;
      if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) moveStrafe += 1;
      if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) moveStrafe -= 1;

      moveStrafe += this.touchMoveX;
      moveFwd += this.touchMoveY;
    }

    const moving = Math.abs(moveFwd) > 0.05 || Math.abs(moveStrafe) > 0.05;
    const touchFullSprint = this.touchMoveY > 0.9;
    this.sprinting =
      moving &&
      !this.ads &&
      !this.crouching &&
      (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || touchFullSprint) &&
      this.stamina > 5;

    if (this.sprinting) {
      this.stamina = Math.max(0, this.stamina - dt * 24);
    } else {
      this.stamina = Math.min(100, this.stamina + dt * 16);
    }

    const abilitySpeedMult =
      this.abilityActiveTimer > 0
        ? this.characterId === 'striker'
          ? 1.28
          : this.characterId === 'ghost'
            ? 1.22
            : 1.0
        : 1.0;
    const charMult = CHARACTERS[this.characterId].speedMult * abilitySpeedMult;
    const baseSpeed = 7.4 * charMult * (this.sprinting ? 1.42 : this.crouching ? 0.56 : this.ads ? 0.65 : 1.0);

    const sinY = Math.sin(this.yaw);
    const cosY = Math.cos(this.yaw);
    let vx = (-sinY * moveFwd + cosY * moveStrafe);
    let vz = (-cosY * moveFwd - sinY * moveStrafe);
    const len = Math.hypot(vx, vz);
    if (len > 1) {
      vx /= len;
      vz /= len;
    }

    this.playerPos.x += vx * baseSpeed * dt;
    this.playerPos.z += vz * baseSpeed * dt;

    // Gravity & Jump
    this.playerVelY -= 19.5 * dt;
    this.playerPos.y += this.playerVelY * dt;
    if (this.playerPos.y <= 0) {
      this.playerPos.y = 0;
      this.playerVelY = 0;
      this.grounded = true;
    }

    this.resolveCollisions(this.playerPos, 0.55);

    const silentSteps = this.characterId === 'ghost' && this.abilityActiveTimer > 0;
    if (moving && this.grounded && !silentSteps) {
      this.stepTimer -= dt * (this.sprinting ? 1.45 : 1);
      if (this.stepTimer <= 0) {
        this.stepTimer = 0.38;
        audioEngine.playFootstep();
      }
    }

    // Continuous auto-fire
    if ((this.mouseFireHeld || this.touchFireHeld) && this.hp > 0) {
      this.tryFire(false);
    }

    // Local Player Death Camera Collapse Animation
    if (this.playerDying) {
      this.playerDeathTimer += dt;
      const fallT = Math.min(1, this.playerDeathTimer / 0.65);
      const ease = 1 - Math.pow(1 - fallT, 2);
      const curEyeH = THREE.MathUtils.lerp(this.crouching ? 1.05 : 1.66, 0.26, ease);
      const shakeX = (Math.random() - 0.5) * this.shakeIntensity * 0.15;
      const shakeY = (Math.random() - 0.5) * this.shakeIntensity * 0.15;
      this.camera.position.set(this.playerPos.x + shakeX, this.playerPos.y + curEyeH + shakeY, this.playerPos.z);
      this.camera.rotation.y = this.yaw;
      this.camera.rotation.x = THREE.MathUtils.lerp(this.pitch, 0.35, ease);
      this.camera.rotation.z = THREE.MathUtils.lerp(0, 0.72, ease);
      this.viewModelRoot.position.y = THREE.MathUtils.lerp(-0.2, -0.75, ease);
      this.viewModelRoot.rotation.z = THREE.MathUtils.lerp(0, -0.8, ease);
      this.damageFlash = Math.max(this.damageFlash, 0.7);
      if (this.mode === 'campaign' && this.playerDeathTimer >= 1.25) {
        this.playerDying = false;
        this.failCampaignMission();
        return;
      }
    } else {
      // Smooth recoil recovery & camera placement
      this.recoilPitchOffset = THREE.MathUtils.damp(this.recoilPitchOffset, 0, 12, dt);
      this.recoilYawOffset = THREE.MathUtils.damp(this.recoilYawOffset, 0, 12, dt);
      this.shakeIntensity = THREE.MathUtils.damp(this.shakeIntensity, 0, 14, dt);

      const eyeH = this.crouching ? 1.05 : 1.66;
      const shakeX = (Math.random() - 0.5) * this.shakeIntensity * 0.25;
      const shakeY = (Math.random() - 0.5) * this.shakeIntensity * 0.25;
      this.camera.position.set(this.playerPos.x + shakeX, this.playerPos.y + eyeH + shakeY, this.playerPos.z);
      this.camera.rotation.y = this.yaw + this.recoilYawOffset;
      this.camera.rotation.x = THREE.MathUtils.clamp(this.pitch + this.recoilPitchOffset, -Math.PI * 0.46, Math.PI * 0.46);
      this.camera.rotation.z = 0;

      // Smooth ADS FOV damping
      const activeW = WEAPONS[this.getActiveWeaponId()];
      const targetFov = this.ads ? activeW.adsFov : this.settings.fov;
      if (Math.abs(this.camera.fov - targetFov) > 0.1) {
        this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 14, dt);
        this.camera.updateProjectionMatrix();
      }

      // Weapon ViewModel procedural positioning + sway + bob
      this.viewModelKick = THREE.MathUtils.damp(this.viewModelKick, 0, 16, dt);
      if (moving && this.grounded) this.walkBobPhase += dt * (this.sprinting ? 13 : 8.5);
      const bobX = moving ? Math.cos(this.walkBobPhase) * 0.012 : 0;
      const bobY = moving ? Math.abs(Math.sin(this.walkBobPhase)) * 0.014 : 0;
      const targetVx = this.ads ? 0 : 0.22;
      const targetVy = this.reloading ? -0.32 : this.ads ? -0.145 : -0.2;
      const targetVz = this.ads ? -0.32 : -0.44;
      this.viewModelRoot.position.set(
        THREE.MathUtils.damp(this.viewModelRoot.position.x, targetVx + bobX, 16, dt),
        THREE.MathUtils.damp(this.viewModelRoot.position.y, targetVy - bobY, 16, dt),
        THREE.MathUtils.damp(this.viewModelRoot.position.z, targetVz + this.viewModelKick, 18, dt)
      );
      this.viewModelRoot.rotation.x = this.reloading ? -0.45 : this.viewModelKick * 1.4;
      this.viewModelRoot.rotation.y = this.sprinting ? 0.35 : 0;
      this.viewModelRoot.rotation.z = 0;
    }

    // Update grenades
    this.updateGrenades(dt);

    // Campaign AI & Proximity Objectives
    if (this.mode === 'campaign') {
      this.updateCampaignAi(dt);
      this.updateCampaignObjectives(dt);
    }

    // Multiplayer sync & remote interpolation
    if (this.mode === 'multiplayer') {
      this.mpSyncTimer += dt;
      if (this.mpSyncTimer >= 0.05) {
        this.mpSyncTimer = 0;
        mpClient.sendPlayerState({
          x: this.playerPos.x,
          y: this.playerPos.y,
          z: this.playerPos.z,
          yaw: this.yaw,
          pitch: this.pitch,
          crouching: this.crouching,
          moving,
          weaponId: this.getActiveWeaponId(),
        });
      }
      this.updateRemotePlayers(dt);
    }

    this.particles.update(dt, this.playerPos.x, this.playerPos.z);

    this.hudEmitTimer += dt;
    if (this.hudEmitTimer >= 0.05) {
      this.hudEmitTimer = 0;
      this.emitHudSnapshot();
    }
  }

  private updateGrenades(dt: number): void {
    for (let i = this.grenadesActive.length - 1; i >= 0; i--) {
      const g = this.grenadesActive[i];
      g.fuse -= dt;
      g.vel.y -= 16 * dt;
      g.pos.addScaledVector(g.vel, dt);
      if (g.pos.y < 0.14) {
        g.pos.y = 0.14;
        g.vel.y = Math.abs(g.vel.y) * 0.35;
        g.vel.x *= 0.6;
        g.vel.z *= 0.6;
      }
      g.mesh.position.copy(g.pos);

      if (g.fuse <= 0) {
        this.particles.spawnExplosion(g.pos, 7.5);
        audioEngine.playExplosion(1);
        this.shakeIntensity = Math.max(this.shakeIntensity, 0.5);
        this.scene.remove(g.mesh);
        this.grenadesActive.splice(i, 1);

        // Splash damage to campaign AI or objectives
        if (this.mode === 'campaign') {
          for (const u of this.aiUnits) {
            if (!u.alive || u.isAlly || u.isCivilian) continue;
            const d = Math.hypot(u.x - g.pos.x, u.z - g.pos.z);
            if (d < 8.5) {
              const dmg = Math.round((1 - d / 8.5) * 165);
              u.hp -= dmg;
              if (u.hp <= 0) this.onAiKilled(u, this.primaryWeaponId, false);
            }
          }
          if (this.activeMap && this.currentMission?.objectiveKind === 'destroy_targets') {
            for (const node of this.activeMap.objectiveNodes) {
              if (node.completed) continue;
              const d = Math.hypot(node.x - g.pos.x, node.z - g.pos.z);
              if (d < 8) {
                node.hp -= 140;
                if (node.hp <= 0) {
                  node.completed = true;
                  node.beacon.visible = false;
                  node.mesh.visible = false;
                  this.objectiveProgress += 1;
                  this.score += 300;
                  this.checkCampaignWin();
                }
              }
            }
          }
        }
      }
    }
  }

  private updateCampaignObjectives(dt: number): void {
    if (!this.activeMap || !this.currentMission || this.missionEnded) return;
    if (this.currentMission.objectiveKind === 'capture_zone') {
      for (const node of this.activeMap.objectiveNodes) {
        if (node.completed) continue;
        const d = Math.hypot(node.x - this.playerPos.x, node.z - this.playerPos.z);
        if (d < 5.2) {
          node.hp -= dt * 28;
          if (node.hp <= 0) {
            node.completed = true;
            node.beacon.visible = false;
            this.objectiveProgress += 1;
            this.score += 350;
            audioEngine.playUiConfirm(true);
            this.checkCampaignWin();
          }
        }
      }
    } else if (this.currentMission.objectiveKind === 'hack_terminals') {
      const near = this.activeMap.objectiveNodes.find(
        (n) => !n.completed && Math.hypot(n.x - this.playerPos.x, n.z - this.playerPos.z) < 4.0
      );
      if (near) {
        this.hackProgress += dt;
        if (this.hackProgress >= 1.8) {
          this.hackProgress = 0;
          near.completed = true;
          near.beacon.visible = false;
          this.objectiveProgress += 1;
          this.score += 250;
          audioEngine.playUiConfirm(true);
          this.checkCampaignWin();
        }
      } else {
        this.hackProgress = 0;
      }
    } else if (this.currentMission.objectiveKind === 'rescue_civilians') {
      for (const u of this.aiUnits) {
        if (u.isCivilian && !u.rescued && Math.hypot(u.x - this.playerPos.x, u.z - this.playerPos.z) < 3.4) {
          u.rescued = true;
          u.rig.root.visible = false;
          this.objectiveProgress += 1;
          this.score += 200;
          audioEngine.playUiConfirm(true);
          this.checkCampaignWin();
        }
      }
    }
  }

  private updateCampaignAi(dt: number): void {
    if (!this.activeMap) return;
    const colliders = this.activeMap.colliders;
    const coreNode =
      this.currentMission?.objectiveKind === 'defend_core'
        ? this.activeMap.objectiveNodes[0]
        : null;

    for (const u of this.aiUnits) {
      if (!u.alive) {
        if (u.deathTimer > 0) {
          u.deathTimer += dt;
          const t = Math.min(1, u.deathTimer / 0.5);
          const ease = 1 - Math.pow(1 - t, 2);
          u.rig.root.rotation.x = ease * (Math.PI * 0.48) * u.deathDir;
          u.rig.root.rotation.z = ease * u.deathTilt * 0.35;
          u.rig.root.position.y = ease * 0.18;
          u.rig.leftLeg.rotation.x = ease * 0.5;
          u.rig.rightLeg.rotation.x = -ease * 0.25;
          u.rig.leftArm.rotation.x = -ease * 1.05;
          u.rig.rightArm.rotation.x = -ease * 0.85;
          u.rig.leftArm.rotation.z = ease * 0.45;
          u.rig.rightArm.rotation.z = -ease * 0.45;
          if (u.deathTimer > 3.0) {
            u.rig.root.position.y -= (u.deathTimer - 3.0) * 1.1;
          }
          if (u.deathTimer >= 3.5) {
            u.rig.root.visible = false;
            u.deathTimer = 0;
          }
        }
        continue;
      }
      if (u.isCivilian) {
        u.rig.root.rotation.y += dt * 0.5;
        continue;
      }
      if (!u.isAlly && this.enemyStunTimer > 0) {
        // EMP stunned by Spectre ability
        u.rig.leftLeg.rotation.x = 0;
        u.rig.rightLeg.rotation.x = 0;
        u.rig.torso.rotation.x = Math.sin(this.matchTimerSec * 28) * 0.08;
        continue;
      }
      u.rig.torso.rotation.x = 0;

      // Target selection
      let targetPos = this.playerPos;
      let targetIsUnit: AiUnit | null = null;

      if (u.isAlly) {
        // Allies seek nearest alive enemy
        let bestD = Infinity;
        for (const other of this.aiUnits) {
          if (other.alive && !other.isAlly && !other.isCivilian) {
            const d = Math.hypot(other.x - u.x, other.z - u.z);
            if (d < bestD) {
              bestD = d;
              targetIsUnit = other;
            }
          }
        }
        if (targetIsUnit) {
          _vec3.set(targetIsUnit.x, 0, targetIsUnit.z);
          targetPos = _vec3;
        }
      } else if (coreNode && Math.hypot(coreNode.x - u.x, coreNode.z - u.z) < Math.hypot(this.playerPos.x - u.x, this.playerPos.z - u.z)) {
        _vec3.set(coreNode.x, 0, coreNode.z);
        targetPos = _vec3;
      }

      const dx = targetPos.x - u.x;
      const dz = targetPos.z - u.z;
      const dist = Math.hypot(dx, dz);
      u.yaw = Math.atan2(dx, dz);
      u.rig.root.rotation.y = u.yaw;

      const eyeA = new THREE.Vector3(u.x, 1.5, u.z);
      const eyeB = new THREE.Vector3(targetPos.x, 1.5, targetPos.z);
      const canSee = dist < (u.archetype === 'sniper' ? 58 : 42) && this.hasLineOfSight(eyeA, eyeB, colliders);

      let isMoving = false;
      const preferredDist = u.archetype === 'rusher' ? 6 : u.archetype === 'sniper' ? 28 : 15;

      if (dist > preferredDist || !canSee) {
        isMoving = true;
        const step = u.speed * dt;
        const nx = u.x + (dx / Math.max(0.01, dist)) * step;
        const nz = u.z + (dz / Math.max(0.01, dist)) * step;
        const pTmp = new THREE.Vector3(nx, 0, nz);
        this.resolveCollisions(pTmp, 0.55);
        u.x = pTmp.x;
        u.z = pTmp.z;
      } else if (canSee) {
        // Tactical strafe
        isMoving = true;
        u.strafeTimer -= dt;
        if (u.strafeTimer <= 0) {
          u.strafeDir *= -1;
          u.strafeTimer = 1.2 + Math.random() * 1.4;
        }
        const perpX = (-dz / Math.max(0.01, dist)) * u.strafeDir;
        const perpZ = (dx / Math.max(0.01, dist)) * u.strafeDir;
        const pTmp = new THREE.Vector3(u.x + perpX * u.speed * 0.55 * dt, 0, u.z + perpZ * u.speed * 0.55 * dt);
        this.resolveCollisions(pTmp, 0.55);
        u.x = pTmp.x;
        u.z = pTmp.z;
      }

      u.rig.root.position.set(u.x, 0, u.z);
      if (isMoving) {
        u.walkPhase += dt * u.speed * 2.1;
        const swing = Math.sin(u.walkPhase) * 0.55;
        u.rig.leftLeg.rotation.x = swing;
        u.rig.rightLeg.rotation.x = -swing;
        u.rig.leftArm.rotation.x = -swing * 0.35;
      } else {
        u.rig.leftLeg.rotation.x = 0;
        u.rig.rightLeg.rotation.x = 0;
      }

      // Firing logic
      u.fireCooldown -= dt;
      if (canSee && u.fireCooldown <= 0) {
        u.fireCooldown = u.isBoss ? 0.22 : u.archetype === 'sniper' ? 2.1 : 0.75 + Math.random() * 0.75;
        const muzzleStart = new THREE.Vector3(u.x, 1.45, u.z);
        const dirToTarget = new THREE.Vector3(dx, -0.05, dz).normalize();
        const tracerEnd = muzzleStart.clone().addScaledVector(dirToTarget, Math.min(dist, 45));
        this.particles.spawnTracer(muzzleStart, tracerEnd, u.isAlly ? 0x34d399 : 0xff6b35);
        audioEngine.playWeaponFire(u.isBoss ? 'm249' : 'ak74m', Math.max(0.1, 1 - dist / 55));

        if (u.isAlly && targetIsUnit) {
          if (Math.random() < 0.42) {
            targetIsUnit.hp -= 24;
            if (targetIsUnit.hp <= 0) {
              this.onAiKilled(targetIsUnit, 'm4a1', false);
            }
          }
        } else if (!u.isAlly) {
          if (coreNode && targetPos.x === coreNode.x && targetPos.z === coreNode.z) {
            coreNode.hp -= u.isBoss ? 22 : 12;
            if (coreNode.hp <= 0) {
              this.failCampaignMission();
              return;
            }
          } else {
            const ghostStealthFactor = this.characterId === 'ghost' && this.abilityActiveTimer > 0 ? 0.2 : 1.0;
            const hitChance = Math.max(0.05, (0.44 - dist * 0.007) * (this.crouching ? 0.75 : 1) * ghostStealthFactor);
            if (Math.random() < hitChance) {
              const vanguardReduction = this.characterId === 'vanguard' && this.abilityActiveTimer > 0 ? 0.45 : 1.0;
              let dmg = (u.isBoss ? 14 : u.archetype === 'sniper' ? 24 : 8 + (this.currentMission?.difficulty || 1) * 1.5) * vanguardReduction;
              if (this.armor > 0) {
                const absorbed = Math.min(this.armor, dmg * 0.55);
                this.armor -= absorbed;
                dmg -= absorbed;
              }
              this.hp = Math.max(0, this.hp - dmg);
              this.damageFlash = 0.9;
              this.shakeIntensity = Math.max(this.shakeIntensity, 0.16);
              if (this.hp <= 0 && !this.playerDying) {
                this.deaths += 1;
                this.ads = false;
                this.touchFireHeld = false;
                this.mouseFireHeld = false;
                this.playerDying = true;
                this.playerDeathTimer = 0.001;
                return;
              }
            }
          }
        }
      }
    }
  }

  private updateRemotePlayers(dt: number): void {
    for (const rem of this.remotePlayers.values()) {
      if (!rem.alive) {
        if (rem.deathTimer > 0) {
          rem.deathTimer += dt;
          const t = Math.min(1, rem.deathTimer / 0.5);
          const ease = 1 - Math.pow(1 - t, 2);
          rem.rig.root.rotation.x = ease * (Math.PI * 0.48) * rem.deathDir;
          rem.rig.root.position.y = ease * 0.18;
          rem.rig.leftLeg.rotation.x = ease * 0.45;
          rem.rig.rightLeg.rotation.x = -ease * 0.25;
          rem.rig.leftArm.rotation.x = -ease * 1.0;
          rem.rig.rightArm.rotation.x = -ease * 0.85;
          if (rem.deathTimer > 2.4) {
            rem.rig.root.position.y -= (rem.deathTimer - 2.4) * 1.1;
          }
          if (rem.deathTimer >= 2.9) {
            rem.rig.root.visible = false;
            rem.deathTimer = 0;
          }
        }
        continue;
      }
      rem.rig.root.rotation.x = 0;
      rem.rig.root.rotation.z = 0;
      rem.rig.root.position.x = THREE.MathUtils.damp(rem.rig.root.position.x, rem.targetX, 14, dt);
      rem.rig.root.position.y = THREE.MathUtils.damp(rem.rig.root.position.y, rem.targetY, 14, dt);
      rem.rig.root.position.z = THREE.MathUtils.damp(rem.rig.root.position.z, rem.targetZ, 14, dt);
      rem.rig.root.rotation.y = rem.targetYaw + Math.PI;
      rem.rig.torso.position.y = rem.crouching ? 0.62 : 0.88;
      if (rem.moving) {
        rem.walkPhase += dt * 11;
        const swing = Math.sin(rem.walkPhase) * 0.55;
        rem.rig.leftLeg.rotation.x = swing;
        rem.rig.rightLeg.rotation.x = -swing;
      } else {
        rem.rig.leftLeg.rotation.x = 0;
        rem.rig.rightLeg.rotation.x = 0;
      }
    }
  }

  private emitHudSnapshot(): void {
    const wId = this.getActiveWeaponId();
    const w = WEAPONS[wId];
    const st = this.ammoState[this.activeSlot];

    // Radar blips
    const radarBlips: HudSnapshot['radarBlips'] = [];
    if (this.mode === 'campaign') {
      for (const u of this.aiUnits) {
        if (!u.alive) continue;
        radarBlips.push({
          x: u.x,
          z: u.z,
          kind: u.isCivilian ? 'civilian' : u.isAlly ? 'ally' : 'enemy',
        });
      }
      if (this.activeMap) {
        for (const n of this.activeMap.objectiveNodes) {
          if (!n.completed) {
            radarBlips.push({ x: n.x, z: n.z, kind: 'objective' });
          }
        }
      }
    } else if (this.mode === 'multiplayer') {
      for (const rem of this.remotePlayers.values()) {
        if (!rem.alive) continue;
        radarBlips.push({
          x: rem.rig.root.position.x,
          z: rem.rig.root.position.z,
          kind: rem.team === this.mpLocalTeam ? 'ally' : 'enemy',
        });
      }
    }

    // Project multiplayer player nametags above characters
    const nametags: ProjectedNametag[] = [];
    if (this.mode === 'multiplayer') {
      const width = this.container.clientWidth || window.innerWidth;
      const height = this.container.clientHeight || window.innerHeight;
      for (const rem of this.remotePlayers.values()) {
        if (!rem.alive) continue;
        _proj.copy(rem.rig.root.position);
        _proj.y += 2.15;
        const dist = _proj.distanceTo(this.camera.position);
        _proj.project(this.camera);
        const visible = _proj.z > 0 && _proj.z < 1 && dist < 75;
        nametags.push({
          id: rem.id,
          name: rem.callsign,
          team: rem.team,
          hp: rem.hp,
          screenX: ((_proj.x + 1) / 2) * width,
          screenY: ((-_proj.y + 1) / 2) * height,
          distance: dist,
          visible,
        });
      }
    }

    // Interaction prompt
    let interactPromptAr: string | null = null;
    if (this.mode === 'campaign' && this.currentMission && this.activeMap) {
      if (this.currentMission.objectiveKind === 'hack_terminals') {
        const near = this.activeMap.objectiveNodes.some(
          (n) => !n.completed && Math.hypot(n.x - this.playerPos.x, n.z - this.playerPos.z) < 4.2
        );
        if (near) interactPromptAr = 'جارٍ اختراق المحطة... أو اضغط [E]';
      } else if (this.currentMission.objectiveKind === 'capture_zone') {
        const near = this.activeMap.objectiveNodes.some(
          (n) => !n.completed && Math.hypot(n.x - this.playerPos.x, n.z - this.playerPos.z) < 5.2
        );
        if (near) interactPromptAr = 'جاري تأمين نقطة السيطرة...';
      } else if (this.currentMission.objectiveKind === 'rescue_civilians') {
        const near = this.aiUnits.some(
          (u) => u.isCivilian && !u.rescued && Math.hypot(u.x - this.playerPos.x, u.z - this.playerPos.z) < 4.5
        );
        if (near) interactPromptAr = 'اضغط [E] لإنقاذ المدني';
      } else if (this.currentMission.objectiveKind === 'boss_citadel') {
        const near = this.activeMap.objectiveNodes.some(
          (n) => !n.completed && Math.hypot(n.x - this.playerPos.x, n.z - this.playerPos.z) < 4.5
        );
        if (near) interactPromptAr = 'اضغط [E] لتعطيل درع المفاعل';
      }
    }

    const cineIdx = Math.min(
      (this.currentMission?.cinematicLinesAr.length || 1) - 1,
      Math.floor((this.cinematicTimer / this.cinematicDuration) * (this.currentMission?.cinematicLinesAr.length || 1))
    );

    const coreNode = this.currentMission?.objectiveKind === 'defend_core' ? this.activeMap?.objectiveNodes[0] : undefined;

    const activeChar = CHARACTERS[this.characterId];
    this.callbacks.onHudUpdate({
      hp: Math.round(this.hp),
      maxHp: this.maxHp,
      armor: Math.round(this.armor),
      maxArmor: this.maxArmor,
      stamina: Math.round(this.stamina),
      weaponId: wId,
      ammo: st.mag,
      reserve: st.reserve,
      reloading: this.reloading,
      reloadProgress: this.reloading ? 1 - this.reloadTimer / w.reloadTimeSec : 0,
      grenades: this.grenades,
      ads: this.ads,
      crouching: this.crouching,
      sprinting: this.sprinting,
      fps: this.currentFps,
      score: this.score,
      kills: this.kills,
      deaths: this.deaths,
      objectiveTextAr:
        this.mode === 'multiplayer'
          ? this.mpRoom?.mode === 'domination'
            ? 'السيطرة على النقاط (A - B - C)'
            : 'مباراة الموت الجماعية'
          : this.currentMission?.objectiveLabelAr || '',
      objectiveProgress: this.objectiveProgress,
      objectiveTarget: this.objectiveTarget,
      timerSec: this.mode === 'multiplayer' ? this.mpRoom?.timeRemainingSec || 0 : Math.floor(this.matchTimerSec),
      wave: this.currentMission?.waves ? this.currentWave : undefined,
      maxWaves: this.currentMission?.waves,
      baseCoreHp: coreNode ? Math.max(0, Math.round((coreNode.hp / coreNode.maxHp) * 100)) : undefined,
      alphaScore: this.mpRoom?.alphaScore,
      bravoScore: this.mpRoom?.bravoScore,
      scoreLimit: this.mpRoom?.scoreLimit,
      capturePoints: this.mpRoom?.capturePoints,
      hitmarkerKind: this.hitmarkerKind,
      damageFlash: this.damageFlash,
      lowHealth: this.hp > 0 && this.hp <= 28,
      pointerLocked: this.pointerLocked,
      cinematicActive: this.cinematicActive,
      cinematicCaptionAr: this.currentMission?.cinematicLinesAr[cineIdx] || '',
      interactPromptAr,
      playerPos: { x: this.playerPos.x, z: this.playerPos.z, yaw: this.yaw },
      radarBlips,
      nametags,
      respawnTimerSec: this.respawnTimerSec,
      abilityNameAr: activeChar.abilityNameAr,
      abilityCooldownSec: this.abilityCooldown,
      abilityMaxCooldownSec: activeChar.abilityCooldownSec,
      abilityActiveSec: this.abilityActiveTimer,
      abilityAccent: activeChar.abilityAccent,
      medkits: this.medkits,
      healing: this.healing,
      healProgress: this.healing ? Math.max(0, Math.min(1, 1 - this.healTimer / this.healDuration)) : 0,
      healFlash: this.healFlash,
    });
  }

  dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);
    this.unbindEvents();
    this.exitPointerLock();
    this.clearActiveWorld();
    this.particles.dispose();
    this.textures.dispose();
    this.composer?.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
