import * as THREE from 'three';
import type { BiomeType, MissionDef } from '../game/types';
import {
  buildArmoredVehicle,
  buildFuelTankTarget,
  buildHelicopter,
  buildRadarArray,
  buildShippingContainer,
  buildTerminalTarget,
  buildWatchtower,
} from './ModelBuilders';
import type { TextureBundle } from './ProceduralTextures';

export interface ColliderBox {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
}

export interface InteractiveObjectiveNode {
  id: string;
  x: number;
  y: number;
  z: number;
  hp: number;
  maxHp: number;
  completed: boolean;
  mesh: THREE.Group;
  beacon: THREE.Mesh;
}

export interface BuiltMap {
  root: THREE.Group;
  colliders: ColliderBox[];
  raycastObstacles: THREE.Object3D[];
  playBounds: number;
  playerSpawn: THREE.Vector3;
  enemySpawns: THREE.Vector3[];
  allySpawns: THREE.Vector3[];
  objectiveNodes: InteractiveObjectiveNode[];
  fireSites: THREE.Vector3[];
  animatedObjects: Array<(dt: number, elapsed: number) => void>;
  dispose: () => void;
}

function addBoxCollider(colliders: ColliderBox[], cx: number, cy: number, cz: number, sx: number, sy: number, sz: number) {
  colliders.push({
    minX: cx - sx * 0.5,
    maxX: cx + sx * 0.5,
    minY: cy - sy * 0.5,
    maxY: cy + sy * 0.5,
    minZ: cz - sz * 0.5,
    maxZ: cz + sz * 0.5,
  });
}

function createBuilding(
  w: number,
  h: number,
  d: number,
  mat: THREE.Material,
  trimMat: THREE.Material,
  windowMat: THREE.Material
): THREE.Group {
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  body.position.y = h * 0.5;
  body.castShadow = true;
  body.receiveShadow = true;

  const roofTrim = new THREE.Mesh(new THREE.BoxGeometry(w + 0.4, 0.35, d + 0.4), trimMat);
  roofTrim.position.y = h + 0.15;
  roofTrim.castShadow = true;

  const plinth = new THREE.Mesh(new THREE.BoxGeometry(w + 0.3, 0.5, d + 0.3), trimMat);
  plinth.position.y = 0.25;
  plinth.receiveShadow = true;

  g.add(body, roofTrim, plinth);

  // Add recessed-style window strips on front/back
  if (h >= 4.5) {
    const rows = Math.floor(h / 3.2);
    for (let r = 0; r < rows; r++) {
      const wy = 2.1 + r * 3.0;
      const winF = new THREE.Mesh(new THREE.BoxGeometry(w * 0.65, 0.9, 0.12), windowMat);
      winF.position.set(0, wy, d * 0.5 + 0.02);
      const winB = winF.clone();
      winB.position.z = -d * 0.5 - 0.02;
      g.add(winF, winB);
    }
  }
  return g;
}

function createSandbagBunker(textures: TextureBundle): THREE.Group {
  const g = new THREE.Group();
  const bagMat = new THREE.MeshStandardMaterial({
    map: textures.sandbag,
    roughness: 0.92,
    metalness: 0.02,
  });
  for (let row = 0; row < 3; row++) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.48, 0.9), bagMat);
    wall.position.set(0, 0.24 + row * 0.45, 0);
    wall.castShadow = true;
    wall.receiveShadow = true;
    g.add(wall);
  }
  return g;
}

function createNaturePerimeter(
  root: THREE.Group,
  biome: BiomeType,
  textures: TextureBundle,
  radius: number
) {
  // Distant natural terrain ring (mountain ridges / desert dunes / coastal cliffs)
  const isDesert = biome === 'desert';
  const isHarbor = biome === 'harbor';
  const isMountain = biome === 'mountain' || biome === 'nightbase';
  const isCitadel = biome === 'citadel' || biome === 'defense_fort';

  const ridgeColor = isDesert
    ? 0xb58852
    : isMountain
      ? 0x48525e
      : isCitadel
        ? 0x2a1d1b
        : 0x38414a;

  const ridgeMat = new THREE.MeshStandardMaterial({
    color: ridgeColor,
    map: isDesert ? textures.desertSand : textures.mountainRock,
    roughness: 0.92,
    metalness: 0.04,
  });

  if (isHarbor) {
    // Ocean water surrounding the peninsula dock
    const waterMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(360, 360),
      new THREE.MeshStandardMaterial({
        map: textures.water,
        roughness: 0.18,
        metalness: 0.35,
      })
    );
    waterMesh.rotation.x = -Math.PI / 2;
    waterMesh.position.y = -0.65;
    waterMesh.receiveShadow = true;
    root.add(waterMesh);
  }

  // Instanced natural hills / rock outcrops around the playable arena perimeter
  const count = 40;
  const hillGeo = new THREE.ConeGeometry(18, 22, 7);
  const inst = new THREE.InstancedMesh(hillGeo, ridgeMat, count);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < count; i++) {
    const ang = (i / count) * Math.PI * 2;
    const dist = radius + 28 + (i % 3) * 14;
    dummy.position.set(Math.cos(ang) * dist, 6 + (i % 4) * 2.5, Math.sin(ang) * dist);
    dummy.rotation.y = ang + i * 0.7;
    const sc = 0.85 + (i % 5) * 0.25;
    dummy.scale.set(sc * 1.3, isDesert ? sc * 0.55 : sc * 1.15, sc);
    dummy.updateMatrix();
    inst.setMatrixAt(i, dummy.matrix);
  }
  inst.computeBoundingSphere();
  root.add(inst);

  // Subtle boundary jersey barriers along the outer playable perimeter
  const barrierMat = new THREE.MeshStandardMaterial({
    map: textures.concrete,
    roughness: 0.85,
    metalness: 0.08,
  });
  const barrierGeo = new THREE.BoxGeometry(5.5, 1.3, 0.8);
  const bInst = new THREE.InstancedMesh(barrierGeo, barrierMat, 48);
  let idx = 0;
  for (let side = 0; side < 4; side++) {
    for (let s = -5; s <= 5; s++) {
      if (idx >= 48) break;
      const offset = s * 9.5;
      if (side === 0) {
        dummy.position.set(offset, 0.65, -radius);
        dummy.rotation.y = 0;
      } else if (side === 1) {
        dummy.position.set(offset, 0.65, radius);
        dummy.rotation.y = 0;
      } else if (side === 2) {
        dummy.position.set(-radius, 0.65, offset);
        dummy.rotation.y = Math.PI / 2;
      } else {
        dummy.position.set(radius, 0.65, offset);
        dummy.rotation.y = Math.PI / 2;
      }
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      bInst.setMatrixAt(idx++, dummy.matrix);
    }
  }
  bInst.computeBoundingSphere();
  root.add(bInst);
}

function createBeaconMesh(colorHex: number): THREE.Mesh {
  const geo = new THREE.CylinderGeometry(0.18, 0.18, 22, 10, 1, true);
  const mat = new THREE.MeshBasicMaterial({
    color: colorHex,
    transparent: true,
    opacity: 0.28,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 11;
  return mesh;
}

export function buildCampaignMap(mission: MissionDef, textures: TextureBundle): BuiltMap {
  const root = new THREE.Group();
  const colliders: ColliderBox[] = [];
  const raycastObstacles: THREE.Object3D[] = [];
  const objectiveNodes: InteractiveObjectiveNode[] = [];
  const fireSites: THREE.Vector3[] = [];
  const animatedObjects: Array<(dt: number, elapsed: number) => void> = [];
  const playBounds = 52;

  const biome = mission.biome;
  const groundTex =
    biome === 'desert'
      ? textures.desertSand
      : biome === 'mountain' || biome === 'nightbase'
        ? textures.mountainRock
        : biome === 'citadel'
          ? textures.citadelMetal
          : biome === 'harbor'
            ? textures.concrete
            : textures.asphalt;

  const groundMat = new THREE.MeshStandardMaterial({
    map: groundTex,
    bumpMap: textures.bumpRough,
    bumpScale: 0.05,
    roughness: biome === 'citadel' ? 0.55 : 0.88,
    metalness: biome === 'citadel' ? 0.35 : 0.05,
  });

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(260, 260), groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  root.add(ground);
  raycastObstacles.push(ground);

  createNaturePerimeter(root, biome, textures, playBounds);

  const concreteMat = new THREE.MeshStandardMaterial({
    color: biome === 'desert' ? 0xc2a988 : biome === 'citadel' ? 0x2e2629 : 0x7c838b,
    map: textures.concrete,
    roughness: 0.82,
    metalness: 0.08,
  });
  const darkTrimMat = new THREE.MeshStandardMaterial({
    color: 0x1e242b,
    roughness: 0.45,
    metalness: 0.65,
  });
  const windowMat = new THREE.MeshStandardMaterial({
    color: biome === 'nightbase' || biome === 'storm' ? 0xf59e0b : 0x1b2b3a,
    emissive: biome === 'nightbase' || biome === 'storm' ? 0x78350f : 0x09131d,
    emissiveIntensity: 0.7,
    roughness: 0.15,
    metalness: 0.4,
  });
  const crateMat = new THREE.MeshStandardMaterial({
    map: textures.woodCrate,
    roughness: 0.8,
    metalness: 0.08,
  });

  const placeStructure = (mesh: THREE.Object3D, x: number, z: number, sx: number, sy: number, sz: number, rotY = 0) => {
    mesh.position.set(x, 0, z);
    mesh.rotation.y = rotY;
    root.add(mesh);
    raycastObstacles.push(mesh);
    addBoxCollider(colliders, x, sy * 0.5, z, sx, sy, sz);
  };

  // Biome-specific architecture & tactical cover
  if (biome === 'harbor') {
    const colors = [0xb91c1c, 0x1d4ed8, 0xd97706, 0x15803d];
    const containerPositions = [
      [-18, -14, 0],
      [-18, -5, 0],
      [18, 12, 0],
      [18, 2, 0],
      [0, -22, Math.PI / 2],
      [0, 22, Math.PI / 2],
      [-28, 16, 0],
      [28, -16, 0],
    ];
    containerPositions.forEach(([x, z, r], i) => {
      const c = buildShippingContainer(colors[i % colors.length], textures);
      const sx = r === 0 ? 3.1 : 6.9;
      const sz = r === 0 ? 6.9 : 3.1;
      placeStructure(c, x, z, sx, 2.9, sz, r);
    });
    const wh1 = createBuilding(12, 7.5, 16, concreteMat, darkTrimMat, windowMat);
    placeStructure(wh1, -34, 0, 12, 7.5, 16);
    const wh2 = createBuilding(12, 7.5, 16, concreteMat, darkTrimMat, windowMat);
    placeStructure(wh2, 34, 0, 12, 7.5, 16);
  } else if (biome === 'desert' || biome === 'mountain' || biome === 'storm') {
    // Rock formations, bunkers, and outpost buildings
    const rockMat = new THREE.MeshStandardMaterial({
      color: biome === 'desert' ? 0xa3784c : 0x525b66,
      map: biome === 'desert' ? textures.desertSand : textures.mountainRock,
      roughness: 0.9,
      metalness: 0.05,
    });
    const rockCoords = [
      [-20, -16, 5, 5.5, 5],
      [20, -14, 6, 6.2, 5],
      [-16, 18, 5, 4.8, 6],
      [22, 16, 6, 7.0, 5],
      [0, -28, 8, 6.5, 5],
      [-32, 4, 5, 5.0, 7],
      [32, -4, 5, 5.5, 7],
    ];
    rockCoords.forEach(([x, z, sx, sy, sz]) => {
      const m = new THREE.Mesh(new THREE.DodecahedronGeometry(sx * 0.62, 1), rockMat);
      m.scale.set(1, sy / sx, sz / sx);
      m.position.y = sy * 0.4;
      m.castShadow = true;
      m.receiveShadow = true;
      const g = new THREE.Group();
      g.add(m);
      placeStructure(g, x, z, sx * 0.9, sy, sz * 0.9);
    });

    const outpost = createBuilding(9, 4.5, 9, concreteMat, darkTrimMat, windowMat);
    placeStructure(outpost, 0, 0, 9, 4.5, 9);
  } else {
    // Urban / Nightbase / Defense / Warfront / Citadel multi-building layout
    const bldCoords = [
      [-24, -18, 10, 8.5, 10],
      [24, -18, 10, 10.5, 10],
      [-24, 18, 10, 9.0, 10],
      [24, 18, 10, 7.5, 10],
      [0, -26, 14, 6.5, 7],
      [-34, 0, 8, 11.0, 12],
      [34, 0, 8, 11.0, 12],
    ];
    bldCoords.forEach(([x, z, w, h, d]) => {
      const b = createBuilding(w, h, d, concreteMat, darkTrimMat, windowMat);
      placeStructure(b, x, z, w, h, d);
    });
  }

  // Common tactical cover: sandbags, crates, armored vehicles, watchtowers, radar
  const sandbagCoords = [
    [-10, -8, 0],
    [10, -8, 0],
    [-10, 10, 0],
    [10, 10, 0],
    [0, 14, 0],
    [-16, 0, Math.PI / 2],
    [16, 0, Math.PI / 2],
  ];
  sandbagCoords.forEach(([x, z, r]) => {
    const sb = createSandbagBunker(textures);
    const sx = r === 0 ? 4.4 : 1.0;
    const sz = r === 0 ? 1.0 : 4.4;
    placeStructure(sb, x, z, sx, 1.4, sz, r);
  });

  const crateCoords = [
    [-6, 4],
    [6, -4],
    [-14, -22],
    [14, 22],
    [-22, 6],
    [22, -6],
  ];
  crateCoords.forEach(([x, z]) => {
    const c = new THREE.Mesh(new THREE.BoxGeometry(1.7, 1.7, 1.7), crateMat);
    c.position.y = 0.85;
    c.castShadow = true;
    c.receiveShadow = true;
    const g = new THREE.Group();
    g.add(c);
    placeStructure(g, x, z, 1.7, 1.7, 1.7);
  });

  // Armored vehicles
  const v1 = buildArmoredVehicle(biome === 'desert' ? 0x9c8259 : 0x3b4a34, textures);
  placeStructure(v1, -12, 28, 2.7, 2.6, 5.3, 0.35);
  const v2 = buildArmoredVehicle(0x2e353d, textures);
  placeStructure(v2, 13, -12, 2.7, 2.6, 5.3, -0.8);

  // Watchtower & Radar
  const tower = buildWatchtower(textures);
  placeStructure(tower, -36, -34, 3.6, 8.0, 3.6);
  const radar = buildRadarArray();
  placeStructure(radar.group, 36, -34, 3.2, 5.2, 3.2);
  animatedObjects.push((dt) => {
    radar.dish.rotation.y += dt * 0.9;
  });

  // Extraction Helicopter on Citadel / Warfront / Harbor
  if (biome === 'citadel' || biome === 'warfront' || biome === 'harbor') {
    const heli = buildHelicopter();
    heli.group.position.set(0, 0.1, 40);
    heli.group.rotation.y = Math.PI;
    root.add(heli.group);
    animatedObjects.push((dt) => {
      heli.mainRotor.rotation.y += dt * 18;
      heli.tailRotor.rotation.x += dt * 24;
    });
  }

  // Fire/smoke sites for dramatic battlefield atmosphere
  fireSites.push(new THREE.Vector3(13, 0.5, -12), new THREE.Vector3(-22, 0.5, -6));
  if (biome === 'citadel' || biome === 'defense_fort' || biome === 'warfront') {
    fireSites.push(new THREE.Vector3(0, 0.5, -14), new THREE.Vector3(24, 0.5, 14));
  }

  // Interactive Objective Nodes per mission
  if (mission.objectiveKind === 'destroy_targets') {
    const coords = [
      [-26, -24],
      [0, -34],
      [26, -22],
    ];
    coords.forEach(([x, z], i) => {
      const targetMesh = buildFuelTankTarget();
      targetMesh.position.set(x, 0, z);
      const beacon = createBeaconMesh(0xef4444);
      targetMesh.add(beacon);
      root.add(targetMesh);
      raycastObstacles.push(targetMesh);
      addBoxCollider(colliders, x, 1.4, z, 3.4, 2.8, 2.4);
      objectiveNodes.push({
        id: `fuel_${i}`,
        x,
        y: 1.4,
        z,
        hp: 160,
        maxHp: 160,
        completed: false,
        mesh: targetMesh,
        beacon,
      });
    });
  } else if (mission.objectiveKind === 'hack_terminals') {
    const coords = [
      [-28, -28],
      [0, -36],
      [28, -24],
    ];
    coords.forEach(([x, z], i) => {
      const term = buildTerminalTarget();
      term.position.set(x, 0, z);
      const beacon = createBeaconMesh(0x38bdf8);
      term.add(beacon);
      root.add(term);
      objectiveNodes.push({
        id: `term_${i}`,
        x,
        y: 1.0,
        z,
        hp: 100,
        maxHp: 100,
        completed: false,
        mesh: term,
        beacon,
      });
    });
  } else if (mission.objectiveKind === 'capture_zone') {
    const coords =
      mission.targetCount === 1
        ? [[0, -34]]
        : [
            [-26, -22],
            [0, -4],
            [26, -22],
          ];
    coords.forEach(([x, z], i) => {
      const zoneGroup = new THREE.Group();
      zoneGroup.position.set(x, 0.05, z);
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(4.4, 5.0, 32),
        new THREE.MeshBasicMaterial({ color: 0xf59e0b, side: THREE.DoubleSide })
      );
      ring.rotation.x = -Math.PI / 2;
      const pole = new THREE.Mesh(
        new THREE.CylinderGeometry(0.1, 0.1, 4.5, 8),
        new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7 })
      );
      pole.position.y = 2.25;
      const beacon = createBeaconMesh(0xf59e0b);
      zoneGroup.add(ring, pole, beacon);
      root.add(zoneGroup);
      objectiveNodes.push({
        id: `zone_${i}`,
        x,
        y: 1.0,
        z,
        hp: 100,
        maxHp: 100,
        completed: false,
        mesh: zoneGroup,
        beacon,
      });
    });
  } else if (mission.objectiveKind === 'defend_core') {
    const coreGroup = new THREE.Group();
    coreGroup.position.set(0, 0, 18);
    const base = new THREE.Mesh(
      new THREE.CylinderGeometry(1.8, 2.2, 1.2, 12),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7, roughness: 0.35 })
    );
    base.position.y = 0.6;
    const crystal = new THREE.Mesh(
      new THREE.OctahedronGeometry(1.15, 0),
      new THREE.MeshStandardMaterial({
        color: 0x10b981,
        emissive: 0x059669,
        emissiveIntensity: 1.3,
        roughness: 0.2,
      })
    );
    crystal.position.y = 2.4;
    const beacon = createBeaconMesh(0x10b981);
    coreGroup.add(base, crystal, beacon);
    root.add(coreGroup);
    animatedObjects.push((dt) => {
      crystal.rotation.y += dt * 1.4;
    });
    objectiveNodes.push({
      id: 'base_core',
      x: 0,
      y: 2.0,
      z: 18,
      hp: 600,
      maxHp: 600,
      completed: false,
      mesh: coreGroup,
      beacon,
    });
  } else if (mission.objectiveKind === 'boss_citadel') {
    const coords = [
      [-18, -28],
      [18, -28],
    ];
    coords.forEach(([x, z], i) => {
      const shield = buildTerminalTarget();
      shield.position.set(x, 0, z);
      const beacon = createBeaconMesh(0xa855f7);
      shield.add(beacon);
      root.add(shield);
      raycastObstacles.push(shield);
      addBoxCollider(colliders, x, 1.0, z, 1.4, 2.0, 1.2);
      objectiveNodes.push({
        id: `shield_${i}`,
        x,
        y: 1.2,
        z,
        hp: 180,
        maxHp: 180,
        completed: false,
        mesh: shield,
        beacon,
      });
    });
  }

  const playerSpawn = new THREE.Vector3(0, 0, 38);
  const enemySpawns = [
    new THREE.Vector3(-30, 0, -28),
    new THREE.Vector3(30, 0, -28),
    new THREE.Vector3(0, 0, -34),
    new THREE.Vector3(-34, 0, -6),
    new THREE.Vector3(34, 0, -6),
    new THREE.Vector3(-14, 0, -14),
    new THREE.Vector3(14, 0, -14),
    new THREE.Vector3(0, 0, -4),
  ];
  const allySpawns = [
    new THREE.Vector3(-8, 0, 34),
    new THREE.Vector3(8, 0, 34),
    new THREE.Vector3(-16, 0, 28),
  ];

  return {
    root,
    colliders,
    raycastObstacles,
    playBounds,
    playerSpawn,
    enemySpawns,
    allySpawns,
    objectiveNodes,
    fireSites,
    animatedObjects,
    dispose: () => {
      root.traverse((obj) => {
        const m = obj as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
        if (m.material) {
          if (Array.isArray(m.material)) m.material.forEach((mt) => mt.dispose());
          else m.material.dispose();
        }
      });
    },
  };
}

export function buildMultiplayerArena(
  mapId: 'urban_arena' | 'harbor_arena',
  textures: TextureBundle
): BuiltMap {
  const pseudoMission: MissionDef = {
    id: 0,
    code: 'MP-ARENA',
    titleAr: mapId === 'harbor_arena' ? 'ساحة الميناء' : 'ساحة المدينة',
    subtitleAr: '',
    locationAr: '',
    biome: mapId === 'harbor_arena' ? 'harbor' : 'urban',
    difficulty: 3,
    briefingAr: '',
    cinematicLinesAr: [],
    objectiveKind: 'eliminate_squads',
    objectiveLabelAr: '',
    targetCount: 25,
    enemyCount: 0,
    rewardXp: 0,
    rewardCredits: 0,
    skyHex: 0x7a96ab,
    fogHex: 0x7a96ab,
    fogDensity: 0.007,
    sunColor: 0xfff1d6,
    sunIntensity: 2.1,
    hemiSky: 0x9ec0db,
    hemiGround: 0x3b4048,
    ambientWeather: 'clear',
  };
  return buildCampaignMap(pseudoMission, textures);
}

export function buildMenuDiorama(textures: TextureBundle): {
  root: THREE.Group;
  animate: (dt: number, elapsed: number) => void;
  dispose: () => void;
} {
  const root = new THREE.Group();
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(180, 180),
    new THREE.MeshStandardMaterial({
      map: textures.asphalt,
      roughness: 0.85,
      metalness: 0.1,
    })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  root.add(ground);

  createNaturePerimeter(root, 'urban', textures, 44);

  const mrap = buildArmoredVehicle(0x3b4a34, textures);
  mrap.position.set(-4.2, 0, 2);
  mrap.rotation.y = 0.55;
  root.add(mrap);

  const heli = buildHelicopter();
  heli.group.position.set(6, 0.1, -9);
  heli.group.rotation.y = -0.65;
  root.add(heli.group);

  const tower = buildWatchtower(textures);
  tower.position.set(-14, 0, -14);
  root.add(tower);

  const radar = buildRadarArray();
  radar.group.position.set(14, 0, -10);
  root.add(radar.group);

  const sb = createSandbagBunker(textures);
  sb.position.set(2.5, 0, 5);
  sb.rotation.y = -0.35;
  root.add(sb);

  return {
    root,
    animate: (dt: number) => {
      radar.dish.rotation.y += dt * 0.8;
      heli.mainRotor.rotation.y += dt * 7.5;
      heli.tailRotor.rotation.x += dt * 11;
    },
    dispose: () => {
      root.traverse((obj) => {
        const m = obj as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
        if (m.material) {
          if (Array.isArray(m.material)) m.material.forEach((mt) => mt.dispose());
          else m.material.dispose();
        }
      });
    },
  };
}
