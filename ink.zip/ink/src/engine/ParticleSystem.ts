import * as THREE from 'three';

interface ParticleItem {
  active: boolean;
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  startScale: number;
  endScale: number;
  gravity: number;
}

interface TracerItem {
  active: boolean;
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
}

interface ShockwaveItem {
  active: boolean;
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
  maxRadius: number;
}

export class ParticleSystem {
  private particles: ParticleItem[] = [];
  private tracers: TracerItem[] = [];
  private shockwaves: ShockwaveItem[] = [];
  private weatherPoints: THREE.Points | null = null;
  private weatherKind: 'rain_storm' | 'embers' | 'dust' | 'none' = 'none';
  private group = new THREE.Group();

  private sparkGeo = new THREE.BoxGeometry(0.14, 0.14, 0.14);
  private smokeGeo = new THREE.DodecahedronGeometry(0.45, 1);
  private tracerGeo = new THREE.CylinderGeometry(0.025, 0.025, 2.2, 6);
  private ringGeo = new THREE.RingGeometry(0.5, 0.9, 24);

  constructor(scene: THREE.Scene, maxParticles = 140) {
    this.tracerGeo.rotateX(Math.PI / 2);
    this.ringGeo.rotateX(-Math.PI / 2);

    for (let i = 0; i < maxParticles; i++) {
      const isSmoke = i % 3 === 0;
      const mat = new THREE.MeshBasicMaterial({
        color: isSmoke ? 0x333840 : 0xffaa33,
        transparent: true,
        opacity: 0.9,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(isSmoke ? this.smokeGeo : this.sparkGeo, mat);
      mesh.visible = false;
      this.group.add(mesh);
      this.particles.push({
        active: false,
        mesh,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        maxLife: 1,
        startScale: 1,
        endScale: 0.1,
        gravity: 0,
      });
    }

    for (let i = 0; i < 36; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffd27a,
        transparent: true,
        opacity: 0.9,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(this.tracerGeo, mat);
      mesh.visible = false;
      this.group.add(mesh);
      this.tracers.push({ active: false, mesh, life: 0, maxLife: 0.1 });
    }

    for (let i = 0; i < 8; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xff8c33,
        transparent: true,
        opacity: 0.85,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(this.ringGeo, mat);
      mesh.visible = false;
      this.group.add(mesh);
      this.shockwaves.push({ active: false, mesh, life: 0, maxLife: 0.45, maxRadius: 7 });
    }

    scene.add(this.group);
  }

  setupWeather(kind: 'clear' | 'dust' | 'night' | 'rain_storm' | 'embers'): void {
    if (this.weatherPoints) {
      this.group.remove(this.weatherPoints);
      this.weatherPoints.geometry.dispose();
      (this.weatherPoints.material as THREE.Material).dispose();
      this.weatherPoints = null;
    }

    if (kind === 'clear' || kind === 'night') {
      this.weatherKind = 'none';
      return;
    }

    this.weatherKind = kind;
    const count = kind === 'rain_storm' ? 950 : 320;
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 90;
      pos[i * 3 + 1] = Math.random() * 28;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));

    const mat = new THREE.PointsMaterial({
      color: kind === 'rain_storm' ? 0x9ec5e8 : kind === 'embers' ? 0xff7b29 : 0xe0bd85,
      size: kind === 'rain_storm' ? 0.22 : kind === 'embers' ? 0.24 : 0.35,
      transparent: true,
      opacity: kind === 'rain_storm' ? 0.65 : 0.55,
      depthWrite: false,
    });

    this.weatherPoints = new THREE.Points(geo, mat);
    this.weatherPoints.frustumCulled = false;
    this.group.add(this.weatherPoints);
  }

  spawnTracer(start: THREE.Vector3, end: THREE.Vector3, colorHex = 0xffdd77): void {
    const item = this.tracers.find((t) => !t.active) || this.tracers[0];
    item.active = true;
    item.life = 0;
    item.maxLife = 0.08;
    const dist = start.distanceTo(end);
    const len = Math.min(dist, 5.5);
    item.mesh.scale.set(1, 1, Math.max(0.2, len / 2.2));
    item.mesh.position.copy(start).lerp(end, 0.5);
    item.mesh.lookAt(end);
    const mat = item.mesh.material as THREE.MeshBasicMaterial;
    mat.color.setHex(colorHex);
    mat.opacity = 0.92;
    item.mesh.visible = true;
  }

  spawnImpact(pos: THREE.Vector3, colorHex = 0xffbb44, count = 8): void {
    for (let i = 0; i < count; i++) {
      const p = this.particles.find((item) => !item.active);
      if (!p) break;
      p.active = true;
      p.life = 0;
      p.maxLife = 0.22 + Math.random() * 0.22;
      p.mesh.position.copy(pos);
      p.vx = (Math.random() - 0.5) * 8;
      p.vy = 1.5 + Math.random() * 5;
      p.vz = (Math.random() - 0.5) * 8;
      p.gravity = 16;
      p.startScale = 0.8;
      p.endScale = 0.05;
      p.mesh.scale.setScalar(p.startScale);
      const mat = p.mesh.material as THREE.MeshBasicMaterial;
      mat.color.setHex(colorHex);
      mat.opacity = 1;
      p.mesh.visible = true;
    }
  }

  spawnExplosion(pos: THREE.Vector3, radius = 6.5): void {
    // Shockwave ring
    const ring = this.shockwaves.find((r) => !r.active) || this.shockwaves[0];
    ring.active = true;
    ring.life = 0;
    ring.maxLife = 0.45;
    ring.maxRadius = radius;
    ring.mesh.position.set(pos.x, Math.max(0.15, pos.y + 0.15), pos.z);
    ring.mesh.scale.setScalar(0.5);
    (ring.mesh.material as THREE.MeshBasicMaterial).opacity = 0.9;
    ring.mesh.visible = true;

    // Fire & Smoke burst
    for (let i = 0; i < 34; i++) {
      const p = this.particles.find((item) => !item.active);
      if (!p) break;
      const isSmoke = i % 2 === 0;
      p.active = true;
      p.life = 0;
      p.maxLife = isSmoke ? 1.1 + Math.random() * 0.6 : 0.4 + Math.random() * 0.3;
      p.mesh.position.set(
        pos.x + (Math.random() - 0.5) * 1.4,
        pos.y + 0.4 + Math.random() * 0.8,
        pos.z + (Math.random() - 0.5) * 1.4
      );
      const angle = Math.random() * Math.PI * 2;
      const spd = isSmoke ? 1.5 + Math.random() * 3.5 : 5 + Math.random() * 9;
      p.vx = Math.cos(angle) * spd;
      p.vy = isSmoke ? 2.8 + Math.random() * 4.0 : 4 + Math.random() * 8;
      p.vz = Math.sin(angle) * spd;
      p.gravity = isSmoke ? -1.4 : 12;
      p.startScale = isSmoke ? 1.2 : 1.8;
      p.endScale = isSmoke ? 3.8 : 0.2;
      p.mesh.scale.setScalar(p.startScale);
      const mat = p.mesh.material as THREE.MeshBasicMaterial;
      mat.color.setHex(
        isSmoke
          ? 0x2c3038
          : i % 3 === 0
            ? 0xff5511
            : 0xffbb33
      );
      mat.opacity = isSmoke ? 0.72 : 0.95;
      p.mesh.visible = true;
    }
  }

  spawnSmokeColumn(pos: THREE.Vector3): void {
    const p = this.particles.find((item) => !item.active);
    if (!p) return;
    p.active = true;
    p.life = 0;
    p.maxLife = 1.8 + Math.random() * 0.8;
    p.mesh.position.set(
      pos.x + (Math.random() - 0.5) * 0.6,
      pos.y + 0.2,
      pos.z + (Math.random() - 0.5) * 0.6
    );
    p.vx = (Math.random() - 0.5) * 0.7;
    p.vy = 2.2 + Math.random() * 1.4;
    p.vz = (Math.random() - 0.5) * 0.7;
    p.gravity = -0.3;
    p.startScale = 0.7;
    p.endScale = 2.9;
    p.mesh.scale.setScalar(p.startScale);
    const mat = p.mesh.material as THREE.MeshBasicMaterial;
    mat.color.setHex(Math.random() > 0.25 ? 0x2a2d33 : 0xff6b22);
    mat.opacity = 0.58;
    p.mesh.visible = true;
  }

  update(dt: number, playerX: number, playerZ: number): void {
    for (const p of this.particles) {
      if (!p.active) continue;
      p.life += dt;
      if (p.life >= p.maxLife) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }
      const t = p.life / p.maxLife;
      p.vy -= p.gravity * dt;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      const sc = p.startScale + (p.endScale - p.startScale) * t;
      p.mesh.scale.setScalar(sc);
      p.mesh.rotation.y += dt * 1.6;
      (p.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - t) * 0.85;
    }

    for (const tr of this.tracers) {
      if (!tr.active) continue;
      tr.life += dt;
      if (tr.life >= tr.maxLife) {
        tr.active = false;
        tr.mesh.visible = false;
        continue;
      }
      (tr.mesh.material as THREE.MeshBasicMaterial).opacity = 1 - tr.life / tr.maxLife;
    }

    for (const r of this.shockwaves) {
      if (!r.active) continue;
      r.life += dt;
      if (r.life >= r.maxLife) {
        r.active = false;
        r.mesh.visible = false;
        continue;
      }
      const t = r.life / r.maxLife;
      r.mesh.scale.setScalar(0.5 + t * r.maxRadius);
      (r.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - t) * 0.85;
    }

    if (this.weatherPoints && this.weatherKind !== 'none') {
      const attr = this.weatherPoints.geometry.getAttribute('position') as THREE.BufferAttribute;
      const arr = attr.array as Float32Array;
      const isRain = this.weatherKind === 'rain_storm';
      const isEmber = this.weatherKind === 'embers';
      for (let i = 0; i < arr.length; i += 3) {
        if (isRain) {
          arr[i] += 6 * dt;
          arr[i + 1] -= 34 * dt;
          if (arr[i + 1] < 0) {
            arr[i] = playerX + (Math.random() - 0.5) * 85;
            arr[i + 1] = 24 + Math.random() * 8;
            arr[i + 2] = playerZ + (Math.random() - 0.5) * 85;
          }
        } else if (isEmber) {
          arr[i] += Math.sin(arr[i + 1] + i) * 1.4 * dt;
          arr[i + 1] += 2.6 * dt;
          if (arr[i + 1] > 24) {
            arr[i] = playerX + (Math.random() - 0.5) * 75;
            arr[i + 1] = 0.2;
            arr[i + 2] = playerZ + (Math.random() - 0.5) * 75;
          }
        } else {
          arr[i] += 3.5 * dt;
          if (Math.abs(arr[i] - playerX) > 45) {
            arr[i] = playerX - 42;
            arr[i + 2] = playerZ + (Math.random() - 0.5) * 80;
          }
        }
      }
      attr.needsUpdate = true;
    }
  }

  dispose(): void {
    this.sparkGeo.dispose();
    this.smokeGeo.dispose();
    this.tracerGeo.dispose();
    this.ringGeo.dispose();
    this.particles.forEach((p) => (p.mesh.material as THREE.Material).dispose());
    this.tracers.forEach((t) => (t.mesh.material as THREE.Material).dispose());
    this.shockwaves.forEach((r) => (r.mesh.material as THREE.Material).dispose());
    if (this.weatherPoints) {
      this.weatherPoints.geometry.dispose();
      (this.weatherPoints.material as THREE.Material).dispose();
    }
  }
}
