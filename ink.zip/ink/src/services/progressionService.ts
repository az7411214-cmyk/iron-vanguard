import { signInWithPopup, signOut } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import type {
  CharacterId,
  LeaderboardEntry,
  MissionRecord,
  PlayerProfile,
  SkinId,
  WeaponId,
} from '../game/types';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from './firebase';

const LOCAL_PROFILE_KEY = 'iron_vanguard_profile_v1';

export function createDefaultProfile(userId = 'local_guest', callsign = 'طليعة-01'): PlayerProfile {
  return {
    userId,
    callsign: callsign.slice(0, 24),
    xp: 0,
    credits: 300,
    rank: 1,
    unlockedMission: 1,
    completedMissions: [],
    unlockedWeapons: ['m4a1', 'p226'],
    unlockedSkins: ['olive'],
    selectedCharacter: 'striker',
    selectedSkin: 'olive',
    primaryWeapon: 'm4a1',
    secondaryWeapon: 'p226',
    kills: 0,
    deaths: 0,
    wins: 0,
    missionRecords: {},
  };
}

export function loadLocalProfile(): PlayerProfile {
  try {
    const raw = localStorage.getItem(LOCAL_PROFILE_KEY);
    if (!raw) return createDefaultProfile();
    const parsed = JSON.parse(raw) as Partial<PlayerProfile>;
    return {
      ...createDefaultProfile(),
      ...parsed,
      unlockedWeapons:
        Array.isArray(parsed.unlockedWeapons) && parsed.unlockedWeapons.length > 0
          ? parsed.unlockedWeapons
          : ['m4a1', 'p226'],
      unlockedSkins:
        Array.isArray(parsed.unlockedSkins) && parsed.unlockedSkins.length > 0
          ? parsed.unlockedSkins
          : ['olive'],
      completedMissions: Array.isArray(parsed.completedMissions)
        ? parsed.completedMissions.slice(0, 10)
        : [],
    };
  } catch {
    return createDefaultProfile();
  }
}

export function saveLocalProfile(profile: PlayerProfile): void {
  try {
    localStorage.setItem(LOCAL_PROFILE_KEY, JSON.stringify(profile));
  } catch {
    // ignore storage quota
  }
}

export function computeRankFromXp(xp: number): number {
  return Math.max(1, Math.min(100, Math.floor(1 + Math.sqrt(xp / 180))));
}

export async function signInWithGoogleAccount(): Promise<void> {
  await signInWithPopup(auth, googleProvider);
}

export async function signOutAccount(): Promise<void> {
  await signOut(auth);
}

function sanitizeCallsign(raw: string | null | undefined): string {
  const cleaned = (raw || '').trim().slice(0, 24);
  return cleaned.length >= 2 ? cleaned : 'طليعة-01';
}

function sanitizeProfilePayload(profile: PlayerProfile, userId: string) {
  return {
    userId,
    callsign: sanitizeCallsign(profile.callsign),
    xp: Math.max(0, Math.min(100000000, Math.floor(profile.xp))),
    credits: Math.max(0, Math.min(100000000, Math.floor(profile.credits))),
    rank: Math.max(1, Math.min(100, Math.floor(profile.rank))),
    unlockedMission: Math.max(1, Math.min(10, Math.floor(profile.unlockedMission))),
    completedMissions: Array.from(new Set(profile.completedMissions)).slice(0, 10),
    unlockedWeapons: Array.from(new Set(profile.unlockedWeapons)).slice(0, 20),
    unlockedSkins: Array.from(new Set(profile.unlockedSkins)).slice(0, 20),
    selectedCharacter: profile.selectedCharacter,
    selectedSkin: profile.selectedSkin,
    primaryWeapon: profile.primaryWeapon,
    secondaryWeapon: profile.secondaryWeapon,
    kills: Math.max(0, Math.min(10000000, Math.floor(profile.kills))),
    deaths: Math.max(0, Math.min(10000000, Math.floor(profile.deaths))),
    wins: Math.max(0, Math.min(10000000, Math.floor(profile.wins))),
  };
}

export async function loadOrCreateCloudProfile(
  uid: string,
  displayName?: string | null
): Promise<PlayerProfile> {
  const userPath = `users/${uid}`;
  const userRef = doc(db, 'users', uid);

  let snap;
  try {
    snap = await getDoc(userRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, userPath);
  }

  if (!snap.exists()) {
    const local = loadLocalProfile();
    const initial = createDefaultProfile(
      uid,
      displayName ? displayName.slice(0, 20) : local.callsign
    );
    // Merge any local guest progress when user signs in for the first time
    initial.xp = local.xp;
    initial.credits = Math.max(initial.credits, local.credits);
    initial.rank = computeRankFromXp(initial.xp);
    initial.unlockedMission = local.unlockedMission;
    initial.completedMissions = local.completedMissions;
    initial.unlockedWeapons = Array.from(new Set([...initial.unlockedWeapons, ...local.unlockedWeapons]));
    initial.unlockedSkins = Array.from(new Set([...initial.unlockedSkins, ...local.unlockedSkins]));
    initial.selectedCharacter = local.selectedCharacter;
    initial.selectedSkin = local.selectedSkin;
    initial.primaryWeapon = local.primaryWeapon;
    initial.kills = local.kills;
    initial.deaths = local.deaths;
    initial.wins = local.wins;

    const payload = {
      ...sanitizeProfilePayload(initial, uid),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    try {
      await setDoc(userRef, payload);
      await syncLeaderboardEntry(initial);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, userPath);
    }

    saveLocalProfile(initial);
    return initial;
  }

  const data = snap.data();
  const recordsMap: Record<number, MissionRecord> = {};
  const recordsPath = `users/${uid}/missionRecords`;
  try {
    const recSnap = await getDocs(collection(db, 'users', uid, 'missionRecords'));
    recSnap.forEach((docItem) => {
      const r = docItem.data() as MissionRecord;
      if (typeof r.missionId === 'number') {
        recordsMap[r.missionId] = r;
      }
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, recordsPath);
  }

  const loaded: PlayerProfile = {
    userId: uid,
    callsign: String(data.callsign || 'مقاتل'),
    xp: Number(data.xp || 0),
    credits: Number(data.credits || 0),
    rank: Number(data.rank || 1),
    unlockedMission: Number(data.unlockedMission || 1),
    completedMissions: Array.isArray(data.completedMissions) ? data.completedMissions : [],
    unlockedWeapons: Array.isArray(data.unlockedWeapons)
      ? (data.unlockedWeapons as WeaponId[])
      : ['m4a1', 'p226'],
    unlockedSkins: Array.isArray(data.unlockedSkins) ? (data.unlockedSkins as SkinId[]) : ['olive'],
    selectedCharacter: (data.selectedCharacter as CharacterId) || 'striker',
    selectedSkin: (data.selectedSkin as SkinId) || 'olive',
    primaryWeapon: (data.primaryWeapon as WeaponId) || 'm4a1',
    secondaryWeapon: (data.secondaryWeapon as WeaponId) || 'p226',
    kills: Number(data.kills || 0),
    deaths: Number(data.deaths || 0),
    wins: Number(data.wins || 0),
    missionRecords: recordsMap,
  };

  saveLocalProfile(loaded);
  return loaded;
}

export async function saveLoadoutToCloud(profile: PlayerProfile): Promise<void> {
  saveLocalProfile(profile);
  if (!auth.currentUser || auth.currentUser.uid !== profile.userId) return;

  const userPath = `users/${profile.userId}`;
  try {
    await updateDoc(doc(db, 'users', profile.userId), {
      callsign: sanitizeCallsign(profile.callsign),
      selectedCharacter: profile.selectedCharacter,
      selectedSkin: profile.selectedSkin,
      primaryWeapon: profile.primaryWeapon,
      secondaryWeapon: profile.secondaryWeapon,
      updatedAt: serverTimestamp(),
    });
    await syncLeaderboardEntry(profile);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, userPath);
  }
}

export async function saveProgressionToCloud(profile: PlayerProfile): Promise<void> {
  saveLocalProfile(profile);
  if (!auth.currentUser || auth.currentUser.uid !== profile.userId) return;

  const clean = sanitizeProfilePayload(profile, profile.userId);
  const userPath = `users/${profile.userId}`;
  try {
    await updateDoc(doc(db, 'users', profile.userId), {
      xp: clean.xp,
      credits: clean.credits,
      rank: clean.rank,
      unlockedMission: clean.unlockedMission,
      completedMissions: clean.completedMissions,
      unlockedWeapons: clean.unlockedWeapons,
      unlockedSkins: clean.unlockedSkins,
      kills: clean.kills,
      deaths: clean.deaths,
      wins: clean.wins,
      selectedCharacter: clean.selectedCharacter,
      selectedSkin: clean.selectedSkin,
      primaryWeapon: clean.primaryWeapon,
      secondaryWeapon: clean.secondaryWeapon,
      updatedAt: serverTimestamp(),
    });
    await syncLeaderboardEntry(profile);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, userPath);
  }
}

export async function saveMissionRecordToCloud(
  uid: string,
  record: MissionRecord
): Promise<void> {
  if (!auth.currentUser || auth.currentUser.uid !== uid) return;
  const docId = `m${record.missionId}`;
  const path = `users/${uid}/missionRecords/${docId}`;
  const ref = doc(db, 'users', uid, 'missionRecords', docId);
  try {
    const existingSnap = await getDoc(ref);
    if (existingSnap.exists()) {
      const prev = existingSnap.data() as MissionRecord;
      await updateDoc(ref, {
        stars: Math.max(1, Math.min(3, Math.round(Math.max(prev.stars || 1, record.stars)))),
        bestScore: Math.max(0, Math.min(10000000, Math.round(Math.max(prev.bestScore || 0, record.bestScore)))),
        bestTimeSec: Math.max(
          1,
          Math.min(
            86400,
            Math.round(
              prev.bestTimeSec
                ? Math.min(prev.bestTimeSec, record.bestTimeSec)
                : record.bestTimeSec
            )
          )
        ),
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        userId: uid,
        missionId: record.missionId,
        stars: Math.max(1, Math.min(3, Math.round(record.stars))),
        bestScore: Math.max(0, Math.min(10000000, Math.round(record.bestScore))),
        bestTimeSec: Math.max(1, Math.min(86400, Math.round(record.bestTimeSec))),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function syncLeaderboardEntry(profile: PlayerProfile): Promise<void> {
  if (!auth.currentUser || auth.currentUser.uid !== profile.userId) return;
  const path = `leaderboard/${profile.userId}`;
  try {
    await setDoc(doc(db, 'leaderboard', profile.userId), {
      userId: profile.userId,
      callsign: sanitizeCallsign(profile.callsign),
      rank: Math.max(1, Math.min(100, Math.floor(profile.rank))),
      xp: Math.max(0, Math.min(100000000, Math.floor(profile.xp))),
      kills: Math.max(0, Math.min(10000000, Math.floor(profile.kills))),
      wins: Math.max(0, Math.min(10000000, Math.floor(profile.wins))),
      isPublic: true,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function fetchLeaderboard(): Promise<LeaderboardEntry[]> {
  if (!auth.currentUser) return [];
  const path = 'leaderboard';
  try {
    const q = query(
      collection(db, 'leaderboard'),
      where('isPublic', '==', true),
      orderBy('xp', 'desc'),
      limit(20)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as LeaderboardEntry);
  } catch (err) {
    const code = (err as { code?: string } | null)?.code;
    const msg = err instanceof Error ? err.message : String(err);
    if (code === 'failed-precondition' || msg.includes('requires an index')) {
      try {
        const fallbackQ = query(
          collection(db, 'leaderboard'),
          where('isPublic', '==', true),
          limit(100)
        );
        const snap = await getDocs(fallbackQ);
        return snap.docs
          .map((d) => d.data() as LeaderboardEntry)
          .sort((a, b) => (b.xp || 0) - (a.xp || 0))
          .slice(0, 20);
      } catch (fallbackErr) {
        handleFirestoreError(fallbackErr, OperationType.LIST, path);
      }
    }
    handleFirestoreError(err, OperationType.LIST, path);
  }
}
