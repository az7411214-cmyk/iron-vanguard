import type {
  CharacterId,
  ChatMessage,
  MultiplayerRoomState,
  SkinId,
  TeamSizeMode,
  WeaponId,
} from '../game/types';

export interface MpDeltaPacket {
  id: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  crouching: boolean;
  moving: boolean;
  weaponId: WeaponId;
}

export interface MpFirePacket {
  playerId: string;
  weaponId: WeaponId;
  ox: number;
  oy: number;
  oz: number;
  dx: number;
  dy: number;
  dz: number;
}

export interface MpKillEvent {
  killerId: string;
  killerName: string;
  killerTeam: 'alpha' | 'bravo';
  victimId: string;
  victimName: string;
  victimTeam: 'alpha' | 'bravo';
  weaponId: WeaponId;
  headshot: boolean;
}

export interface MpDamagePacket {
  hp: number;
  fromId: string;
  fromX: number;
  fromZ: number;
}

export interface MpRespawnPacket {
  x: number;
  y: number;
  z: number;
  yaw: number;
}

type ListenerMap = {
  connected: (playerId: string) => void;
  disconnected: () => void;
  roomState: (room: MultiplayerRoomState | null) => void;
  matchStarted: (room: MultiplayerRoomState) => void;
  matchEnded: (room: MultiplayerRoomState) => void;
  chat: (msg: ChatMessage) => void;
  error: (message: string) => void;
  playerDelta: (delta: MpDeltaPacket) => void;
  remoteFire: (fire: MpFirePacket) => void;
  tookDamage: (dmg: MpDamagePacket) => void;
  killEvent: (ev: MpKillEvent) => void;
  respawned: (sp: MpRespawnPacket) => void;
};

export class MultiplayerClient {
  private ws: WebSocket | null = null;
  private reconnectTimer: number | null = null;
  private intentionalClose = false;
  public playerId: string | null = null;
  public currentRoom: MultiplayerRoomState | null = null;

  private listeners: { [K in keyof ListenerMap]: Set<ListenerMap[K]> } = {
    connected: new Set(),
    disconnected: new Set(),
    roomState: new Set(),
    matchStarted: new Set(),
    matchEnded: new Set(),
    chat: new Set(),
    error: new Set(),
    playerDelta: new Set(),
    remoteFire: new Set(),
    tookDamage: new Set(),
    killEvent: new Set(),
    respawned: new Set(),
  };

  on<K extends keyof ListenerMap>(event: K, fn: ListenerMap[K]): () => void {
    this.listeners[event].add(fn);
    return () => {
      this.listeners[event].delete(fn);
    };
  }

  private emit<K extends keyof ListenerMap>(
    event: K,
    ...args: Parameters<ListenerMap[K]>
  ): void {
    for (const fn of this.listeners[event]) {
      (fn as (...a: Parameters<ListenerMap[K]>) => void)(...args);
    }
  }

  connect(): void {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }
    this.intentionalClose = false;
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${proto}//${window.location.host}/ws`;
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.onmessage = (event) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(String(event.data)) as Record<string, unknown>;
      } catch {
        return;
      }
      const type = String(msg.type || '');
      if (type === 'welcome') {
        this.playerId = String(msg.playerId || '');
        this.emit('connected', this.playerId);
      } else if (type === 'joined_room') {
        this.playerId = String(msg.playerId || this.playerId || '');
        this.currentRoom = msg.room as MultiplayerRoomState;
        this.emit('roomState', this.currentRoom);
      } else if (type === 'room_state') {
        this.currentRoom = msg.room as MultiplayerRoomState;
        this.emit('roomState', this.currentRoom);
      } else if (type === 'match_started') {
        this.currentRoom = msg.room as MultiplayerRoomState;
        this.emit('roomState', this.currentRoom);
        this.emit('matchStarted', this.currentRoom);
      } else if (type === 'match_ended') {
        this.currentRoom = msg.room as MultiplayerRoomState;
        this.emit('roomState', this.currentRoom);
        this.emit('matchEnded', this.currentRoom);
      } else if (type === 'left_room') {
        this.currentRoom = null;
        this.emit('roomState', null);
      } else if (type === 'chat_message') {
        this.emit('chat', msg.message as ChatMessage);
      } else if (type === 'error') {
        this.emit('error', String(msg.message || 'خطأ في الاتصال بالخادم.'));
      } else if (type === 'player_delta') {
        this.emit('playerDelta', msg as unknown as MpDeltaPacket);
      } else if (type === 'remote_fire') {
        this.emit('remoteFire', msg as unknown as MpFirePacket);
      } else if (type === 'took_damage') {
        this.emit('tookDamage', msg as unknown as MpDamagePacket);
      } else if (type === 'kill_event') {
        this.emit('killEvent', msg as unknown as MpKillEvent);
      } else if (type === 'respawned') {
        this.emit('respawned', msg as unknown as MpRespawnPacket);
      }
    };

    ws.onclose = () => {
      this.ws = null;
      this.emit('disconnected');
      if (!this.intentionalClose) {
        if (this.reconnectTimer) window.clearTimeout(this.reconnectTimer);
        this.reconnectTimer = window.setTimeout(() => this.connect(), 2000);
      }
    };
  }

  disconnect(): void {
    this.intentionalClose = true;
    if (this.reconnectTimer) {
      window.clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.currentRoom = null;
  }

  private send(payload: Record<string, unknown>): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }

  createRoom(opts: {
    roomName: string;
    isPrivate: boolean;
    mode: 'tdm' | 'domination';
    teamSize: TeamSizeMode;
    mapId: 'urban_arena' | 'harbor_arena';
    callsign: string;
    characterId: CharacterId;
    skinId: SkinId;
    weaponId: WeaponId;
  }): void {
    this.send({ type: 'create_room', ...opts });
  }

  quickMatch(opts: {
    mode: 'tdm' | 'domination';
    teamSize: TeamSizeMode;
    callsign: string;
    characterId: CharacterId;
    skinId: SkinId;
    weaponId: WeaponId;
  }): void {
    this.send({ type: 'quick_match', ...opts });
  }

  joinRoom(opts: {
    code: string;
    callsign: string;
    characterId: CharacterId;
    skinId: SkinId;
    weaponId: WeaponId;
  }): void {
    this.send({ type: 'join_room', ...opts });
  }

  leaveRoom(): void {
    this.send({ type: 'leave_room' });
    this.currentRoom = null;
    this.emit('roomState', null);
  }

  switchTeam(): void {
    this.send({ type: 'switch_team' });
  }

  setReady(ready: boolean): void {
    this.send({ type: 'set_ready', ready });
  }

  updateLoadout(characterId: CharacterId, skinId: SkinId, weaponId: WeaponId): void {
    this.send({ type: 'update_loadout', characterId, skinId, weaponId });
  }

  startMatch(): void {
    this.send({ type: 'start_match' });
  }

  returnToLobby(): void {
    this.send({ type: 'return_lobby' });
  }

  sendChat(text: string): void {
    this.send({ type: 'chat_message', text });
  }

  sendPlayerState(state: {
    x: number;
    y: number;
    z: number;
    yaw: number;
    pitch: number;
    crouching: boolean;
    moving: boolean;
    weaponId: WeaponId;
  }): void {
    this.send({ type: 'player_state', ...state });
  }

  sendFire(fire: {
    weaponId: WeaponId;
    ox: number;
    oy: number;
    oz: number;
    dx: number;
    dy: number;
    dz: number;
  }): void {
    this.send({ type: 'player_fire', ...fire });
  }

  sendHitClaim(targetId: string, headshot: boolean): void {
    this.send({ type: 'hit_claim', targetId, headshot });
  }

  sendHeal(): void {
    this.send({ type: 'player_heal' });
  }
}

export const mpClient = new MultiplayerClient();
